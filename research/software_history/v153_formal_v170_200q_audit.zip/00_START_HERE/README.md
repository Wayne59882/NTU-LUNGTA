# Added150 / Total200 formal v153 audit v170

## Fixed model configuration

- Formal Main KB factor weights:
  **45, 8, 0, 7, 0, 18, 2, 0, 2, 12**
- Final Active-7 weights:
  **45, 8, 7, 18, 2, 2, 12**
- Formal Domain threshold: **1**
- Formal Main KB Gate: **68**

The factor weights and Gate are locked before external validation.

## Added150 results

- Domain: TP 75, FP 0, TN 75, FN 0, F1 100.00%
- Main KB at Gate 68: TP 73, FP 6, TN 69, FN 2, F1 94.81%
- Highest-F1 Main KB plateau: **68–71**

## Total200 results

- Domain: TP 100, FP 1, TN 99, FN 0, F1 99.50%
- Main KB at Gate 68: TP 98, FP 7, TN 93, FN 2, F1 95.61%
- Highest-F1 Main KB plateau: **68–71**

## Correct validation interpretation

Added150 and Total200 validate the locked model. They do not redefine the
individual factor weights. The plateau becomes narrower, but its left edge
remains 68.

The previous post-hoc robustness OFAT has been removed from the formal report
and replaced by the Original50 formal weight-selection OFAT plus a locked-weight
table across all three datasets.

## Figure standard

- Metric Y-axis: **Score percentage (%)**
- Confusion matrices: blue monochrome with direct TN/FP/FN/TP labels
- Count and raw-score charts retain their actual units
- Word-ready editable tables and PNG/SVG figures are in `08_WORD_READY`
