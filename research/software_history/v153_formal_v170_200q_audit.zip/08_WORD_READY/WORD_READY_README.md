# Word-ready v170

The DOCX contains editable Word tables and embedded 300-dpi figures.
PNG and SVG copies are provided separately.

Added150 and Total200 are validation datasets. They do not reselect the
formal factor weights.

Formal weights:
45, 8, 0, 7, 0, 18, 2, 0, 2, 12.

Formal Main KB Gate:
68.

Metric Y-axis:
Score percentage (%).

Confusion matrices:
blue monochrome with explicit TN, FP, FN and TP labels.
