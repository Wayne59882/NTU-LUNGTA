/* v60: Global speech stop and state sync patch.
   Goal: whenever the user changes course/tab/question/mode, all current TTS audio stops immediately.
   This patch is intentionally UI-preserving and content-preserving. */
(function(){
  const $ = id => document.getElementById(id);
  let lastStopAt = 0;
  function setStatus(msg){
    const s = $('status');
    if(s) s.textContent = '狀態：' + msg;
  }
  function hardStopSpeech(reason){
    lastStopAt = Date.now();
    try{
      if(window.speechSynthesis){
        window.speechSynthesis.pause();
        window.speechSynthesis.cancel();
        // Some Chromium voices keep one queued utterance; cancel twice in next tick.
        setTimeout(()=>{ try{ window.speechSynthesis.cancel(); }catch(_){} }, 0);
        setTimeout(()=>{ try{ window.speechSynthesis.cancel(); }catch(_){} }, 80);
      }
    }catch(_){ }
    try{ document.body.classList.remove('speaking'); }catch(_){ }
    if(reason) setStatus(reason);
  }

  // Replace the public speech function used by later QA patches.
  // It always cancels any previous utterance before speaking the current visible answer.
  window.v60HardStopSpeech = hardStopSpeech;
  window.v50Speak = function(text){
    const clean = String(text || '').trim();
    if(!clean || !window.speechSynthesis) return;
    hardStopSpeech('正在切換到最新語音');
    const startedAt = Date.now();
    setTimeout(()=>{
      // If another stop/switch happened after this speak request, do not speak stale text.
      if(lastStopAt > startedAt) return;
      try{
        const u = new SpeechSynthesisUtterance(clean);
        const voiceSelect = $('voiceSelect');
        const voices = window.speechSynthesis.getVoices ? window.speechSynthesis.getVoices() : [];
        if(voiceSelect && voices[Number(voiceSelect.value)]) u.voice = voices[Number(voiceSelect.value)];
        else {
          const zh = voices.find(v => /zh|cmn|Taiwan|Chinese/i.test((v.lang||'') + ' ' + (v.name||'')));
          if(zh) u.voice = zh;
        }
        u.lang = 'zh-TW';
        const rate = parseFloat(($('rateRange')||{}).value || '1');
        const pitch = parseFloat(($('pitchRange')||{}).value || '1');
        u.rate = Number.isFinite(rate) ? rate : 1;
        u.pitch = Number.isFinite(pitch) ? pitch : 1;
        u.onstart = ()=>{ document.body.classList.add('speaking'); setStatus('正在朗讀目前畫面內容'); };
        u.onend = ()=>{ document.body.classList.remove('speaking'); setStatus('語音播放完成'); };
        u.onerror = ()=>{ document.body.classList.remove('speaking'); setStatus('語音播放已中止或失敗'); };
        window.speechSynthesis.speak(u);
      }catch(e){ setStatus('語音播放失敗'); }
    }, 120);
  };

  function bindStopTo(el, eventName, reason){
    if(!el || el.dataset.v60StopBound) return;
    el.addEventListener(eventName, ()=>hardStopSpeech(reason), true);
    el.dataset.v60StopBound = '1';
  }

  function install(){
    // Stop old speech when user starts typing/editing a new question.
    const q = $('studentQuestion');
    if(q){
      q.addEventListener('focus', ()=>hardStopSpeech('已停止語音，可輸入新問題'), true);
      q.addEventListener('input', ()=>hardStopSpeech('已停止語音，正在編輯新問題'), true);
      q.addEventListener('paste', ()=>hardStopSpeech('已停止語音，正在貼上新問題'), true);
    }

    // Stop old speech when starting voice recognition.
    bindStopTo($('askBtn'), 'click', '已停止目前語音，準備聆聽新問題');
    bindStopTo($('answerCaseBtn'), 'click', '已停止目前語音，準備聆聽情境題回答');

    // Stop speech immediately before submitting a new question/answer; new answer may speak afterward.
    bindStopTo($('submitTypedQuestionBtn'), 'click', '已停止上一段語音，正在產生新回答');
    bindStopTo($('stopAskBtn'), 'click', '已停止上一段語音，正在送出語音問題');
    bindStopTo($('submitTypedCaseBtn'), 'click', '已停止上一段語音，正在產生情境題回饋');
    bindStopTo($('stopCaseBtn'), 'click', '已停止上一段語音，正在送出情境題回答');

    // Stop on course/menu/tab/model/case switching. These actions should never leave stale audio playing.
    const switchIds = [
      'caseSelect',
      'lessonTab','caseTab','modelTab',
      'nextCaseBtn','hintBtn','startCaseBtn',
      'normalBtn','peBtn','pneumoniaBtn','shuntBtn','deadSpaceBtn',
      'v37NoBtn','v37MisBtn','v37PEBtn','v37PneuBtn','v37ShuntBtn','v37DeadBtn','v37NextBtn',
      'clearBtn'
    ];
    switchIds.forEach(id=>{
      const el = $(id);
      if(el){
        bindStopTo(el, 'click', '已停止語音');
        bindStopTo(el, 'change', '已停止語音，已切換內容');
      }
    });

    // The explicit stop button should be aggressive.
    const stopLesson = $('stopLessonBtn');
    if(stopLesson){
      stopLesson.onclick = function(e){ e.preventDefault(); hardStopSpeech('語音已完全停止'); };
    }

    // Patch submit if available: stop first, then submit, and only speak the answer produced by that submit.
    if(window.VQ_V55_submit && !window.VQ_V55_submit_v60_wrapped){
      const oldSubmit = window.VQ_V55_submit;
      window.VQ_V55_submit = async function(){
        hardStopSpeech('已停止上一段語音，正在回答新問題');
        return oldSubmit.apply(this, arguments);
      };
      window.VQ_V55_submit_v60_wrapped = true;
    }

    setStatus('系統已就緒');
  }

  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', ()=>setTimeout(install, 180));
  else setTimeout(install, 180);
})();
