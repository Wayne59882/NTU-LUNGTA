/* v62: stop microphone recognition immediately whenever a question is submitted or the user switches task.
   This patch does not change UI/course/KB content. It only synchronizes SpeechRecognition state with submit events. */
(function(){
  const $ = id => document.getElementById(id);
  const activeRecognizers = new Set();
  let recognitionActive = false;

  function setStatus(msg){
    const s = $('status');
    if(s) s.textContent = '狀態：' + msg;
  }
  function resetVoiceButtons(){
    ['askBtn','answerCaseBtn'].forEach(id=>{ const b=$(id); if(b) b.disabled=false; });
    ['stopAskBtn','stopCaseBtn'].forEach(id=>{ const b=$(id); if(b) b.disabled=true; });
    ['studentQuestion','studentCaseAnswer'].forEach(id=>{
      const el=$(id); if(!el) return;
      el.classList && el.classList.remove('listening-mode');
      if((el.textContent||'').trim()==='正在聆聽...' || (el.textContent||'').trim()==='正在聆聽…') el.textContent='';
      if(id==='studentQuestion') el.setAttribute('data-placeholder','請在這裡輸入問題，或按「學生開始提問」使用語音。');
    });
  }
  function stopAllRecognition(reason){
    recognitionActive = false;
    activeRecognizers.forEach(r=>{ try{ r.stop ? r.stop() : (r.abort ? r.abort() : null); }catch(_){} });
    resetVoiceButtons();
    if(reason) setStatus(reason);
  }
  window.VQ_stopAllRecognition = stopAllRecognition;

  function wrapRecognitionConstructor(name){
    const Original = window[name];
    if(!Original || Original.__v62Wrapped) return;
    function WrappedRecognition(){
      const r = new Original();
      activeRecognizers.add(r);
      const origStart = r.start ? r.start.bind(r) : null;
      const origStop = r.stop ? r.stop.bind(r) : null;
      const origAbort = r.abort ? r.abort.bind(r) : null;
      if(origStart){
        r.start = function(){ recognitionActive = true; activeRecognizers.add(r); return origStart(); };
      }
      if(origStop){
        r.stop = function(){ recognitionActive = false; return origStop(); };
      }
      if(origAbort){
        r.abort = function(){ recognitionActive = false; return origAbort(); };
      }
      r.addEventListener && r.addEventListener('end', ()=>{ recognitionActive=false; resetVoiceButtons(); });
      r.addEventListener && r.addEventListener('error', ()=>{ recognitionActive=false; resetVoiceButtons(); });
      return r;
    }
    WrappedRecognition.prototype = Original.prototype;
    WrappedRecognition.__v62Wrapped = true;
    window[name] = WrappedRecognition;
  }
  wrapRecognitionConstructor('SpeechRecognition');
  wrapRecognitionConstructor('webkitSpeechRecognition');

  function bindStopBefore(el, eventName, reason){
    if(!el || el.dataset.v62RecStopBound) return;
    el.addEventListener(eventName, function(){
      if(recognitionActive || activeRecognizers.size) stopAllRecognition(reason);
    }, true);
    el.dataset.v62RecStopBound='1';
  }
  function install(){
    // If the user sends a typed question, recording must end immediately.
    bindStopBefore($('submitTypedQuestionBtn'), 'click', '已停止錄音，正在送出文字問題');
    // If the user finishes voice input, stop recording first; existing handler may then submit the recognized text.
    bindStopBefore($('stopAskBtn'), 'click', '已停止錄音，正在送出語音問題');
    bindStopBefore($('submitTypedCaseBtn'), 'click', '已停止錄音，正在送出情境題回答');
    bindStopBefore($('stopCaseBtn'), 'click', '已停止錄音，正在送出語音回答');
    // Switching content should also end recording.
    ['lessonSelect','caseSelect','lessonTab','caseTab','modelTab','clearBtn','startCaseBtn','nextCaseBtn'].forEach(id=>{
      const el=$(id); if(el){ bindStopBefore(el,'click','已停止錄音'); bindStopBefore(el,'change','已停止錄音，已切換內容'); }
    });
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded', install); else install();
})();
