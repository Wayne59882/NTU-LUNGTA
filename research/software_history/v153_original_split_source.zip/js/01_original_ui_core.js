/* v50: original UI core script kept; wrapped to avoid total blank screen if one module fails */
try {

(function(){
  const LESSONS = {"basic":{"title":"課程 1：Gas Exchange 基本架構","keywords":["gas exchange","氣體交換","基本","架構","血氣","abg"],"script":"同學你好，這一單元我們先建立 gas exchange 的基本架構。\n\n氣體交換不是只看 PaO2 或 PaCO2，而是要同時看四個層次：ventilation、perfusion、diffusion，以及 blood oxygen content。\n\n第一，ventilation 是空氣是否能到達肺泡。  \n第二，perfusion 是血流是否能到達肺泡周圍微血管。  \n第三，diffusion 是氧氣是否能跨過 alveolar-capillary membrane。  \n第四，oxygen content 是血液是否有足夠 hemoglobin 攜帶氧氣。\n\n所以當病人低血氧時，不能直接說一定是肺泡氧氣不足，也不能直接說一定是 hemoglobin 問題。要先判斷問題發生在哪一個環節。\n\n在這份講義裡，後面的每一個主題都可以接回這四個層次。Ventilation 影響 PaCO2 和 PAO2；perfusion 影響 V/Q；diffusion 影響 A-a gradient；hemoglobin 影響 CaO2 和 oxygen delivery。"},"ventilation":{"title":"課程 2：Ventilation 與 Alveolar Ventilation","keywords":["ventilation","通氣","alveolar ventilation","va","vt","vd","frequency","respiratory rate","dead space","潮氣容積","呼吸頻率"],"script":"同學你好，這一單元講 ventilation 與 alveolar ventilation。\n\nMinute ventilation 是每分鐘總通氣量：\nVE = VT × f。\n\nVT 是 tidal volume，f 是 respiratory frequency。\n\n但是，不是所有進入氣道的空氣都能參與氣體交換。dead space 的空氣不參與肺泡交換。\n\n所以真正影響 PaCO2 的是 alveolar ventilation：\nVA = (VT - VD) × f。\n\n如果 VT 下降、VD 上升、或 f 下降，VA 都會下降。  \nVA 下降時，CO2 排不出去，所以 PaCO2 會上升。  \nVA 上升時，CO2 排出增加，所以 PaCO2 會下降。\n\n在模型中，我們用正常值當基準：\nVA_normal = (500 - 150) × 15 / 1000 = 5.25 L/min。\n\n如果你調整 VT、VD、f，肺葉大小應該根據 VA 相對於 5.25 L/min 來改變。VA 高於正常，肺葉放大；VA 低於正常，肺葉縮小。"},"alveolar_gas":{"title":"課程 3：Alveolar Gas Equation 與 Oxygenation","keywords":["alveolar gas","pao2","fio2","oxygenation","氧合","吸氧","海拔","altitude","inspired oxygen"],"script":"同學你好，這一單元講 alveolar gas equation 與 oxygenation。\n\n肺泡氧分壓 PAO2 可以用這個式子估計：\n\nPAO2 = FIO2 × (Patm - PH2O) - PaCO2 / R。\n\n這個式子有三個重點。\n\n第一，FIO2 越高，PAO2 越高，所以吸氧可以提高肺泡氧氣。\n\n第二，PaCO2 越高，PAO2 越低。所以 hypoventilation 造成 CO2 retention 時，也會拉低肺泡氧氣。\n\n第三，海拔越高，barometric pressure 越低，因此 inspired PO2 與 PAO2 都會下降。\n\n所以 oxygenation problem 和 ventilation problem 不能混在一起。提高 FIO2 可以改善 oxygenation，但不會直接修正 PaCO2。PaCO2 主要還是由 alveolar ventilation 決定。"},"perfusion":{"title":"課程 4：Perfusion、Cardiac Output 與 Mixed Venous Blood","keywords":["perfusion","灌流","cardiac output","qt","mixed venous","svo2","pvo2","心輸出"],"script":"同學你好，這一單元講 perfusion、cardiac output 與 mixed venous blood。\n\nPerfusion 是血流到達肺泡周圍微血管的量。  \n如果通氣存在，但血流不足，就會形成 high V/Q，嚴重時接近 dead space。\n\nCardiac output 影響全身 oxygen delivery。  \noxygen delivery 約等於 cardiac output 乘上 arterial oxygen content。\n\n如果 cardiac output 下降，PaO2 和 PaCO2 不一定立刻大幅異常。  \n但是 mixed venous blood 會很敏感。\n\n因為組織仍然需要氧氣，當血流量下降時，每單位血液會被抽取更多氧氣。  \n所以 mixed venous PO2 和 SvO2 會下降。\n\n因此，mixed venous values 可反映組織 oxygen delivery 是否足夠。"},"normal_vq":{"title":"課程 5：正常 V/Q Gradient：Apex 與 Base","keywords":["apex","base","gradient","肺尖","肺底","上肺","下肺","正常 v/q"],"script":"同學你好，這一單元講正常 V/Q gradient。\n\nV/Q ratio 是 ventilation 除以 perfusion。\n\n直立姿勢下，apex 與 base 的 ventilation 和 perfusion 都不同。\n\nApex 的 ventilation 較少，perfusion 也較少。  \n但是 perfusion 下降得更明顯，所以 apex 的 V/Q ratio 較高。\n\nBase 的 ventilation 較多，perfusion 也較多。  \n但是 perfusion 增加得更明顯，所以 base 的 V/Q ratio 較低。\n\n所以正常肺也不是每一區 V/Q 都完全相同。  \nApex 偏 high V/Q，base 偏 low V/Q。\n\n但要注意：apex 的 V/Q ratio 比較高，不代表 apex 對總氣體交換貢獻最大。Base 因為總 ventilation 與 perfusion 較多，通常對整體 gas exchange 貢獻更多。"},"low_vq":{"title":"課程 6：Low V/Q 與 Shunt-like Physiology","keywords":["low v/q","low vq","shunt-like","低 v/q","低通氣","pneumonia","asthma","copd","airway obstruction"],"script":"同學你好，這一單元講 low V/Q 與 shunt-like physiology。\n\nLow V/Q 的意思是：ventilation 相對不足，但是 perfusion 仍然存在。\n\n可以用一句話記：\n有血，但是氣不夠。\n\n因為血流還在，但肺泡通氣不足，所以血液經過肺泡後，氧氣沒有補夠，二氧化碳也不容易排乾淨。\n\n因此 low V/Q 區域通常會出現：\nPO2 下降、PCO2 上升、oxygen content 下降。\n\n如果 low V/Q 很嚴重，接近完全沒有通氣但仍有血流，就會變成 shunt-like，甚至接近 true shunt。\n\n常見例子包括 pneumonia、asthma、COPD 或局部 airway obstruction。\n\n所以在模型上，low V/Q 或 shunt-like 應該偏向通氣不足的病灶區，常呈現中下肺葉或病灶區縮小，而不是 high V/Q 的上肺葉變化。"},"high_vq":{"title":"課程 7：High V/Q、Dead Space 與 Pulmonary Embolism","keywords":["high v/q","high vq","dead space","pe","pulmonary embolism","肺栓塞","有氣沒血"],"script":"同學你好，這一單元講 high V/Q、dead space 與 pulmonary embolism。\n\nHigh V/Q 的意思是：ventilation 相對保留，但是 perfusion 不足。\n\n可以用一句話記：\n有氣，但是血不夠。\n\n如果 perfusion 非常低，這個區域就接近 dead space。  \n空氣進入肺泡，但沒有足夠血流參與氣體交換。\n\nPulmonary embolism 是典型例子。  \nPE 會阻斷肺血流，使受影響區域 perfusion 下降。  \nventilation 相對還在，所以 V/Q ratio 上升，形成 high V/Q 或 dead-space-like physiology。\n\n因此 dead-space-like 不應該被畫在下肺葉 shunt-like 區域。它應該偏向通氣存在但灌流不足的區域，模型上用上肺葉或局部 high V/Q 區域表示。"},"shunt":{"title":"課程 8：True Shunt 與 Shunt Equation","keywords":["true shunt","shunt equation","qs/qt","分流","有血沒氣","高氧反應"],"script":"同學你好，這一單元講 true shunt 與 shunt equation。\n\nShunt 的意思是有血流，但是沒有有效通氣。\n\n可以用一句話記：\n有血，沒氣。\n\nShunted blood 沒有接觸到通氣肺泡，所以血液無法被氧合，就直接混入 arterial blood。  \n因此 shunt 會使 PaO2 明顯下降。\n\nShunt 對提高 FIO2 的反應通常比較差。  \n因為沒有接觸肺泡的血流，即使外界氧氣提高，也不能直接被氧合。\n\nShunt equation 是：\nQS/QT = (Cco2 - Cao2) / (Cco2 - Cvo2)。\n\n這裡用的是 oxygen content，而不是只看 PO2。因為血液攜氧主要取決於 hemoglobin-bound oxygen。"},"diffusion":{"title":"課程 9：Diffusion Limitation 與 A-a Gradient","keywords":["diffusion","dl","dlo2","a-a","擴散","diffusing capacity","運動"],"script":"同學你好，這一單元講 diffusion limitation 與 A-a gradient。\n\nDiffusion 是氣體穿過 alveolar-capillary membrane 的過程。\n\n氧氣要從肺泡進入血液，二氧化碳要從血液回到肺泡。\n\n當 diffusing capacity 下降時，氧氣無法充分進入血液，所以 PaO2 下降。  \n但是 PAO2 可能仍然相對正常，因此 A-a O2 difference 會增加。\n\nExercise 會讓 diffusion limitation 更明顯。  \n因為運動時 oxygen uptake 增加，而且血液通過 pulmonary capillary 的有效交換時間相對變短。\n\n提高 FIO2 可以改善 diffusion limitation，因為它會增加肺泡和血液之間的 oxygen partial pressure gradient。\n\nCO2 通常比較不受 diffusion limitation 影響，因為 CO2 的擴散能力比 O2 更強。"},"oxygen_content":{"title":"課程 10：Hemoglobin、CaO2 與 Oxygen Delivery","keywords":["hemoglobin","hb","cao2","oxygen content","oxygen delivery","貧血","anemia","sao2"],"script":"同學你好，這一單元講 hemoglobin、CaO2 與 oxygen delivery。\n\nPaO2 是溶解在血漿中的 oxygen partial pressure。  \n它不是血液總氧含量。\n\n血液總氧含量 CaO2 主要由 hemoglobin 和 SaO2 決定：\n\nCaO2 ≈ 1.34 × Hb × SaO2 + 0.003 × PaO2。\n\n所以 anemia 時，PaO2 可以正常，SaO2 也可以正常。  \n但是 Hb 下降會讓 CaO2 下降。\n\nOxygen delivery 約等於 cardiac output × CaO2。\n\n因此，Hb 下降或 cardiac output 下降，都可能造成 tissue hypoxia。這也是為什麼只看 PaO2 有時候會低估病人的氧輸送問題。"},"integrated_disease":{"title":"課程 11：疾病整合：PE、Pneumonia、Asthma、COPD","keywords":["disease","疾病","pneumonia","asthma","copd","pe","肺炎","氣喘","肺阻塞"],"script":"同學你好，這一單元整合 PE、pneumonia、asthma、COPD 與 V/Q physiology。\n\nPulmonary embolism，簡稱 PE，主要問題是 perfusion 下降。  \nventilation 相對保留，所以 V/Q 上升，偏 high V/Q 或 dead-space-like。\n\nPneumonia 主要問題是肺泡發炎、滲出物或 consolidation。  \n這會使 ventilation 下降，但 perfusion 仍可能存在，所以偏 low V/Q 或 shunt-like。\n\nAsthma 和 COPD 常見 airway obstruction。  \n氣道阻塞會讓部分肺區 ventilation 下降，因此常見 regional low V/Q。\n\nCOPD 還可能合併肺泡破壞、dead space 增加與 gas exchange efficiency 下降，所以它可能是 mixed pattern。\n\n總結：\nPE：Q 下降，V/Q 上升，偏 dead space。  \nPneumonia：V 下降，V/Q 下降，偏 shunt-like。  \nAsthma / COPD：airway obstruction 造成 regional low V/Q，也可能混合 high V/Q。"}};
  const QUESTIONS = [{"title":"Gas Exchange 架構","question":"下列哪一組最能完整描述 gas exchange 的四個主要層次？","choices":["ventilation、perfusion、diffusion、oxygen content","只有 ventilation","只有 PaO2 與 PaCO2","只有 hemoglobin"],"answer":0,"explanation":"Gas exchange 要同時看 ventilation、perfusion、diffusion 與 oxygen content。"},{"title":"Alveolar ventilation 公式","question":"Alveolar ventilation 的公式是？","choices":["VE = VT × f","VA = (VT - VD) × f","CaO2 = Hb × QT","QS/QT = PaO2 / PaCO2"],"answer":1,"explanation":"VA = (VT - VD) × f。"},{"title":"Hypoventilation","question":"VA 下降時，PaCO2 通常會如何？","choices":["下降","不變","上升","一定為 0"],"answer":2,"explanation":"VA 下降時 CO2 排出不足，PaCO2 上升。"},{"title":"Alveolar gas equation","question":"PAO2 = FIO2 × (Patm - PH2O) - PaCO2 / R 主要用來理解什麼？","choices":["心輸出量","血紅素含量","分流比例","肺泡氧分壓"],"answer":3,"explanation":"Alveolar gas equation 用來估計 PAO2。"},{"title":"Apex/Base","question":"直立姿勢下 apex 的 V/Q ratio 通常為何較高？","choices":["因為 perfusion 下降比 ventilation 更明顯","因為 apex 完全沒有氣","因為 base 沒有血","因為 Hb 在 apex 較高"],"answer":0,"explanation":"Apex 的 V 和 Q 都較低，但 Q 下降更明顯，所以 V/Q 較高。"},{"title":"Low V/Q","question":"Low V/Q 最接近哪一種直覺描述？","choices":["有氣沒血","有血但氣不夠","沒有血也沒有氣","只有 hemoglobin 問題"],"answer":1,"explanation":"Low V/Q 是 ventilation 相對不足，但 perfusion 仍存在。"},{"title":"High V/Q","question":"High V/Q 最接近哪一種狀態？","choices":["true shunt","low V/Q","dead-space-like","anemia"],"answer":2,"explanation":"High V/Q 是 ventilation 相對保留，但 perfusion 不足，偏 dead-space-like。"},{"title":"True shunt","question":"True shunt 的核心是？","choices":["有氣沒血","Hb 不足","擴散能力增加","有血沒氣"],"answer":3,"explanation":"Shunt 是有血流但沒有有效通氣。"},{"title":"PE","question":"Pulmonary embolism 主要造成什麼型態？","choices":["High V/Q / dead-space-like","Low V/Q only","True shunt only","Pure anemia"],"answer":0,"explanation":"PE 阻斷血流，使 perfusion 下降，形成 high V/Q。"},{"title":"Pneumonia","question":"Pneumonia 常見的 V/Q 變化是？","choices":["High V/Q only","Low V/Q 或 shunt-like","只有 dead space","只有 Hb 下降"],"answer":1,"explanation":"Pneumonia 使 ventilation 下降但 perfusion 仍可能存在，偏 low V/Q。"},{"title":"Diffusion limitation","question":"Diffusion limitation 最典型會造成？","choices":["PaO2 下降且 A-a gradient 增加","PaCO2 一定為 0","SaO2 一定為 100%","QT 一定上升"],"answer":0,"explanation":"Diffusion limitation 造成氧氣進入血液受限，PaO2 下降，A-a gradient 增加。"},{"title":"Anemia","question":"Anemia 時哪一項最正確？","choices":["PaO2 一定為 0","SaO2 一定為 0","PaO2 可正常，但 CaO2 下降","PaCO2 一定上升"],"answer":2,"explanation":"貧血時 Hb 下降，CaO2 下降，但 PaO2 可正常。"}];
  const DEFAULTS={VT:500,VD:150,f:15,FIO2:.21,Altitude:0,VO2:300,R:.8,Hb:15,QT:5.5,Shunt:0,DLO2:32,LowVA:50,LowQ:50,HighVA:50,HighQ:50};
  let labMode='No V/Q mismatch', currentQ=0, lessonTimer=null, answerTimer=null, thinkTimer=null, activeDisease=null;
  const $=id=>document.getElementById(id);
  const qa=s=>Array.from(document.querySelectorAll(s));
  const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
  const fmt=(x,d=2)=>Number.isFinite(x)?x.toFixed(d):'—';
  function speak(text){try{if('speechSynthesis'in window){speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(text);u.lang='zh-TW';u.rate=parseFloat($('rateRange')?.value||'1')||1;speechSynthesis.speak(u)}}catch(e){}}
  function type(el,text,delay=28){if(!el)return;clearInterval(lessonTimer);let i=0;el.textContent='';lessonTimer=setInterval(()=>{i++;el.textContent=text.slice(0,i);el.scrollTop=el.scrollHeight;if(i>=text.length)clearInterval(lessonTimer)},delay)}
  function currentLesson(){const sel=$('lessonSelect');const k=sel&&LESSONS[sel.value]?sel.value:Object.keys(LESSONS)[0];return {key:k,item:LESSONS[k]};}
  function initTabs(){
    const map=[['lessonTab','lessonPanel'],['caseTab','casePanel'],['modelTab','modelPanel']];
    map.forEach(([b,p])=>{const btn=$(b),pan=$(p);if(!btn||!pan)return;btn.onclick=()=>{map.forEach(([bb,pp])=>{$(bb)?.classList.remove('active');$(pp)?.classList.remove('active')});btn.classList.add('active');pan.classList.add('active');document.body.classList.toggle('v150-model-active',p==='modelPanel');document.body.classList.toggle('v150-case-active',p==='casePanel');};});
  }
  function initLessons(){
    const sel=$('lessonSelect'); if(!sel) return;
    sel.innerHTML=Object.entries(LESSONS).map(([k,v])=>'<option value="'+k+'">'+v.title+'</option>').join('');
    sel.onchange=()=>{$('lessonText').textContent='目前選擇：'+currentLesson().item.title+'。請按「老師開始講課」。';};
    $('lessonText').textContent='目前選擇：'+currentLesson().item.title+'。請按「老師開始講課」。';
    $('startLessonBtn').onclick=e=>{e.preventDefault();const item=currentLesson().item;type($('lessonText'),item.script,30);speak(item.script);$('status').textContent='狀態：老師講解中 - '+item.title;};
    $('pauseLessonBtn').onclick=e=>{e.preventDefault();try{speechSynthesis.pause()}catch(x){}};
    $('resumeLessonBtn').onclick=e=>{e.preventDefault();try{speechSynthesis.resume()}catch(x){}};
    $('stopLessonBtn').onclick=e=>{e.preventDefault();clearInterval(lessonTimer);try{speechSynthesis.cancel()}catch(x){}};
    $('repeatBtn').onclick=e=>{e.preventDefault();speak(currentLesson().item.script);};
    $('clearBtn').onclick=e=>{e.preventDefault();$('studentQuestion').textContent='';$('teacherAnswer').textContent='AI 老師回答會顯示在這裡。';};
    $('submitTypedQuestionBtn').onclick=e=>{e.preventDefault();submitQA();};
  }
  function normalizeQuestionText(text){
    return String(text||'')
      .replace(/學生問的問題會顯示在這裡。?/g,'')
      .replace(/\s+/g,' ')
      .trim()
      .toLowerCase();
  }
  function allTopicKeywords(){
    const extra = ['v/q','vq','v q','ventilation','perfusion','diffusion','oxygen','oxygenation','gas exchange','abg','pao2','paco2','paco2','pa o2','pa co2','fio2','fio₂','co2','o2','a-a','gradient','shunt','dead space','alveolar','hemoglobin','hb','cao2','sao2','svo2','cardiac output','pulmonary embolism','pe','pneumonia','asthma','copd','apex','base','肺','呼吸','通氣','灌流','擴散','氧','血氧','二氧化碳','血氣','肺泡','分流','死腔','血紅素','貧血','肺栓塞','肺炎','氣喘','肺阻塞','肺尖','肺底','低血氧','潮氣容積','呼吸頻率','氣體交換'];
    const set = new Set(extra.map(x=>String(x).toLowerCase()));
    Object.values(LESSONS).forEach(v=>(v.keywords||[]).forEach(k=>set.add(String(k).toLowerCase())));
    return Array.from(set);
  }
  function isGibberishOrTooVague(raw){
    const q = String(raw||'').replace(/\s+/g,'').trim();
    if(!q || q.includes('學生問的問題')) return true;
    // repeated filler/noise such as 餵餵餵、哈哈哈、aaaaa
    const compact = q.replace(/[，。！？,.!?]/g,'');
    if(compact.length < 3) return true;
    const repeated = /(.)\1{4,}/.test(compact);
    const onlyFiller = /^(餵|喂|欸|呃|嗯|啊|哈|嘿|hi|hello|test|測試)+$/i.test(compact);
    return repeated || onlyFiller;
  }
  function analyzeQuestionRelevance(text){
    const t = normalizeQuestionText(text);
    if(isGibberishOrTooVague(text)) return {relevant:false, reason:'empty_or_noise'};
    const topicHits = allTopicKeywords().filter(k => k && t.includes(k));
    const adminWords = ['目前','現在','這頁','這個系統','這個模式','怎麼用','如何使用','開始講課','語音','錄音','麥克風','問答模式','情境題','課程'];
    const adminHit = adminWords.some(w => t.includes(w.toLowerCase()));
    if(topicHits.length > 0) return {relevant:true, reason:'topic', hits:topicHits};
    if(adminHit) return {relevant:false, reason:'admin_vague'};
    return {relevant:false, reason:'off_topic'};
  }
  function lessonByQuestion(text){
    const t=normalizeQuestionText(text);
    let best = null, bestScore = 0;
    for(const [k,v] of Object.entries(LESSONS)){
      let score = 0;
      (v.keywords||[]).forEach(w=>{ if(t.includes(String(w).toLowerCase())) score += 1; });
      if(score > bestScore){ best = {key:k,item:v,score}; bestScore = score; }
    }
    if(best) return best;
    return currentLesson();
  }
  function offTopicReply(q, reason){
    if(reason === 'empty_or_noise'){
      return '我目前無法判斷你的問題內容。請輸入一個明確、跟本課有關的問題，例如：「low V/Q 是什麼？」、「肺栓塞為什麼是 dead space-like？」或「PaCO2 為什麼會上升？」';
    }
    if(reason === 'admin_vague'){
      return '你目前在「老師講解 / 自由問答」模式。這裡只回答目前呼吸生理課程相關問題。請把問題寫得更具體，例如問 ventilation、perfusion、V/Q ratio、shunt、dead space、diffusion、PaO2、PaCO2 或 oxygen content。';
    }
    return '這個問題和目前課程主題不相關，因此我不會硬套課程內容回答。請改問 gas exchange、V/Q ratio、ventilation、perfusion、shunt、dead space、diffusion、PaO2、PaCO2、hemoglobin 或相關疾病案例。';
  }
  function answerFor(q){
    if(!q||q.includes('學生問的問題')) return '請先在學生問題區輸入問題。';
    const rel = analyzeQuestionRelevance(q);
    if(!rel.relevant) return offTopicReply(q, rel.reason);
    const {key,item}=lessonByQuestion(q); let direct='';
    if(key==='low_vq') direct='Low V/Q 是 ventilation 相對不足但 perfusion 仍在，所以是「有血但氣不夠」，偏 shunt-like。';
    else if(key==='high_vq') direct='High V/Q 是 ventilation 相對保留但 perfusion 不足，所以是「有氣但血不夠」，偏 dead-space-like。';
    else if(key==='ventilation') direct='VT、VD、f 共同決定 VA = (VT - VD) × f。VA 下降會使 PaCO2 上升。';
    else if(key==='alveolar_gas') direct='PAO2 由 FIO2、barometric pressure、PaCO2 和 R 決定。吸氧提高 PAO2，但不直接降低 PaCO2。';
    else if(key==='normal_vq') direct='直立時 apex V/Q 較高、base V/Q 較低，因為 perfusion 的重力梯度比 ventilation 更明顯。';
    else if(key==='shunt') direct='True shunt 是有血沒氣，PaO2 下降明顯，且對提高 FIO2 反應較差。';
    else if(key==='diffusion') direct='Diffusion limitation 使 PaO2 下降、A-a gradient 增加，運動時更明顯。';
    else if(key==='perfusion') direct='Cardiac output 下降時 oxygen delivery 下降，mixed venous PO2/SvO2 會下降。';
    else if(key==='oxygen_content') direct='PaO2 不等於 CaO2。貧血時 PaO2 可正常，但 Hb 減少會使 CaO2 下降。';
    else if(key==='integrated_disease') direct='PE 偏 high V/Q；pneumonia 偏 low V/Q；asthma/COPD 常見 regional low V/Q，也可能混合。';
    else direct='Gas exchange 要同時看 ventilation、perfusion、diffusion 與 oxygen content。';
    return '我判斷這題屬於：「'+item.title+'」。\n\n'+direct+'\n\n補充：如果你要問其他課程，請直接提到關鍵字，例如 shunt、dead space、diffusion、PaO2、PaCO2 或 hemoglobin。';
  }
  function submitQA(){
    const q=($('studentQuestion')?.textContent||'').trim(), ans=answerFor(q), box=$('teacherAnswer');
    clearInterval(answerTimer);clearInterval(thinkTimer);let dots=0;box.textContent='AI 老師思考中';
    thinkTimer=setInterval(()=>{dots=(dots+1)%4;box.textContent='AI 老師思考中'+'.'.repeat(dots)},250);
    setTimeout(()=>{clearInterval(thinkTimer);let i=0;box.textContent='';speak(ans);answerTimer=setInterval(()=>{i++;box.textContent=ans.slice(0,i);box.scrollTop=box.scrollHeight;if(i>=ans.length)clearInterval(answerTimer)},28)},650);
  }
  function num(id,f,maxv){const el=$(id);let n=parseFloat(el?.value);if(!Number.isFinite(n))n=f;if(n<0)n=0;if(Number.isFinite(maxv))n=Math.min(n,maxv);if(el)el.value=n;return n;}
  function buildModel(){
    const panel=$('modelPanel'), row=$('vqConditionRow'); if(!panel||$('v37Wrap'))return;
    const wrap=document.createElement('div');wrap.id='v37Wrap';
    wrap.innerHTML='<div class="v37-lab-card"><div class="v37-title">完整數值輸入區：Lung Lab 參數計算 → 原本雙側肺 V/Q 視覺模型</div><div class="v37-sub">調整參數後按 Calculate。右側完整列出數值，並更新下方肺模型。</div><div class="v37-mode-row"><button id="v37NoBtn" class="active">No V/Q mismatch</button><button id="v37MisBtn">V/Q mismatch</button><button id="v37PEBtn">Pulmonary Embolism</button><button id="v37PneuBtn">Pneumonia</button><button id="v37ShuntBtn">Shunt-like</button><button id="v37DeadBtn">Dead Space-like</button></div><div class="v37-lab-grid"><div><div class="v37-input-grid">'+
    ['VT','VD','f','FIO2','Altitude','VO2','R','Hb','QT','Shunt','DLO2','LowVA','LowQ','HighVA','HighQ'].map(k=>'<div class="v37-input-row"><label>'+k+'</label><input id="v37'+k+'" type="number" step="any" value="'+DEFAULTS[k]+'"></div>').join('')+
    '</div><div class="v37-actions"><button id="v37CalcBtn">Calculate 並更新肺模型</button><button id="v37ResetBtn">Reset normal</button></div></div><div id="v37Result" class="v37-result">尚未計算。請調整參數後按 Calculate。</div></div></div>';
    (row||panel.firstElementChild).parentNode.insertBefore(wrap,row||panel.firstElementChild);
    $('v37NoBtn').onclick=e=>{e.preventDefault();labMode='No V/Q mismatch';activeDisease=null;setModeButtons();};
    $('v37MisBtn').onclick=e=>{e.preventDefault();labMode='V/Q mismatch';activeDisease=null;setModeButtons();};
    $('v37CalcBtn').onclick=e=>{e.preventDefault();activeDisease=null;calculate();setModeButtons();};
    $('v37ResetBtn').onclick=e=>{e.preventDefault();resetModel();};
    $('v37PEBtn').onclick=e=>{e.preventDefault();showDisease('pe');};
    $('v37PneuBtn').onclick=e=>{e.preventDefault();showDisease('pneumonia');};
    $('v37ShuntBtn').onclick=e=>{e.preventDefault();showDisease('shunt');};
    $('v37DeadBtn').onclick=e=>{e.preventDefault();showDisease('deadspace');};
  }
  function setModeButtons(){['v37NoBtn','v37MisBtn','v37PEBtn','v37PneuBtn','v37ShuntBtn','v37DeadBtn'].forEach(id=>$(id)?.classList.remove('active')); if(activeDisease==='pe')$('v37PEBtn')?.classList.add('active'); else if(activeDisease==='pneumonia')$('v37PneuBtn')?.classList.add('active'); else if(activeDisease==='shunt')$('v37ShuntBtn')?.classList.add('active'); else if(activeDisease==='deadspace')$('v37DeadBtn')?.classList.add('active'); else (labMode==='V/Q mismatch'?$('v37MisBtn'):$('v37NoBtn'))?.classList.add('active');}
  function pb(alt){return 760*Math.exp(-alt/7000)}; function sat(po2){return clamp(100/(1+Math.pow(26.8/Math.max(po2,1),2.7)),0,99.8)}; function o2content(po2,hb){return 1.34*hb*(sat(po2)/100)+0.003*Math.max(po2,0)}; function co2content(pco2){return 48+pco2*.20}; function ph(pco2){return clamp(7.40-Math.log(Math.max(pco2,1)/40)/Math.log(10)*.65,6.65,7.65)}
  function read(){return {VT:num('v37VT',500),VD:num('v37VD',150),f:num('v37f',15),FIO2:num('v37FIO2',.21),Altitude:num('v37Altitude',0),VO2:num('v37VO2',300),R:num('v37R',.8),Hb:num('v37Hb',15),QT:num('v37QT',5.5),Shunt:num('v37Shunt',0,1),DLO2:num('v37DLO2',32),LowVA:num('v37LowVA',50,100),LowQ:num('v37LowQ',50,100),HighVA:num('v37HighVA',50,100),HighQ:num('v37HighQ',50,100)}}
  function compute(){const s=read(),Pb=pb(s.Altitude),VCO2=s.VO2*s.R,insp=s.FIO2*Math.max(Pb-47,1),VA=Math.max((s.VT-s.VD)*s.f/1000,.01),VE=s.VT*s.f/1000,PACO2=(VCO2*.863)/VA,PAO2=insp-PACO2/Math.max(s.R,.01);const lr=(labMode==='V/Q mismatch'?s.LowVA/s.LowQ:1),hr=(labMode==='V/Q mismatch'?s.HighVA/s.HighQ:1);let artPO2=PAO2-2-(s.DLO2<32?(32-s.DLO2)*1.15:0)-s.Shunt*55,artPCO2=PACO2+s.Shunt*8;if(labMode==='V/Q mismatch'){const lowPO2=PAO2-30*(1/Math.max(lr,.2)-1),highPO2=PAO2+22*(hr-1);artPO2=(lowPO2*s.LowQ+highPO2*s.HighQ)/Math.max(s.LowQ+s.HighQ,1)-s.Shunt*45;artPCO2=(PACO2*(1.05/Math.max(lr,.12))*s.LowQ+PACO2*(.85/Math.max(hr,.25))*s.HighQ)/Math.max(s.LowQ+s.HighQ,1)+s.Shunt*8;}return {s,Pb,insp,VA,VE,PACO2,PAO2,Vrel:clamp(VA/5.25,.08,2.6),Qrel:clamp(s.QT/5.5,.1,2.6),ratio:labMode==='V/Q mismatch'?clamp((lr+hr)/2,.05,8):clamp((VA/5.25)/Math.max((s.QT/5.5)*(1-s.Shunt),.05),.05,8),artPO2,artPCO2,lr,hr};}
  function tr(a,b,u){const neg=typeof b==='number'&&b<0;return '<tr><td>'+a+'</td><td class="'+(neg?'v37-neg':'')+'">'+(typeof b==='number'?fmt(b,2):b)+' '+(u||'')+'</td></tr>'}
  function calculate(){const d=compute();const s=d.s;let html='<div class="v37-output"><div class="v37-block"><div class="v37-block-title">Input Variables</div><table class="v37-table"><tbody>'+Object.keys(s).map(k=>tr(k,s[k],'')).join('')+'</tbody></table></div>';html+='<div class="v37-block"><div class="v37-block-title">General</div><table class="v37-table"><tbody>'+tr('Barometric pressure',d.Pb,'mmHg')+tr('Minute Vent.',d.VE,'L/min')+tr('Alveolar Vent.',d.VA,'L/min')+tr('Alveolar PCO2',d.PACO2,'mmHg')+tr('Inspired PO2',d.insp,'mmHg')+tr('Alveolar PO2',d.PAO2,'mmHg')+tr('V/Q ratio',d.ratio,'')+'</tbody></table></div>';html+='<div class="v37-block"><div class="v37-block-title">Arterial Blood</div><table class="v37-table"><tbody>'+tr('PCO2',d.artPCO2,'mmHg')+tr('CO2 Content',co2content(d.artPCO2),'ml/dl')+tr('pH',ph(d.artPCO2),'')+tr('PO2',d.artPO2,'mmHg')+tr('O2 Saturation',sat(d.artPO2),'%')+tr('O2 Content',o2content(d.artPO2,s.Hb),'ml/dl')+tr('A-a O2 Diff',d.PAO2-d.artPO2,'mmHg')+'</tbody></table></div>';html+='</div><div class="v37-interpret">目前模式：'+labMode+'<br><br>VA = (VT - VD) × f = '+fmt(d.VA)+' L/min。以 normal VA 5.25 L/min 為基準，肺葉依此放大或縮小。</div>';$('v37Result').innerHTML=html;updateLung(d);}
  function setRegion(id,cls,scale){const el=$(id);if(!el)return;el.removeAttribute('transform');el.style.transform='scale('+scale+')';el.style.transformBox='fill-box';el.style.transformOrigin='center center';if(cls==='high')el.setAttribute('class','vq-lung-region vq-region-high');else if(cls==='low')el.setAttribute('class','vq-lung-region vq-region-low');else el.setAttribute('class','vq-lung-region vq-region-normal');}
  function updateLung(d){const scale=clamp(d.Vrel,.45,1.45);let apex=labMode==='No V/Q mismatch'?'high':'normal',mid='normal',base=labMode==='No V/Q mismatch'?'low':'normal'; if(labMode==='V/Q mismatch'){if(d.hr>1.25)apex='high';if(d.lr<.8||d.s.Shunt>.15)base='low';if(d.s.Shunt>.2)mid='low';}['leftApex','rightApex'].forEach(id=>setRegion(id,apex,scale));['leftMiddle','rightMiddle'].forEach(id=>setRegion(id,mid,scale));['leftBase','rightBase'].forEach(id=>setRegion(id,base,scale));$('zoomTitle').textContent=labMode+' - Calculated';$('ventBar').style.width=clamp(d.Vrel*50,5,100)+'%';$('perfBar').style.width=clamp(d.Qrel*50,5,100)+'%';$('vqBar').style.width=clamp(d.ratio*30,5,100)+'%';$('ventText').textContent='Ventilation '+Math.round(clamp(d.Vrel*50,1,100))+'/100';$('perfText').textContent='Perfusion '+Math.round(clamp(d.Qrel*50,1,100))+'/100';$('vqText').textContent='V/Q ratio '+fmt(d.ratio,2);}
  function showDisease(k){activeDisease=k;setModeButtons();try{ if(typeof renderVQCondition==='function')renderVQCondition(k)}catch(e){}$('v37Result').innerHTML='<div class="v37-interpret">目前顯示疾病模型：'+k+'。疾病模型獨立於數值計算；要計算請按 Calculate。</div>';}
  function resetModel(){Object.entries(DEFAULTS).forEach(([k,v])=>{const el=$('v37'+k);if(el)el.value=v});qa('.vq-lung-region').forEach(el=>{el.style.transform='';el.removeAttribute('transform')});labMode='No V/Q mismatch';activeDisease=null;setModeButtons();$('v37Result').textContent='已 Reset normal。請調整參數後按 Calculate。';}
  function initCases(){const p=$('casePanel');if(!p)return;p.innerHTML='<div class="section-label">COMPLETE CASE QUESTIONS</div><div class="v37-case-card"><div class="v37-case-top"><select id="v37CaseSelect"></select><button id="v37NextBtn" class="secondary">下一題</button></div><div id="v37Question" class="v37-question"></div><div id="v37Choices"></div><div class="section-label" style="margin-top:14px;">AI FEEDBACK</div><div id="v37Feedback" class="dialog-box answer-box v37-feedback">請選擇答案。</div></div>';$('v37CaseSelect').onchange=()=>{currentQ=Number($('v37CaseSelect').value)||0;renderCase()};$('v37NextBtn').onclick=e=>{e.preventDefault();currentQ=(currentQ+1)%QUESTIONS.length;renderCase()};renderCase();}
  function renderCase(){const sel=$('v37CaseSelect');sel.innerHTML=QUESTIONS.map((q,i)=>'<option value="'+i+'">'+(i+1)+'. '+q.title+'</option>').join('');sel.value=currentQ;const item=QUESTIONS[currentQ];$('v37Question').textContent=item.question;$('v37Choices').innerHTML=item.choices.map((c,i)=>'<button class="v37-choice" data-i="'+i+'">'+String.fromCharCode(65+i)+'. '+c+'</button>').join('');qa('.v37-choice').forEach(b=>b.onclick=()=>choose(Number(b.dataset.i)));}
  function choose(i){const item=QUESTIONS[currentQ],ok=i===item.answer;qa('.v37-choice').forEach(b=>{const idx=Number(b.dataset.i);b.classList.toggle('correct',idx===item.answer);b.classList.toggle('wrong',idx===i&&i!==item.answer)});$('v37Feedback').textContent=(ok?'正確。':'不正確。')+'\\n\\n正解：'+String.fromCharCode(65+item.answer)+'. '+item.choices[item.answer]+'\\n\\n解析：'+item.explanation;}
  function init(){initTabs();initLessons();}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();

} catch (e) {
  console.error('v50 core script error:', e);
  document.addEventListener('DOMContentLoaded', function(){
    var box = document.getElementById('teacherAnswer') || document.body;
    if (box) box.textContent = '系統核心腳本載入時發生錯誤，但畫面已保留。請截圖 Console 錯誤。';
  });
}
