(function(){
  'use strict';

  /* v126: force avatar-role voices to Yating/Zhiwei only.
     Fixes the first lecture utterance using browser default browser default voice.
     This file must load after js/26_realistic_avatar_photo_mouth_sync.js. */

  const ROLE_TO_VOICE = {
    yating: { label: '雅婷 Yating｜女生頭像｜女聲', voiceName: 'Yating' },
    zhiwei: { label: '哲偉 Zhiwei｜男生頭像｜男聲', voiceName: 'Zhiwei' }
  };

  const DEFAULT_ROLE = 'yating';
  const $ = id => document.getElementById(id);

  function getSynth(){ return window.speechSynthesis || null; }

  function getVoices(){
    try{
      const synth = getSynth();
      return synth && synth.getVoices ? (synth.getVoices() || []) : [];
    }catch(_){
      return [];
    }
  }

  function voiceKey(v){
    return ((v && (v.voiceURI || v.name || '')) + '|' + ((v && v.lang) || '')).trim();
  }

  function isAllowedVoice(v){
    const s = ((v && v.name) || '') + ' ' + ((v && v.voiceURI) || '') + ' ' + ((v && v.lang) || '');
    return /Yating|Zhiwei/i.test(s);
  }

  function getRoleKey(){
    const roleSel = $('avatarRoleSelect');
    if(roleSel && ROLE_TO_VOICE[roleSel.value]) return roleSel.value;

    const avatar = $('avatar');
    const dataRole = avatar && avatar.getAttribute('data-avatar-role');
    if(dataRole && ROLE_TO_VOICE[dataRole]) return dataRole;

    const stored = localStorage.getItem('VQ_REAL_AVATAR_ROLE');
    if(stored && ROLE_TO_VOICE[stored]) return stored;

    return DEFAULT_ROLE;
  }

  function getTargetVoice(roleKey){
    const role = ROLE_TO_VOICE[roleKey] || ROLE_TO_VOICE[DEFAULT_ROLE];
    const list = getVoices();
    return list.find(v => new RegExp(role.voiceName, 'i').test((v.name||'') + ' ' + (v.voiceURI||'') + ' ' + (v.lang||''))) || null;
  }

  function applyTargetVoiceToUtterance(u){
    if(!u) return null;
    const roleKey = getRoleKey();
    const target = getTargetVoice(roleKey);
    if(target){
      u.voice = target;
      u.lang = target.lang || 'zh-TW';
      u.rate = 1.0;
      u.pitch = 1.0;
      u.volume = 1.0;
    }else{
      u.lang = 'zh-TW';
      u.rate = 1.0;
      u.pitch = 1.0;
      u.volume = 1.0;
    }
    return target;
  }

  function setStatus(msg){
    const s = $('status');
    if(s) s.textContent = '狀態：' + msg;
  }

  function rebuildVoiceSelect(){
    const sel = $('voiceSelect');
    const list = getVoices();
    if(!sel) return null;

    sel.style.display = 'block';
    sel.style.visibility = 'visible';
    sel.style.opacity = '1';

    const allowed = list.filter(isAllowedVoice);
    const roleKey = getRoleKey();
    const role = ROLE_TO_VOICE[roleKey] || ROLE_TO_VOICE[DEFAULT_ROLE];

    if(!list.length){
      sel.innerHTML = '<option value="">正在準備 Yating / Zhiwei 聲音...</option>';
      return null;
    }

    if(!allowed.length){
      sel.innerHTML = '<option value="">未偵測到 Microsoft Yating / Zhiwei</option>';
      return null;
    }

    const currentTarget = allowed.find(v => new RegExp(role.voiceName, 'i').test((v.name||'') + ' ' + (v.voiceURI||''))) || allowed[0];
    sel.innerHTML = '';
    allowed.forEach(v => {
      const opt = document.createElement('option');
      opt.value = voiceKey(v);
      opt.textContent = (v.name || 'Voice') + ' - ' + (v.lang || '');
      opt.dataset.voiceName = v.name || '';
      opt.dataset.lang = v.lang || '';
      opt.dataset.uri = v.voiceURI || '';
      sel.appendChild(opt);
    });

    const targetKey = voiceKey(currentTarget);
    sel.value = targetKey;
    try{
      localStorage.setItem('vqSelectedVoiceKey', targetKey);
      localStorage.setItem('vqSelectedVoiceText', currentTarget.name + ' - ' + (currentTarget.lang || ''));
    }catch(_){ }

    return currentTarget;
  }

  function enforceRoleAndVoice(){
    const roleKey = getRoleKey();
    const roleSel = $('avatarRoleSelect');
    if(roleSel && ROLE_TO_VOICE[roleKey] && roleSel.value !== roleKey){
      roleSel.value = roleKey;
    }
    return rebuildVoiceSelect();
  }

  function installSpeakGuard(){
    const synth = getSynth();
    if(!synth || synth.__VQ126_FORCE_YATING_ZHIWEI__) return;

    const nativeSpeak = synth.speak.bind(synth);
    synth.speak = function(utterance){
      try{ enforceRoleAndVoice(); }catch(_){ }
      let target = null;
      try{ target = applyTargetVoiceToUtterance(utterance); }catch(_){ }

      // On Chromium/Edge, voices may load after page initialization. Do not let the
      // first lecture fall back to browser default while Yating/Zhiwei is still loading.
      if(!target && utterance && !utterance.__VQ126_FORCE_RETRY_DONE__){
        const tries = Number(utterance.__VQ126_FORCE_TRIES__ || 0);
        if(tries < 14){
          utterance.__VQ126_FORCE_TRIES__ = tries + 1;
          setTimeout(() => {
            try{ synth.speak(utterance); }catch(_){ }
          }, 140);
          return;
        }
        utterance.__VQ126_FORCE_RETRY_DONE__ = '1';
        setStatus('未偵測到 Yating / Zhiwei；請確認 Windows/Edge 已安裝台灣繁中語音。');
      }

      return nativeSpeak(utterance);
    };
    synth.__VQ126_FORCE_YATING_ZHIWEI__ = '1';
  }

  function bindRoleSelect(){
    const roleSel = $('avatarRoleSelect');
    if(!roleSel || roleSel.__VQ126_BOUND__) return;
    roleSel.__VQ126_BOUND__ = '1';
    roleSel.addEventListener('change', () => {
      const roleKey = getRoleKey();
      try{ localStorage.setItem('VQ_REAL_AVATAR_ROLE', roleKey); }catch(_){ }
      setTimeout(() => {
        const v = enforceRoleAndVoice();
        if(v) setStatus('已切換為「' + (ROLE_TO_VOICE[roleKey] && ROLE_TO_VOICE[roleKey].label || roleKey) + '」，聲音已鎖定：' + v.name);
      }, 20);
    }, true);
  }

  function bindBeforeSpeechButtons(){
    ['startLessonBtn','repeatBtn','submitTypedQuestionBtn','submitTypedCaseBtn','avatarRoleSelect','voiceSelect'].forEach(id => {
      const el = $(id);
      if(!el || el.__VQ126_PRE_SPEECH_BOUND__) return;
      el.__VQ126_PRE_SPEECH_BOUND__ = '1';
      el.addEventListener('mousedown', enforceRoleAndVoice, true);
      el.addEventListener('click', () => setTimeout(enforceRoleAndVoice, 10), true);
      el.addEventListener('change', enforceRoleAndVoice, true);
    });
  }

  function init(){
    installSpeakGuard();
    bindRoleSelect();
    bindBeforeSpeechButtons();
    enforceRoleAndVoice();
  }

  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();

  [60, 180, 450, 900, 1600, 2600].forEach(t => setTimeout(init, t));

  try{
    const synth = getSynth();
    if(synth){
      const old = synth.onvoiceschanged;
      synth.onvoiceschanged = function(ev){
        try{ if(typeof old === 'function') old.call(this, ev); }catch(_){ }
        setTimeout(init, 0);
        setTimeout(enforceRoleAndVoice, 80);
      };
    }
  }catch(_){ }

  window.VQ126_FORCE_YATING_ZHIWEI = {
    init,
    enforceRoleAndVoice,
    getRoleKey,
    getTargetVoice
  };
})();
