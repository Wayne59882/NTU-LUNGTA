(function(){
  'use strict';

  // v110 in-place fix: this file remains js/25; no extra JS files are added.
  // It owns lecture start/pause/resume/stop, yellow highlight, and top-mode switch safety stop.
  window.__VQ105_INPLACE_LECTURE_MASTER__ = window.__VQ105_INPLACE_LECTURE_MASTER__ || {active:false, running:false, paused:false};

  const LESSONS_V105 = {"basic": {"title": "課程 1：Gas Exchange 基本架構", "keywords": ["gas exchange", "氣體交換", "基本", "架構", "血氣", "abg"], "script": "同學你好，這一單元我們先建立 gas exchange 的基本架構。\n\n氣體交換不是只看 PaO2 或 PaCO2，而是要同時看四個層次：ventilation、perfusion、diffusion，以及 blood oxygen content。\n\n第一，ventilation 是空氣是否能到達肺泡。  \n第二，perfusion 是血流是否能到達肺泡周圍微血管。  \n第三，diffusion 是氧氣是否能跨過 alveolar-capillary membrane。  \n第四，oxygen content 是血液是否有足夠 hemoglobin 攜帶氧氣。\n\n所以當病人低血氧時，不能直接說一定是肺泡氧氣不足，也不能直接說一定是 hemoglobin 問題。要先判斷問題發生在哪一個環節。\n\n在這份講義裡，後面的每一個主題都可以接回這四個層次。Ventilation 影響 PaCO2 和 PAO2；perfusion 影響 V/Q；diffusion 影響 A-a gradient；hemoglobin 影響 CaO2 和 oxygen delivery。"}, "ventilation": {"title": "課程 2：Ventilation 與 Alveolar Ventilation", "keywords": ["ventilation", "通氣", "alveolar ventilation", "va", "vt", "vd", "frequency", "respiratory rate", "dead space", "潮氣容積", "呼吸頻率"], "script": "同學你好，這一單元講 ventilation 與 alveolar ventilation。\n\nMinute ventilation 是每分鐘總通氣量：\nVE = VT × f。\n\nVT 是 tidal volume，f 是 respiratory frequency。\n\n但是，不是所有進入氣道的空氣都能參與氣體交換。dead space 的空氣不參與肺泡交換。\n\n所以真正影響 PaCO2 的是 alveolar ventilation：\nVA = (VT - VD) × f。\n\n如果 VT 下降、VD 上升、或 f 下降，VA 都會下降。  \nVA 下降時，CO2 排不出去，所以 PaCO2 會上升。  \nVA 上升時，CO2 排出增加，所以 PaCO2 會下降。\n\n在模型中，我們用正常值當基準：\nVA_normal = (500 - 150) × 15 / 1000 = 5.25 L/min。\n\n如果你調整 VT、VD、f，肺葉大小應該根據 VA 相對於 5.25 L/min 來改變。VA 高於正常，肺葉放大；VA 低於正常，肺葉縮小。"}, "alveolar_gas": {"title": "課程 3：Alveolar Gas Equation 與 Oxygenation", "keywords": ["alveolar gas", "pao2", "fio2", "oxygenation", "氧合", "吸氧", "海拔", "altitude", "inspired oxygen"], "script": "同學你好，這一單元講 alveolar gas equation 與 oxygenation。\n\n肺泡氧分壓 PAO2 可以用這個式子估計：\n\nPAO2 = FIO2 × (Patm - PH2O) - PaCO2 / R。\n\n這個式子有三個重點。\n\n第一，FIO2 越高，PAO2 越高，所以吸氧可以提高肺泡氧氣。\n\n第二，PaCO2 越高，PAO2 越低。所以 hypoventilation 造成 CO2 retention 時，也會拉低肺泡氧氣。\n\n第三，海拔越高，barometric pressure 越低，因此 inspired PO2 與 PAO2 都會下降。\n\n所以 oxygenation problem 和 ventilation problem 不能混在一起。提高 FIO2 可以改善 oxygenation，但不會直接修正 PaCO2。PaCO2 主要還是由 alveolar ventilation 決定。"}, "perfusion": {"title": "課程 4：Perfusion、Cardiac Output 與 Mixed Venous Blood", "keywords": ["perfusion", "灌流", "cardiac output", "qt", "mixed venous", "svo2", "pvo2", "心輸出"], "script": "同學你好，這一單元講 perfusion、cardiac output 與 mixed venous blood。\n\nPerfusion 是血流到達肺泡周圍微血管的量。  \n如果通氣存在，但血流不足，就會形成 high V/Q，嚴重時接近 dead space。\n\nCardiac output 影響全身 oxygen delivery。  \noxygen delivery 約等於 cardiac output 乘上 arterial oxygen content。\n\n如果 cardiac output 下降，PaO2 和 PaCO2 不一定立刻大幅異常。  \n但是 mixed venous blood 會很敏感。\n\n因為組織仍然需要氧氣，當血流量下降時，每單位血液會被抽取更多氧氣。  \n所以 mixed venous PO2 和 SvO2 會下降。\n\n因此，mixed venous values 可反映組織 oxygen delivery 是否足夠。"}, "normal_vq": {"title": "課程 5：正常 V/Q Gradient：Apex 與 Base", "keywords": ["apex", "base", "gradient", "肺尖", "肺底", "上肺", "下肺", "正常 v/q"], "script": "同學你好，這一單元講正常 V/Q gradient。\n\nV/Q ratio 是 ventilation 除以 perfusion。\n\n直立姿勢下，apex 與 base 的 ventilation 和 perfusion 都不同。\n\nApex 的 ventilation 較少，perfusion 也較少。  \n但是 perfusion 下降得更明顯，所以 apex 的 V/Q ratio 較高。\n\nBase 的 ventilation 較多，perfusion 也較多。  \n但是 perfusion 增加得更明顯，所以 base 的 V/Q ratio 較低。\n\n所以正常肺也不是每一區 V/Q 都完全相同。  \nApex 偏 high V/Q，base 偏 low V/Q。\n\n但要注意：apex 的 V/Q ratio 比較高，不代表 apex 對總氣體交換貢獻最大。Base 因為總 ventilation 與 perfusion 較多，通常對整體 gas exchange 貢獻更多。"}, "low_vq": {"title": "課程 6：Low V/Q 與 Shunt-like Physiology", "keywords": ["low v/q", "low vq", "shunt-like", "低 v/q", "低通氣", "pneumonia", "asthma", "copd", "airway obstruction"], "script": "同學你好，這一單元講 low V/Q 與 shunt-like physiology。\n\nLow V/Q 的意思是：ventilation 相對不足，但是 perfusion 仍然存在。\n\n可以用一句話記：\n有血，但是氣不夠。\n\n因為血流還在，但肺泡通氣不足，所以血液經過肺泡後，氧氣沒有補夠，二氧化碳也不容易排乾淨。\n\n因此 low V/Q 區域通常會出現：\nPO2 下降、PCO2 上升、oxygen content 下降。\n\n如果 low V/Q 很嚴重，接近完全沒有通氣但仍有血流，就會變成 shunt-like，甚至接近 true shunt。\n\n常見例子包括 pneumonia、asthma、COPD 或局部 airway obstruction。\n\n所以在模型上，low V/Q 或 shunt-like 應該偏向通氣不足的病灶區，常呈現中下肺葉或病灶區縮小，而不是 high V/Q 的上肺葉變化。"}, "high_vq": {"title": "課程 7：High V/Q、Dead Space 與 Pulmonary Embolism", "keywords": ["high v/q", "high vq", "dead space", "pe", "pulmonary embolism", "肺栓塞", "有氣沒血"], "script": "同學你好，這一單元講 high V/Q、dead space 與 pulmonary embolism。\n\nHigh V/Q 的意思是：ventilation 相對保留，但是 perfusion 不足。\n\n可以用一句話記：\n有氣，但是血不夠。\n\n如果 perfusion 非常低，這個區域就接近 dead space。  \n空氣進入肺泡，但沒有足夠血流參與氣體交換。\n\nPulmonary embolism 是典型例子。  \nPE 會阻斷肺血流，使受影響區域 perfusion 下降。  \nventilation 相對還在，所以 V/Q ratio 上升，形成 high V/Q 或 dead-space-like physiology。\n\n因此 dead-space-like 不應該被畫在下肺葉 shunt-like 區域。它應該偏向通氣存在但灌流不足的區域，模型上用上肺葉或局部 high V/Q 區域表示。"}, "shunt": {"title": "課程 8：True Shunt 與 Shunt Equation", "keywords": ["true shunt", "shunt equation", "qs/qt", "分流", "有血沒氣", "高氧反應"], "script": "同學你好，這一單元講 true shunt 與 shunt equation。\n\nShunt 的意思是有血流，但是沒有有效通氣。\n\n可以用一句話記：\n有血，沒氣。\n\nShunted blood 沒有接觸到通氣肺泡，所以血液無法被氧合，就直接混入 arterial blood。  \n因此 shunt 會使 PaO2 明顯下降。\n\nShunt 對提高 FIO2 的反應通常比較差。  \n因為沒有接觸肺泡的血流，即使外界氧氣提高，也不能直接被氧合。\n\nShunt equation 是：\nQS/QT = (Cco2 - Cao2) / (Cco2 - Cvo2)。\n\n這裡用的是 oxygen content，而不是只看 PO2。因為血液攜氧主要取決於 hemoglobin-bound oxygen。"}, "diffusion": {"title": "課程 9：Diffusion Limitation 與 A-a Gradient", "keywords": ["diffusion", "dl", "dlo2", "a-a", "擴散", "diffusing capacity", "運動"], "script": "同學你好，這一單元講 diffusion limitation 與 A-a gradient。\n\nDiffusion 是氣體穿過 alveolar-capillary membrane 的過程。\n\n氧氣要從肺泡進入血液，二氧化碳要從血液回到肺泡。\n\n當 diffusing capacity 下降時，氧氣無法充分進入血液，所以 PaO2 下降。  \n但是 PAO2 可能仍然相對正常，因此 A-a O2 difference 會增加。\n\nExercise 會讓 diffusion limitation 更明顯。  \n因為運動時 oxygen uptake 增加，而且血液通過 pulmonary capillary 的有效交換時間相對變短。\n\n提高 FIO2 可以改善 diffusion limitation，因為它會增加肺泡和血液之間的 oxygen partial pressure gradient。\n\nCO2 通常比較不受 diffusion limitation 影響，因為 CO2 的擴散能力比 O2 更強。"}, "oxygen_content": {"title": "課程 10：Hemoglobin、CaO2 與 Oxygen Delivery", "keywords": ["hemoglobin", "hb", "cao2", "oxygen content", "oxygen delivery", "貧血", "anemia", "sao2"], "script": "同學你好，這一單元講 hemoglobin、CaO2 與 oxygen delivery。\n\nPaO2 是溶解在血漿中的 oxygen partial pressure。  \n它不是血液總氧含量。\n\n血液總氧含量 CaO2 主要由 hemoglobin 和 SaO2 決定：\n\nCaO2 ≈ 1.34 × Hb × SaO2 + 0.003 × PaO2。\n\n所以 anemia 時，PaO2 可以正常，SaO2 也可以正常。  \n但是 Hb 下降會讓 CaO2 下降。\n\nOxygen delivery 約等於 cardiac output × CaO2。\n\n因此，Hb 下降或 cardiac output 下降，都可能造成 tissue hypoxia。這也是為什麼只看 PaO2 有時候會低估病人的氧輸送問題。"}, "integrated_disease": {"title": "課程 11：疾病整合：PE、Pneumonia、Asthma、COPD", "keywords": ["disease", "疾病", "pneumonia", "asthma", "copd", "pe", "肺炎", "氣喘", "肺阻塞"], "script": "同學你好，這一單元整合 PE、pneumonia、asthma、COPD 與 V/Q physiology。\n\nPulmonary embolism，簡稱 PE，主要問題是 perfusion 下降。  \nventilation 相對保留，所以 V/Q 上升，偏 high V/Q 或 dead-space-like。\n\nPneumonia 主要問題是肺泡發炎、滲出物或 consolidation。  \n這會使 ventilation 下降，但 perfusion 仍可能存在，所以偏 low V/Q 或 shunt-like。\n\nAsthma 和 COPD 常見 airway obstruction。  \n氣道阻塞會讓部分肺區 ventilation 下降，因此常見 regional low V/Q。\n\nCOPD 還可能合併肺泡破壞、dead space 增加與 gas exchange efficiency 下降，所以它可能是 mixed pattern。\n\n總結：\nPE：Q 下降，V/Q 上升，偏 dead space。  \nPneumonia：V 下降，V/Q 下降，偏 shunt-like。  \nAsthma / COPD：airway obstruction 造成 regional low V/Q，也可能混合 high V/Q。"}};

  const $ = id => document.getElementById(id);
  const synth = window.speechSynthesis;

  let lessonText = '';
  let lessonIndex = 0;
  let segments = [];
  let currentSegment = -1;
  let lessonTimer = null;
  let lessonUtterance = null;
  let lectureRunning = false;
  let lecturePaused = false;
  let timerBaseIndex = 0;
  let timerStartedAt = 0;
  let timerTotalMs = 10000;
  let boundaryMode = false;
  let mouthTimer = null;
  let mouthCounter = 0;
  let answerUtterance = null;
  let answerText = "";
  let answerIndex = 0;
  let controlTimer = null;
  let installed = false;

  window.__VQ105_INPLACE_LECTURE_MASTER__ = window.__VQ105_INPLACE_LECTURE_MASTER__ || {};

  function clean(s){ return String(s || '').trim(); }

  function setStatus(msg){
    const s = $('status');
    if(s) s.textContent = '狀態：' + msg;
  }

  function selectedVoice(){
    const sel = $('voiceSelect');
    const voices = (synth && synth.getVoices) ? synth.getVoices() : [];
    if(sel){
      const direct = voices[Number(sel.value)];
      if(direct) return direct;
      const optText = sel.selectedIndex >= 0 && sel.options[sel.selectedIndex] ? sel.options[sel.selectedIndex].textContent || '' : '';
      const byText = voices.find(v => optText.includes(v.name || '') && optText.includes(v.lang || ''));
      if(byText) return byText;
    }
    return voices.find(v => /Yating|Taiwan|Traditional|zh-TW|Chinese/i.test((v.name || '') + ' ' + (v.lang || ''))) ||
           voices.find(v => /^zh/i.test(v.lang || '')) ||
           voices[0] || null;
  }

  function rate(){
    const r = parseFloat(($('rateRange') || {}).value || '1');
    return Number.isFinite(r) && r > 0 ? r : 1;
  }

  function pitch(){
    const p = parseFloat(($('pitchRange') || {}).value || '1');
    return Number.isFinite(p) && p > 0 ? p : 1;
  }

  function injectStyles(){
    if(document.getElementById('vq109-lecture-style')) return;
    const st = document.createElement('style');
    st.id = 'vq109-lecture-style';
    st.textContent = `
      #lessonText.vq109-script-box{
        white-space: pre-wrap !important;
        line-height: 1.82 !important;
        overflow-wrap: break-word !important;
        word-break: normal !important;
      }
      #lessonText .vq109-seg{
        border-radius: 8px;
        padding: 1px 3px;
        transition: background-color .18s ease, box-shadow .18s ease;
      }
      #lessonText .vq109-current{
        background: #fff176;
        color: #0f172a;
        box-shadow: 0 0 0 2px rgba(250, 204, 21, .28);
      }
      #lessonText .vq109-done{
        color: #334155;
      }
    `;
    document.head.appendChild(st);
  }

  function mouthEl(){ return document.querySelector('.mouth'); }

  function setMouth(shape){
    const m = mouthEl();
    if(!m) return;
    m.classList.remove('mouth-closed','mouth-small','mouth-open','mouth-wide','mouth-round','mouth-a','mouth-e','mouth-o','mouth-fv');
    m.classList.add(shape || 'mouth-closed');
  }

  function startMouthLoop(kind){
    stopMouthLoop(false);
    document.body.classList.add('speaking');
    const shapes = ['mouth-small','mouth-open','mouth-wide','mouth-round','mouth-open','mouth-small'];
    mouthTimer = setInterval(()=>{
      mouthCounter++;
      let ch = '';
      if(kind === 'lecture' && lessonText){
        ch = lessonText.charAt(Math.min(lessonIndex, lessonText.length - 1)).toLowerCase();
      }else if(kind === 'answer' && answerText){
        ch = answerText.charAt(Math.min(answerIndex, answerText.length - 1)).toLowerCase();
      }
      if(/[ao啊阿哈]/i.test(ch)) setMouth('mouth-a');
      else if(/[ei欸ㄟㄧ一衣]/i.test(ch)) setMouth('mouth-e');
      else if(/[ouㄡㄛㄨ喔哦嗚]/i.test(ch)) setMouth('mouth-o');
      else if(/[bmpㄅㄆㄇ]/i.test(ch)) setMouth('mouth-m');
      else if(/[fv]/i.test(ch)) setMouth('mouth-small');
      else if(/[\s，。！？、,.!?]/i.test(ch)) setMouth('mouth-closed');
      else if(/[aei]/i.test(ch)) setMouth('mouth-wide');
      else if(/[ou]/i.test(ch)) setMouth('mouth-round');
      else if(/[fv]/i.test(ch)) setMouth('mouth-small');
      else setMouth(shapes[mouthCounter % shapes.length]);
    }, Math.max(90, 170 / rate()));
  }

  function stopMouthLoop(close){
    if(mouthTimer) clearInterval(mouthTimer);
    mouthTimer = null;
    document.body.classList.remove('speaking');
    if(close !== false) setMouth('mouth-closed');
  }

  function buildSegments(text){
    const out = [];
    let start = 0;
    for(let i=0;i<text.length;i++){
      const ch = text[i];
      if(ch === '\n'){
        if(i > start) out.push({start, end:i, text:text.slice(start,i)});
        let j = i;
        while(j < text.length && text[j] === '\n') j++;
        out.push({start:i, end:j, text:text.slice(i,j), newline:true});
        start = j;
        i = j - 1;
      }else if(/[。！？!?]/.test(ch)){
        out.push({start, end:i+1, text:text.slice(start,i+1)});
        start = i + 1;
      }
    }
    if(start < text.length) out.push({start, end:text.length, text:text.slice(start)});
    return out.length ? out : [{start:0, end:text.length, text}];
  }

  function renderScript(text){
    const box = $('lessonText');
    if(!box) return;
    injectStyles();
    box.classList.add('vq109-script-box');
    box.innerHTML = '';
    segments = buildSegments(text);
    currentSegment = -1;
    for(let i=0;i<segments.length;i++){
      const seg = segments[i];
      if(seg.newline){
        box.appendChild(document.createTextNode(seg.text));
      }else{
        const span = document.createElement('span');
        span.className = 'vq109-seg';
        span.dataset.i = String(i);
        span.dataset.start = String(seg.start);
        span.dataset.end = String(seg.end);
        span.textContent = seg.text;
        box.appendChild(span);
      }
    }
    box.scrollTop = 0;
  }

  function segmentForIndex(idx){
    if(!segments.length) return -1;
    for(let i=0;i<segments.length;i++){
      const seg = segments[i];
      if(seg.newline) continue;
      if(idx >= seg.start && idx < seg.end) return i;
    }
    for(let i=segments.length-1;i>=0;i--){
      if(!segments[i].newline) return i;
    }
    return -1;
  }

  function updateHighlight(idx){
    const box = $('lessonText');
    if(!box) return;
    lessonIndex = Math.max(0, Math.min(idx, lessonText.length));
    const nextSeg = segmentForIndex(lessonIndex);
    if(nextSeg === currentSegment) return;
    currentSegment = nextSeg;
    const spans = box.querySelectorAll('.vq109-seg');
    spans.forEach(sp => {
      const i = Number(sp.dataset.i);
      sp.classList.toggle('vq109-current', i === currentSegment);
      const end = Number(sp.dataset.end || 0);
      sp.classList.toggle('vq109-done', end < lessonIndex);
    });
    const cur = box.querySelector('.vq109-current');
    if(cur && typeof cur.scrollIntoView === 'function'){
      try{ cur.scrollIntoView({block:'nearest', inline:'nearest'}); }catch(_){ }
    }
  }

  function renderLessonAt(i){
    if(!$('lessonText')) return;
    if(($('lessonText').dataset || {}).vq109Text !== lessonText){
      $('lessonText').dataset.vq109Text = lessonText;
      renderScript(lessonText);
    }
    updateHighlight(i);
  }

  function setBtn(id, disabled){
    const b = $(id);
    if(!b) return;
    b.disabled = !!disabled;
    b.setAttribute('aria-disabled', disabled ? 'true' : 'false');
    b.classList.toggle('vq-control-muted', !!disabled);
    b.style.pointerEvents = disabled ? 'none' : 'auto';
    b.style.opacity = disabled ? '0.38' : '1';
    if(disabled){
      b.classList.remove('active','selected','pressed');
      b.setAttribute('aria-pressed','false');
      try{ b.blur(); }catch(_){ }
    }
  }

  function setLectureControls(active, paused){
    const master = window.__VQ105_INPLACE_LECTURE_MASTER__ || {};
    master.active = true;
    master.running = !!active;
    master.paused = !!paused;
    window.__VQ105_INPLACE_LECTURE_MASTER__ = master;

    setBtn('pauseLessonBtn', !active || !!paused);
    setBtn('resumeLessonBtn', !active || !paused);
    setBtn('stopLessonBtn', !active);
  }

  function enforceControls(){
    if(!window.__VQ105_INPLACE_LECTURE_MASTER__ || !window.__VQ105_INPLACE_LECTURE_MASTER__.active) return;
    setLectureControls(lectureRunning, lecturePaused);
  }

  function stopLectureTimers(){
    if(lessonTimer) clearInterval(lessonTimer);
    lessonTimer = null;
  }

  function cancelSpeech(){
    try{ if(synth) synth.cancel(); }catch(_){ }
  }

  function fallbackTick(){
    if(!lectureRunning || lecturePaused || !lessonText || boundaryMode) return;
    const elapsed = Date.now() - timerStartedAt;
    const remaining = Math.max(0, lessonText.length - timerBaseIndex);
    const next = Math.min(lessonText.length, timerBaseIndex + Math.floor((elapsed / timerTotalMs) * remaining));
    if(next > lessonIndex) renderLessonAt(next);
    if(next >= lessonText.length) finishLecture();
  }

  function getLessonScript(){
    const sel = $('lessonSelect');
    const key = sel ? sel.value : 'basic';
    const lesson = LESSONS_V105[key] || Object.values(LESSONS_V105)[0] || {};
    return {key, title: lesson.title || '目前課程', script: String(lesson.script || '')};
  }

  function startFallbackTimer(fromIndex){
    timerBaseIndex = Math.max(0, Math.min(fromIndex || 0, lessonText.length));
    timerStartedAt = Date.now();
    timerTotalMs = Math.max(2500, (lessonText.length - timerBaseIndex) * 175 / rate());
    stopLectureTimers();
    lessonTimer = setInterval(fallbackTick, 120);
  }

  function speakLectureFromIndex(idx, allowResume){
    if(!synth || !lessonText || idx >= lessonText.length){
      if(idx >= lessonText.length) finishLecture();
      return;
    }

    if(!allowResume){
      cancelSpeech();
    }

    const remaining = lessonText.slice(idx);
    const baseIndex = idx;
    const u = new SpeechSynthesisUtterance(remaining);
    const v = selectedVoice();
    if(v) u.voice = v;
    u.lang = (v && v.lang) ? v.lang : 'zh-TW';
    u.rate = rate();
    u.pitch = pitch();
    lessonUtterance = u;
    boundaryMode = false;

    u.onstart = function(){
      if(!lectureRunning || lecturePaused) return;
      startMouthLoop('lecture');
      setStatus('老師講課中：黃色標示會跟到目前講到的句子');
    };
    u.onboundary = function(e){
      if(!lectureRunning || lecturePaused) return;
      if(typeof e.charIndex === 'number' && e.charIndex >= 0){
        boundaryMode = true;
        renderLessonAt(baseIndex + e.charIndex);
      }
    };
    u.onend = function(){
      if(!lectureRunning || lecturePaused) return;
      finishLecture();
    };
    u.onerror = function(){
      if(lecturePaused) return;
      boundaryMode = false;
      setStatus('語音事件不穩定；改用時間估算維持黃色標示');
    };

    try{ synth.speak(u); }catch(_){ boundaryMode = false; }
  }

  function startLectureFromBeginning(){
    const lesson = getLessonScript();
    lessonText = lesson.script || '';
    lessonIndex = 0;
    currentSegment = -1;
    lectureRunning = true;
    lecturePaused = false;
    boundaryMode = false;
    if(!lessonText){
      const box = $('lessonText'); if(box) box.textContent = '目前課程沒有講稿。';
      setLectureControls(false, false);
      return;
    }
    cancelSpeech();
    stopMouthLoop(true);
    renderScript(lessonText);
    renderLessonAt(0);
    setLectureControls(true, false);
    startFallbackTimer(0);
    speakLectureFromIndex(0, false);
    setStatus('老師講課開始：可暫停，黃色標示會跟隨目前句子');
  }

  function pauseLectureForQuestion(){
    if(!lectureRunning || lecturePaused) return;
    pauseLecture('老師講課已暫停，可提問；回答後按「繼續」可接續講稿');
  }

  function pauseLecture(customStatus){
    if(!lectureRunning) return;
    try{ fallbackTick(); }catch(_){ }
    lecturePaused = true;
    stopLectureTimers();
    try{ if(synth && synth.speaking && !synth.paused) synth.pause(); }catch(_){ }
    stopMouthLoop(true);
    setLectureControls(true, true);
    setStatus(customStatus || '語音與黃色標示已暫停，可按「繼續」接續');
  }

  function resumeLecture(){
    if(!lectureRunning || !lecturePaused || !lessonText || lessonIndex >= lessonText.length){
      setStatus('目前沒有暫停中的講稿；請重新按「老師開始講課」');
      setLectureControls(false, false);
      return;
    }
    lectureRunning = true;
    lecturePaused = false;
    boundaryMode = false;
    setLectureControls(true, false);
    startFallbackTimer(lessonIndex);

    let resumedNative = false;
    try{
      if(synth && synth.paused){ synth.resume(); resumedNative = true; }
    }catch(_){ resumedNative = false; }

    startMouthLoop('lecture');
    setStatus('語音與黃色標示已從暫停處繼續');

    // Chrome/Edge sometimes reports paused=false after pause/cancel but does not continue.
    // If native resume did not really resume, restart from the stored character index.
    setTimeout(()=>{
      if(!lectureRunning || lecturePaused) return;
      const stillSilent = synth && !synth.speaking && !synth.paused;
      if(!resumedNative || stillSilent){
        speakLectureFromIndex(lessonIndex, false);
      }
    }, 450);
  }

  function stopLecture(){
    lectureRunning = false;
    lecturePaused = false;
    stopLectureTimers();
    cancelSpeech();
    stopMouthLoop(true);
    lessonText = '';
    lessonIndex = 0;
    currentSegment = -1;
    segments = [];
    boundaryMode = false;
    const box = $('lessonText');
    if(box){
      box.classList.remove('vq109-script-box');
      delete box.dataset.vq109Text;
      box.textContent = '';
      box.scrollTop = 0;
    }
    setLectureControls(false, false);
    setStatus('老師講解已結束；如要重新播放，請按「老師開始講課」');
  }

  function stopRecognitionForModeSwitch(){
    try{ if(window.VQ_stopAllRecognition) window.VQ_stopAllRecognition('已切換模式，錄音已停止'); }catch(_){ }
    try{ if(window.__v105_active_recognition) window.__v105_active_recognition.stop(); }catch(_){ }
    window.__v105_active_recognition = null;
    const ask = $('askBtn'), stop = $('stopAskBtn');
    if(ask) ask.disabled = false;
    if(stop) stop.disabled = true;
    const qBox = $('studentQuestion');
    if(qBox) qBox.classList.remove('listening-mode');
  }

  function resetLessonIntroAfterModeSwitch(){
    const lesson = getLessonScript();
    const box = $('lessonText');
    lessonText = '';
    lessonIndex = 0;
    currentSegment = -1;
    segments = [];
    boundaryMode = false;
    if(box){
      box.classList.remove('vq109-script-box');
      delete box.dataset.vq109Text;
      box.textContent = '目前選擇：' + lesson.title + '。請按「老師開始講課」。';
      box.scrollTop = 0;
    }
  }

  function switchModePanel(tabId){
    const map = {
      lessonTab: 'lessonPanel',
      caseTab: 'casePanel',
      modelTab: 'modelPanel'
    };
    const panelId = map[tabId];
    if(!panelId) return;
    Object.keys(map).forEach(id => {
      const btn = $(id), panel = $(map[id]);
      if(btn) btn.classList.toggle('active', id === tabId);
      if(panel) panel.classList.toggle('active', id === tabId);
    });
    document.body.classList.toggle('v150-model-active', tabId === 'modelTab');
    document.body.classList.toggle('v150-case-active', tabId === 'caseTab');
  }

  function stopForModeSwitch(tabId){
    lectureRunning = false;
    lecturePaused = false;
    stopLectureTimers();
    cancelSpeech();
    stopMouthLoop(true);
    stopRecognitionForModeSwitch();
    setLectureControls(false, false);
    resetLessonIntroAfterModeSwitch();
    switchModePanel(tabId);
    const label = tabId === 'caseTab' ? '情境題練習' : (tabId === 'modelTab' ? 'V/Q 視覺模型' : '老師講解 / 自由問答');
    setStatus('已切換至「' + label + '」：老師講課、語音、嘴型與黃色標示已完全停止');
  }

  function finishLecture(){
    lectureRunning = false;
    lecturePaused = false;
    stopLectureTimers();
    lessonIndex = lessonText.length;
    renderLessonAt(lessonIndex);
    stopMouthLoop(true);
    setLectureControls(false, false);
    setStatus('老師講解完成');
  }

  async function submitQuestion(){
    pauseLectureForQuestion();
    const qBox = $('studentQuestion');
    const aBox = $('teacherAnswer');
    const q = clean(qBox ? qBox.textContent : '');
    if(!q || q === '正在聆聽...' || q === '正在聆聽…'){
      if(aBox) aBox.textContent = '請先輸入或錄下問題。';
      return;
    }
    if(aBox) aBox.textContent = 'AI 老師正在依目前課程與知識庫判斷問題...';
    let ans = '';
    try{
      if(window.VQ_V55_answerQuestion) ans = await window.VQ_V55_answerQuestion(q);
      else ans = '目前問答引擎尚未載入，請重新整理頁面。';
    }catch(e){
      ans = '問答判斷時發生錯誤，請重新送出問題。';
    }
    if(aBox){ aBox.textContent = ans; aBox.scrollTop = 0; }
    speakAnswer(ans);
  }

  function speakAnswer(ans){
    try{ if(synth) synth.cancel(); }catch(_){ }
    stopMouthLoop(true);
    answerText = String(ans || '');
    answerIndex = 0;
    if(!synth || !clean(ans)) return;
    const u = new SpeechSynthesisUtterance(String(ans));
    const v = selectedVoice();
    if(v) u.voice = v;
    u.lang = (v && v.lang) ? v.lang : 'zh-TW';
    u.rate = rate();
    u.pitch = pitch();
    answerUtterance = u;
    u.onstart = () => { answerText = String(ans || ''); answerIndex = 0; startMouthLoop('answer'); setStatus('AI 老師正在回答；講稿保持暫停'); };
    u.onboundary = (e) => { if(e && typeof e.charIndex === 'number' && e.charIndex >= 0) answerIndex = e.charIndex; };
    u.onend = () => { stopMouthLoop(true); if(lectureRunning && lecturePaused){ setLectureControls(true, true); setStatus('回答完成，可按「繼續」接續老師講稿'); }else{ setLectureControls(false, false); setStatus('回答完成'); } };
    u.onerror = () => { stopMouthLoop(true); if(lectureRunning && lecturePaused){ setLectureControls(true, true); setStatus('回答語音中止；可按「繼續」接續老師講稿'); }else{ setLectureControls(false, false); setStatus('回答語音中止'); } };
    try{ synth.speak(u); }catch(_){ }
  }

  function startRecognition(){
    pauseLectureForQuestion();
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    const qBox = $('studentQuestion');
    const ask = $('askBtn'), stop = $('stopAskBtn');
    if(!SR){
      if(qBox) qBox.textContent = '此瀏覽器不支援 SpeechRecognition。請改用 Chrome / Edge，或直接輸入文字問題。';
      return;
    }
    let finalText = '';
    try{
      const rec = new SR();
      rec.lang = 'zh-TW';
      rec.interimResults = true;
      rec.continuous = true;
      window.__v105_active_recognition = rec;
      if(ask) ask.disabled = true;
      if(stop) stop.disabled = false;
      if(qBox){ qBox.classList.add('listening-mode'); qBox.textContent = '正在聆聽...'; }
      rec.onresult = ev => {
        let interim = '';
        for(let i=ev.resultIndex;i<ev.results.length;i++){
          const t = ev.results[i][0].transcript;
          if(ev.results[i].isFinal) finalText += t + ' ';
          else interim += t;
        }
        if(qBox) qBox.textContent = clean(finalText + interim) || '正在聆聽...';
      };
      rec.onerror = () => {
        if(ask) ask.disabled = false;
        if(stop) stop.disabled = true;
        if(qBox) qBox.classList.remove('listening-mode');
      };
      rec.onend = () => {
        if(ask) ask.disabled = false;
        if(stop) stop.disabled = true;
        if(qBox) qBox.classList.remove('listening-mode');
      };
      rec.start();
      setStatus('正在聆聽學生語音；老師講稿暫停保留');
    }catch(e){
      if(ask) ask.disabled = false;
      if(stop) stop.disabled = true;
      if(qBox){ qBox.classList.remove('listening-mode'); qBox.textContent = '語音辨識啟動失敗，可改用文字輸入。'; }
    }
  }

  function stopRecognitionAndSubmit(){
    try{ if(window.__v105_active_recognition) window.__v105_active_recognition.stop(); }catch(_){ }
    setTimeout(submitQuestion, 350);
  }

  function handleClickCapture(e){
    const t = e.target && e.target.closest ? e.target.closest('button') : null;
    if(!t || !t.id) return;
    const map = {
      lessonTab: () => stopForModeSwitch('lessonTab'),
      caseTab: () => stopForModeSwitch('caseTab'),
      modelTab: () => stopForModeSwitch('modelTab'),
      startLessonBtn: startLectureFromBeginning,
      pauseLessonBtn: pauseLecture,
      resumeLessonBtn: resumeLecture,
      stopLessonBtn: stopLecture,
      repeatBtn: startLectureFromBeginning,
      askBtn: startRecognition,
      stopAskBtn: stopRecognitionAndSubmit,
      submitTypedQuestionBtn: submitQuestion
    };
    if(!map[t.id]) return;
    e.preventDefault();
    e.stopImmediatePropagation();
    map[t.id]();
  }

  function setupQuestionBox(){
    const q = $('studentQuestion');
    if(!q) return;
    q.setAttribute('contenteditable','true');
    q.setAttribute('data-placeholder','請在這裡輸入問題，或按「學生開始提問」使用語音。');
    if((q.textContent || '').trim() === '學生問的問題會顯示在這裡。') q.textContent = '';
    if(!q.dataset.v109Bound){
      q.dataset.v109Bound = '1';
      q.addEventListener('focus', () => { if(lectureRunning && !lecturePaused) pauseLectureForQuestion(); }, true);
      q.addEventListener('input', () => { if(lectureRunning && !lecturePaused) pauseLectureForQuestion(); }, true);
    }
  }

  function bindControls(){
    if(installed) return;
    installed = true;
    injectStyles();
    document.addEventListener('click', handleClickCapture, true);
    window.addEventListener('click', handleClickCapture, true);
    setupQuestionBox();

    const sel = $('lessonSelect');
    if(sel && !sel.dataset.v109Bound){
      sel.dataset.v109Bound = '1';
      sel.addEventListener('change', () => {
        stopLecture();
        const lesson = getLessonScript();
        const box = $('lessonText');
        if(box){
          box.classList.remove('vq109-script-box');
          box.textContent = '目前選擇：' + lesson.title + '。請按「老師開始講課」。';
        }
      }, true);
    }

    setLectureControls(false, false);
    if(controlTimer) clearInterval(controlTimer);
    controlTimer = setInterval(enforceControls, 120);
    stopMouthLoop(true);
    setStatus('系統已就緒');
  }

  window.VQ_V110_stopAllTeachingMedia = stopForModeSwitch;

  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', bindControls);
  else bindControls();
})();
