from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
html = (ROOT / "index.html").read_text(encoding="utf-8")
sources = re.findall(r'<script\s+src="([^"]+)"', html)

missing = [source for source in sources if not (ROOT / source).exists()]
print(f"Script references: {len(sources)}")
for index, source in enumerate(sources, start=1):
    print(f"{index:02d}  {source}")

if missing:
    print("Missing files:")
    for source in missing:
        print(source)
    sys.exit(1)

print("All script references exist.")
