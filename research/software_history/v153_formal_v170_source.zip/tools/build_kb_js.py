from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[1]
source = ROOT / "data" / "full_kb.json"
target = ROOT / "js" / "00_full_kb_data.generated.js"

data = json.loads(source.read_text(encoding="utf-8"))
payload = (
    "/** GENERATED from data/full_kb.json — do not edit manually. */\n"
    "window.VQ_TA_FULL_KB = "
    + json.dumps(data, ensure_ascii=False, separators=(",", ":"))
    + ";\n"
)
target.write_text(payload, encoding="utf-8")
print(f"Wrote {target}")
