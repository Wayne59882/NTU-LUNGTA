/**
 * V/Q TA v153 — 09_lesson_dropdown_confirm_stop.js
 * Status: Loaded
 * Responsibility: Stops current narration before changing lessons.
 * Main dependency: Lecture controls
 * Behavior note: documentation header added for GitHub; executable logic preserved.
 */

(function(){
  const $ = id => document.getElementById(id);
  const LESSONS = {"basic": {"title": "課程 1：Gas Exchange 基本架構", "script": "同學你好，這一單元我們先建立 gas exchange 的基本架構。\n\n氣體交換不是只看 PaO2 或 PaCO2，而是要同時看四個層次：ventilation、perfusion、diffusion，以及 blood oxygen content。\n\n第一，ventilation 是空氣是否能到達肺泡。  \n第二，perfusion 是血流是否能到達肺泡周圍微血管。  \n第三，diffusion 是氧氣是否能跨過 alveolar-capillary membrane。  \n第四，oxygen content 是血液是否有足夠 hemoglobin 攜帶氧氣。\n\n所以當病人低血氧時，不能直接說一定是肺泡氧氣不足，也不能直接說一定是 hemoglobin 問題。要先判斷問題發生在哪一個環節。\n\n在這份講義裡，後面的每一個主題都可以接回這四個層次。Ventilation 影響 PaCO2 和 PAO2；perfusion 影響 V/Q；diffusion 影響 A-a gradient；hemoglobin 影響 CaO2 和 oxygen delivery。"}, "ventilation": {"title": "課程 2：Ventilation 與 Alveolar Ventilation", "script": "同學你好，這一單元講 ventilation 與 alveolar ventilation。\n\nMinute ventilation 是每分鐘總通氣量：\nVE = VT × f。\n\nVT 是 tidal volume，f 是 respiratory frequency。\n\n但是，不是所有進入氣道的空氣都能參與氣體交換。dead space 的空氣不參與肺泡交換。\n\n所以真正影響 PaCO2 的是 alveolar ventilation：\nVA = (VT - VD) × f。\n\n如果 VT 下降、VD 上升、或 f 下降，VA 都會下降。  \nVA 下降時，CO2 排不出去，所以 PaCO2 會上升。  \nVA 上升時，CO2 排出增加，所以 PaCO2 會下降。\n\n在模型中，我們用正常值當基準：\nVA_normal = (500 - 150) × 15 / 1000 = 5.25 L/min。\n\n如果你調整 VT、VD、f，肺葉大小應該根據 VA 相對於 5.25 L/min 來改變。VA 高於正常，肺葉放大；VA 低於正常，肺葉縮小。"}, "alveolar_gas": {"title": "課程 3：Alveolar Gas Equation 與 Oxygenation", "script": "同學你好，這一單元講 alveolar gas equation 與 oxygenation。\n\n肺泡氧分壓 PAO2 可以用這個式子估計：\n\nPAO2 = FIO2 × (Patm - PH2O) - PaCO2 / R。\n\n這個式子有三個重點。\n\n第一，FIO2 越高，PAO2 越高，所以吸氧可以提高肺泡氧氣。\n\n第二，PaCO2 越高，PAO2 越低。所以 hypoventilation 造成 CO2 retention 時，也會拉低肺泡氧氣。\n\n第三，海拔越高，barometric pressure 越低，因此 inspired PO2 與 PAO2 都會下降。\n\n所以 oxygenation problem 和 ventilation problem 不能混在一起。提高 FIO2 可以改善 oxygenation，但不會直接修正 PaCO2。PaCO2 主要還是由 alveolar ventilation 決定。"}, "perfusion": {"title": "課程 4：Perfusion、Cardiac Output 與 Mixed Venous Blood", "script": "同學你好，這一單元講 perfusion、cardiac output 與 mixed venous blood。\n\nPerfusion 是血流到達肺泡周圍微血管的量。  \n如果通氣存在，但血流不足，就會形成 high V/Q，嚴重時接近 dead space。\n\nCardiac output 影響全身 oxygen delivery。  \noxygen delivery 約等於 cardiac output 乘上 arterial oxygen content。\n\n如果 cardiac output 下降，PaO2 和 PaCO2 不一定立刻大幅異常。  \n但是 mixed venous blood 會很敏感。\n\n因為組織仍然需要氧氣，當血流量下降時，每單位血液會被抽取更多氧氣。  \n所以 mixed venous PO2 和 SvO2 會下降。\n\n因此，mixed venous values 可反映組織 oxygen delivery 是否足夠。"}, "normal_vq": {"title": "課程 5：正常 V/Q Gradient：Apex 與 Base", "script": "同學你好，這一單元講正常 V/Q gradient。\n\nV/Q ratio 是 ventilation 除以 perfusion。\n\n直立姿勢下，apex 與 base 的 ventilation 和 perfusion 都不同。\n\nApex 的 ventilation 較少，perfusion 也較少。  \n但是 perfusion 下降得更明顯，所以 apex 的 V/Q ratio 較高。\n\nBase 的 ventilation 較多，perfusion 也較多。  \n但是 perfusion 增加得更明顯，所以 base 的 V/Q ratio 較低。\n\n所以正常肺也不是每一區 V/Q 都完全相同。  \nApex 偏 high V/Q，base 偏 low V/Q。\n\n但要注意：apex 的 V/Q ratio 比較高，不代表 apex 對總氣體交換貢獻最大。Base 因為總 ventilation 與 perfusion 較多，通常對整體 gas exchange 貢獻更多。"}, "low_vq": {"title": "課程 6：Low V/Q 與 Shunt-like Physiology", "script": "同學你好，這一單元講 low V/Q 與 shunt-like physiology。\n\nLow V/Q 的意思是：ventilation 相對不足，但是 perfusion 仍然存在。\n\n可以用一句話記：\n有血，但是氣不夠。\n\n因為血流還在，但肺泡通氣不足，所以血液經過肺泡後，氧氣沒有補夠，二氧化碳也不容易排乾淨。\n\n因此 low V/Q 區域通常會出現：\nPO2 下降、PCO2 上升、oxygen content 下降。\n\n如果 low V/Q 很嚴重，接近完全沒有通氣但仍有血流，就會變成 shunt-like，甚至接近 true shunt。\n\n常見例子包括 pneumonia、asthma、COPD 或局部 airway obstruction。\n\n所以在模型上，low V/Q 或 shunt-like 應該偏向通氣不足的病灶區，常呈現中下肺葉或病灶區縮小，而不是 high V/Q 的上肺葉變化。"}, "high_vq": {"title": "課程 7：High V/Q、Dead Space 與 Pulmonary Embolism", "script": "同學你好，這一單元講 high V/Q、dead space 與 pulmonary embolism。\n\nHigh V/Q 的意思是：ventilation 相對保留，但是 perfusion 不足。\n\n可以用一句話記：\n有氣，但是血不夠。\n\n如果 perfusion 非常低，這個區域就接近 dead space。  \n空氣進入肺泡，但沒有足夠血流參與氣體交換。\n\nPulmonary embolism 是典型例子。  \nPE 會阻斷肺血流，使受影響區域 perfusion 下降。  \nventilation 相對還在，所以 V/Q ratio 上升，形成 high V/Q 或 dead-space-like physiology。\n\n因此 dead-space-like 不應該被畫在下肺葉 shunt-like 區域。它應該偏向通氣存在但灌流不足的區域，模型上用上肺葉或局部 high V/Q 區域表示。"}, "shunt": {"title": "課程 8：True Shunt 與 Shunt Equation", "script": "同學你好，這一單元講 true shunt 與 shunt equation。\n\nShunt 的意思是有血流，但是沒有有效通氣。\n\n可以用一句話記：\n有血，沒氣。\n\nShunted blood 沒有接觸到通氣肺泡，所以血液無法被氧合，就直接混入 arterial blood。  \n因此 shunt 會使 PaO2 明顯下降。\n\nShunt 對提高 FIO2 的反應通常比較差。  \n因為沒有接觸肺泡的血流，即使外界氧氣提高，也不能直接被氧合。\n\nShunt equation 是：\nQS/QT = (Cco2 - Cao2) / (Cco2 - Cvo2)。\n\n這裡用的是 oxygen content，而不是只看 PO2。因為血液攜氧主要取決於 hemoglobin-bound oxygen。"}, "diffusion": {"title": "課程 9：Diffusion Limitation 與 A-a Gradient", "script": "同學你好，這一單元講 diffusion limitation 與 A-a gradient。\n\nDiffusion 是氣體穿過 alveolar-capillary membrane 的過程。\n\n氧氣要從肺泡進入血液，二氧化碳要從血液回到肺泡。\n\n當 diffusing capacity 下降時，氧氣無法充分進入血液，所以 PaO2 下降。  \n但是 PAO2 可能仍然相對正常，因此 A-a O2 difference 會增加。\n\nExercise 會讓 diffusion limitation 更明顯。  \n因為運動時 oxygen uptake 增加，而且血液通過 pulmonary capillary 的有效交換時間相對變短。\n\n提高 FIO2 可以改善 diffusion limitation，因為它會增加肺泡和血液之間的 oxygen partial pressure gradient。\n\nCO2 通常比較不受 diffusion limitation 影響，因為 CO2 的擴散能力比 O2 更強。"}, "oxygen_content": {"title": "課程 10：Hemoglobin、CaO2 與 Oxygen Delivery", "script": "同學你好，這一單元講 hemoglobin、CaO2 與 oxygen delivery。\n\nPaO2 是溶解在血漿中的 oxygen partial pressure。  \n它不是血液總氧含量。\n\n血液總氧含量 CaO2 主要由 hemoglobin 和 SaO2 決定：\n\nCaO2 ≈ 1.34 × Hb × SaO2 + 0.003 × PaO2。\n\n所以 anemia 時，PaO2 可以正常，SaO2 也可以正常。  \n但是 Hb 下降會讓 CaO2 下降。\n\nOxygen delivery 約等於 cardiac output × CaO2。\n\n因此，Hb 下降或 cardiac output 下降，都可能造成 tissue hypoxia。這也是為什麼只看 PaO2 有時候會低估病人的氧輸送問題。"}, "integrated_disease": {"title": "課程 11：疾病整合：PE、Pneumonia、Asthma、COPD", "script": "同學你好，這一單元整合 PE、pneumonia、asthma、COPD 與 V/Q physiology。\n\nPulmonary embolism，簡稱 PE，主要問題是 perfusion 下降。  \nventilation 相對保留，所以 V/Q 上升，偏 high V/Q 或 dead-space-like。\n\nPneumonia 主要問題是肺泡發炎、滲出物或 consolidation。  \n這會使 ventilation 下降，但 perfusion 仍可能存在，所以偏 low V/Q 或 shunt-like。\n\nAsthma 和 COPD 常見 airway obstruction。  \n氣道阻塞會讓部分肺區 ventilation 下降，因此常見 regional low V/Q。\n\nCOPD 還可能合併肺泡破壞、dead space 增加與 gas exchange efficiency 下降，所以它可能是 mixed pattern。\n\n總結：\nPE：Q 下降，V/Q 上升，偏 dead space。  \nPneumonia：V 下降，V/Q 下降，偏 shunt-like。  \nAsthma / COPD：airway obstruction 造成 regional low V/Q，也可能混合 high V/Q。"}};
  let timer = null;
  let utterance = null;
  let scriptText = '';
  let index = 0;
  let paused = false;
  let startedAt = 0;
  let totalMs = 0;
  let boundaryMode = false;

  function getLessonKey(){
    const sel = $('lessonSelect');
    return sel && sel.value ? sel.value : 'basic';
  }
  function getLesson(){
    return LESSONS[getLessonKey()] || LESSONS.basic || Object.values(LESSONS)[0] || {title:'課程', script:''};
  }
  function status(t){
    const ids=['lectureStatus','agentStatus','statusText','systemStatus'];
    for(const id of ids){ const el=$(id); if(el){ el.textContent=t; break; } }
  }
  function setControls(active){
    const p=$('pauseLessonBtn'), r=$('resumeLessonBtn'), s=$('stopLessonBtn');
    if(p) p.disabled=!active;
    if(r) r.disabled=!active;
    if(s) s.disabled=!active;
  }
  function escapeText(s){ return String(s || '').replace(/[&<>]/g, ch=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[ch])); }
  function renderAt(i){
    const box=$('lessonText'); if(!box) return;
    const safe=Math.max(0, Math.min(i, scriptText.length));
    const done=scriptText.slice(0, safe);
    const current=scriptText.charAt(safe) || '';
    box.classList.add('v66-typewriter-sync');
    box.innerHTML = '<span class="v66-done">'+escapeText(done)+'</span>' +
      (current ? '<span class="v66-current-char">'+escapeText(current)+'</span>' : '') +
      '<span class="v66-caret"></span>';
    try{ box.scrollTop = box.scrollHeight; }catch(_){ }
  }
  function stopTimers(){ if(timer){ clearInterval(timer); timer=null; } }
  function hardStop(msg){
    stopTimers(); paused=false; boundaryMode=false; index=0;
    try{ if(window.VQ_stopAllRecognition) window.VQ_stopAllRecognition('停止錄音'); }catch(_){ }
    try{ if(window.speechSynthesis){ window.speechSynthesis.pause(); window.speechSynthesis.cancel(); setTimeout(()=>window.speechSynthesis.cancel(),60); } }catch(_){ }
    utterance=null; setControls(false); if(msg) status(msg);
  }
  window.VQ_v66HardStop = hardStop;

  function pickVoice(u){
    try{
      const sel=$('voiceSelect'); const voices=window.speechSynthesis?.getVoices?.() || [];
      if(sel && sel.value){ const v=voices.find(x=>x.name===sel.value); if(v) u.voice=v; }
      if(!u.voice){
        u.voice = voices.find(v=>/zh|Chinese|Taiwan|Mandarin/i.test((v.lang||'')+' '+(v.name||''))) || voices[0] || null;
      }
    }catch(_){ }
  }
  function fallbackTick(){
    if(paused || boundaryMode || !scriptText) return;
    const elapsed = Date.now() - startedAt;
    const target = Math.min(scriptText.length, Math.floor((elapsed / Math.max(1,totalMs)) * scriptText.length));
    if(target > index){ index = target; renderAt(index); }
    if(index >= scriptText.length){ stopTimers(); renderAt(scriptText.length); }
  }
  function startTypewriterLecture(){
    hardStop('正在開始老師講課');
    const lesson=getLesson(); scriptText=String(lesson.script || ''); index=0; paused=false; boundaryMode=false;
    if(!scriptText){ const box=$('lessonText'); if(box) box.textContent='目前課程沒有講稿。'; return; }
    renderAt(0); setControls(true);
    const rate=parseFloat(($('rateRange')||{}).value || '1') || 1;
    totalMs = Math.max(8000, scriptText.length * 165 / rate);
    startedAt = Date.now();
    timer = setInterval(fallbackTick, 80);
    if(window.speechSynthesis){
      utterance = new SpeechSynthesisUtterance(scriptText);
      utterance.lang='zh-TW'; utterance.rate=rate; pickVoice(utterance);
      utterance.onstart=()=>{ startedAt=Date.now(); status('老師講課中：講稿會跟語音同步逐字出現'); };
      utterance.onboundary=(e)=>{
        if(typeof e.charIndex === 'number' && e.charIndex >= 0){
          boundaryMode=true;
          index=Math.min(scriptText.length, e.charIndex);
          renderAt(index);
        }
      };
      utterance.onend=()=>{ stopTimers(); index=scriptText.length; renderAt(index); setControls(false); utterance=null; status('老師講解完成'); };
      utterance.onerror=(e)=>{ stopTimers(); setControls(false); utterance=null; if(e && e.error==='interrupted') status('老師講解已停止'); else status('老師講解語音已中止'); };
      setTimeout(()=>{ try{ window.speechSynthesis.cancel(); window.speechSynthesis.speak(utterance); }catch(_){ } },80);
    } else {
      status('此瀏覽器不支援語音播放，僅顯示逐字講稿');
    }
  }
  function pauseLecture(){
    paused=true;
    try{ if(window.speechSynthesis) window.speechSynthesis.pause(); }catch(_){ }
    status('語音與講稿已暫停');
  }
  function resumeLecture(){
    paused=false;
    // reset clock so fallback does not jump too far after pause
    const progress = scriptText.length ? index / scriptText.length : 0;
    startedAt = Date.now() - progress * totalMs;
    try{ if(window.speechSynthesis) window.speechSynthesis.resume(); }catch(_){ }
    status('語音與講稿繼續');
  }
  function resetIntro(){
    const lesson=getLesson(); const box=$('lessonText');
    if(box){ box.classList.remove('v66-typewriter-sync'); box.textContent='目前選擇：'+(lesson.title||'課程')+'。請按「老師開始講課」。'; }
  }
  function bindCapture(id, fn){
    const el=$(id); if(!el) return;
    el.disabled=false;
    el.addEventListener('click', function(e){ e.preventDefault(); e.stopImmediatePropagation(); fn(e); }, true);
  }
  function install(){
    bindCapture('startLessonBtn', startTypewriterLecture);
    bindCapture('repeatBtn', startTypewriterLecture);
    bindCapture('pauseLessonBtn', pauseLecture);
    bindCapture('resumeLessonBtn', resumeLecture);
    bindCapture('stopLessonBtn', ()=>hardStop('語音與講稿已停止'));
    ['submitTypedQuestionBtn','startAskBtn','stopAskBtn'].forEach(id=>{
      const el=$(id); if(el) el.addEventListener('click', ()=>hardStop('已停止老師講課'), true);
    });
    const sel=$('lessonSelect');
    if(sel){
      let committedLessonValue = sel.value;
      // v86: opening/clicking/navigating the course dropdown must NOT stop the current lecture.
      // The old v60 click stopper is removed for lessonSelect; only a confirmed value change stops speech.
      ['pointerdown','mousedown','click','focus'].forEach(evt=>{
        sel.addEventListener(evt, e=>{ e.stopPropagation(); }, true);
      });
      sel.addEventListener('change', ()=>{
        const nextLessonValue = sel.value;
        if(nextLessonValue !== committedLessonValue){
          committedLessonValue = nextLessonValue;
          hardStop('已確認切換課程，語音停止');
          setTimeout(resetIntro,0);
        }
      }, true);
    }
    resetIntro();
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',()=>setTimeout(install,250));
  else setTimeout(install,250);
})();
