# v170 formal release bundle

Application scoring remains the formal course-mapping-fixed v153 model.

Formal Main KB weights are locked at:

45, 8, 0, 7, 0, 18, 2, 0, 2, 12.

Added150 and Total200 are validation datasets and do not reselect the
factor weights. The Main KB Gate remains 68.
