# V/Q Ratio Virtual Human TA — v153 GitHub-ready

這是 v153 分檔版的 GitHub 整理版。介面與執行邏輯維持 v153；主要整理是把原本塞在
`03_full_kb_course_specific_qa.js` 內的 **11,000 筆 Knowledge Base 資料**
拆成獨立資料檔，讓 JavaScript 邏輯可以直接閱讀。

## 快速啟動

```bash
python -m http.server 8000
```

瀏覽器開啟 `http://localhost:8000/`。

也可以直接開啟 `index.html`，但使用本機伺服器較適合測試 Web Speech API。

## 重要目錄

- `index.html`：主程式入口，可直接部署到 GitHub Pages。
- `js/00_full_kb_data.generated.js`：瀏覽器實際載入的 11,000 筆 KB。
- `js/03_qa_engine.js`：Domain、retrieval、Active-7 scoring 與回答生成邏輯。
- `data/full_kb.json`：可閱讀、可版本控制的 KB 原始資料。
- `data/javascript_manifest.csv`：JavaScript 載入順序、職責與相依性。
- `js/archive_not_loaded/`：v153 中存在但未由 `index.html` 載入的舊 patch。
- `docs/`：程式結構、scoring pipeline 與 GitHub 部署說明。
- `tools/`：重建 KB JavaScript 與檢查 script references 的工具。

## 正式 scoring

Main KB 使用 Active-7：

| Scoring item | Weight |
|---|---:|
| Course base | 45 |
| Intent match | 8 |
| Alias hit | 7 |
| Concept exact | 18 |
| Domain overlap | 2 |
| Response variant | 2 |
| Detected-course bonus | 12 |

Main KB Gate = **68**。

Domain 正式規則為 binary any-hit：命中至少一個有效 Domain item 才通過。

## Knowledge Base

- Course groups：11
- Base KB items：11000
- 每個 course group：1,000 筆
- 另有程式中加入的 main KB fine-grained items，保留在 `03_qa_engine.js`

## GitHub Pages

Repository Settings → Pages → Deploy from branch → `main` / root。

## v168 course-context correction

The UI lesson IDs are mapped to Main KB course IDs before course detection:

- `core` -> `basic`
- `regional` -> `normal_vq`
- `disease` -> `integrated_disease`
- `patient` -> `basic`

This removes the previous UI/KB ID mismatch and preserves the formal validation plateaus: Original 50Q `68-93`; Added 150Q and Total 200Q `68-71`.
