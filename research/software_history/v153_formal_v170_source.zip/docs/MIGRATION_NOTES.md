# v153 GitHub cleanup notes

Changes made for repository clarity:

1. Extracted the embedded 11,000-item KB from the QA engine.
2. Renamed the logic file to `03_qa_engine.js`.
3. Added a generated browser data file and a readable JSON source file.
4. Moved JavaScript files not referenced by `index.html` into `js/archive_not_loaded/`.
5. Added standardized documentation headers.
6. Added manifests, build tools and GitHub Pages instructions.

No scoring weights, Domain rules, Main KB Gate, UI behavior or student-result logic were intentionally changed.
