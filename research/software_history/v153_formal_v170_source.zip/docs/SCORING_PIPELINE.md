# Domain and Main KB pipeline

## Stage 1 — Domain gate

1. Normalize question text.
2. Evaluate strong English terms, strong Chinese terms, fine-grained Domain terms,
   V/Q ratio patterns, special Chinese patterns, weak generic evidence and course-title tokens.
3. Formal rule: at least one valid Domain item hit is required.
4. If Domain fails, the system does not proceed to the Main KB answer stage.

## Stage 2 — Main KB

1. Detect intent.
2. Detect likely course.
3. Retrieve candidate KB items.
4. Score each candidate using Active-7:
   - Course base 45
   - Intent match 8
   - Alias hit 7
   - Concept exact 18
   - Domain overlap 2
   - Response variant 2
   - Detected-course bonus 12
5. Select Top-1 candidate.
6. Top-1 score ≥ 68 → answer adopted.

## Important distinction

OFAT sensitivity results are independent one-variable analyses. They are not added to obtain Gate 68.
Gate 68 comes from the whole-model Top-1 score threshold sweep.
