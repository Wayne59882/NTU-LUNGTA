# Course-context mapping correction (v168)

`index.html` uses four lesson-context IDs, while the Main KB uses eleven course IDs.
The QA engine now maps the UI context before applying the selected-course tie-breaker:

| UI context | Main KB context |
|---|---|
| core | basic |
| regional | normal_vq |
| disease | integrated_disease |
| patient | basic |

The default `core` context therefore evaluates as `basic`, matching the formal v153 validation configuration.
