# JavaScript load order

1. `js/01_original_ui_core.js`
2. `js/02_stable_webspeech_patch.js`
3. `js/00_full_kb_data.generated.js`
4. `js/03_qa_engine.js`
5. `js/04_global_speech_stop_patch.js`
6. `js/05_recognition_stop_on_submit.js`
7. `js/06_abort_guard_patch.js`
8. `js/07_typewriter_highlight_patch.js`
9. `js/08_script_typewriter_sync.js`
10. `js/09_lesson_dropdown_confirm_stop.js`
11. `js/13_voice_speed_restore.js`
12. `js/14_voice_live_sync_patch.js`
13. `js/15_voice_options_restore.js`
14. `js/16_voice_switch_script_control_fix.js`
15. `js/17_voice_live_sync_pause_button_fix.js`
16. `js/20_stop_clears_teacher_script_patch.js`
17. `js/25_v105_resume_after_question_mouth_sync.js`
18. `js/26_realistic_avatar_photo_mouth_sync.js`
19. `js/27_force_yating_zhiwei_voice.js`
20. `js/29_v153_course_aligned_student_results.js`

詳細責任與相依性請看 `data/javascript_manifest.csv`。
