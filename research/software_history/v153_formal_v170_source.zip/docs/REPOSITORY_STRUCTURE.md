# Repository structure

```text
.
├─ index.html
├─ assets/
├─ css/
├─ js/
│  ├─ 00_full_kb_data.generated.js
│  ├─ 01_original_ui_core.js
│  ├─ 02_stable_webspeech_patch.js
│  ├─ 03_qa_engine.js
│  ├─ ...
│  ├─ 29_v153_course_aligned_student_results.js
│  └─ archive_not_loaded/
├─ data/
│  ├─ full_kb.json
│  ├─ kb_course_summary.csv
│  └─ javascript_manifest.csv
├─ docs/
└─ tools/
```

`index.html` 只會載入 active JavaScript。`archive_not_loaded` 內的檔案不參與 v153 runtime。
