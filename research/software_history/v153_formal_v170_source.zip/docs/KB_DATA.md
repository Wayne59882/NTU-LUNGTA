# Knowledge Base data

`data/full_kb.json` is the readable source data.

The browser cannot reliably use `fetch()` when the app is opened directly with `file://`.
Therefore the build tool generates:

`js/00_full_kb_data.generated.js`

which assigns the same object to `window.VQ_TA_FULL_KB`.

After editing `data/full_kb.json`, run:

```bash
python tools/build_kb_js.py
```
