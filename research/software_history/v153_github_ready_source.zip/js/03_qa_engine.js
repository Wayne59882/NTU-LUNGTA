/**
 * V/Q TA v153 — Main QA engine
 *
 * Responsibilities
 * - Domain evidence screening
 * - Intent and course detection
 * - Main KB retrieval and Active-7 scoring
 * - Main KB Gate = 68
 * - Course-specific response composition
 * - Speech recognition and answer rendering
 *
 * Data dependency
 * - js/00_full_kb_data.generated.js must load first.
 * - Editable KB source: data/full_kb.json
 *
 * This refactor only separates the 11,000-item data object from the logic.
 * Runtime scoring and behavior are preserved from v153.
 */

(function(){
  const $ = id => document.getElementById(id);
  const EMBEDDED_FULL_KB = window.VQ_TA_FULL_KB;
  if (!EMBEDDED_FULL_KB) {
    throw new Error('VQ_TA_FULL_KB was not loaded before the QA engine.');
  }
  const COURSE_ORDER = ['basic','ventilation','alveolar_gas','perfusion','normal_vq','low_vq','high_vq','shunt','diffusion','oxygen_content','integrated_disease'];


  // v113 main KB domain-term items: shunt, dead space, VD/VT, Qs/Qt and V/Q mismatch items are listed under existing KB course/domain groups.
  const MAIN_KB_DOMAIN_ITEMS_V113 = [{"course":"shunt","courseTitle":"課程 8：Shunt 與分流生理","courseGoal":"讓學生能分辨 true shunt、anatomic shunt、physiologic shunt、oxygen response 與 shunt equation。","concept":"anatomic shunt","intent":"definition","aliases":["anatomic shunt","anatomical shunt","解剖分流","解剖性分流","normal anatomic shunt","bronchial circulation shunt","thebesian veins"],"questionPatterns":["是什麼","什麼意思","define","definition","what is","何謂","分流"],"content":"Anatomic shunt 是正常解剖上存在的少量右到左分流，通常來自 bronchial venous drainage 與 Thebesian veins，使少量未完全氧合的血混入動脈血。","definition":"Anatomic shunt 是正常解剖結構造成的少量右到左分流；少量靜脈血會繞過已通氣肺泡或直接混入左心與肺靜脈血。","equation":"可放在 shunt fraction 的概念中理解：Qs/Qt 反映未被有效氧合的血流比例；anatomic shunt 是正常生理下的小部分來源。","mechanism":"即使肺泡通氣正常，bronchial circulation 與 Thebesian veins 仍可讓少量低氧血混入 arterial blood，因此 PaO2 會略低於理想 end-capillary PO2。","example":"健康人也可能有很小的 A-a gradient，部分原因就是正常 anatomic shunt 與 V/Q 不均。","model":"模型可標示為少量固定 venous admixture，不應顯示為整個肺區完全無通氣。","clinical":"臨床上 anatomic shunt 通常很小；若低氧嚴重，應再評估 pathologic shunt、V/Q mismatch 或 diffusion limitation。","misconception":"不要把 anatomic shunt 等同於 pneumonia 或 atelectasis 造成的大片 true shunt。","variant":"direct","unitItemNumber":11001},{"course":"shunt","courseTitle":"課程 8：Shunt 與分流生理","courseGoal":"讓學生能分辨 true shunt、anatomic shunt、physiologic shunt、oxygen response 與 shunt equation。","concept":"physiologic shunt","intent":"definition","aliases":["physiologic shunt","physiological shunt","生理分流","生理性分流","total shunt","venous admixture"],"questionPatterns":["是什麼","什麼意思","define","definition","what is","何謂","分流"],"content":"Physiologic shunt 是造成 arterial oxygenation 下降的總分流效果，包含 anatomic shunt 加上肺內低 V/Q 或未通氣但仍灌流區域造成的 venous admixture。","definition":"Physiologic shunt 是功能上等同分流的總效果：有些血液沒有被充分氧合就進入動脈端，因此拉低 PaO2 與 SaO2。","equation":"可用 Qs/Qt 估計：Qs/Qt = (CcO2 - CaO2) / (CcO2 - CvO2)。","mechanism":"它不只包含正常 anatomic shunt，也包含嚴重 low V/Q、肺泡塌陷、肺炎滲出等造成的未充分氧合血流。","example":"pneumonia 或 atelectasis 造成某些肺泡幾乎沒有通氣但仍有血流，會增加 physiologic shunt。","model":"模型上可用『低氧血混入 arterial side』呈現；嚴重時該區 V/Q 接近 0。","clinical":"physiologic shunt 越大，給氧改善越有限；尤其 true shunt 對單純提高 FiO2 的反應較差。","misconception":"physiologic shunt 不是單指正常 anatomic shunt；它是所有分流效果的總和。","variant":"direct","unitItemNumber":11002},{"course":"shunt","courseTitle":"課程 8：Shunt 與分流生理","courseGoal":"讓學生能分辨 true shunt、anatomic shunt、physiologic shunt、oxygen response 與 shunt equation。","concept":"venous admixture","intent":"definition","aliases":["venous admixture","靜脈血混合","venous mixing","mixed venous admixture","admixture"],"questionPatterns":["是什麼","什麼意思","define","definition","what is","何謂"],"content":"Venous admixture 指低氧或未完全氧合的靜脈血混入已氧合血，使動脈氧含量與 PaO2 下降。","definition":"Venous admixture 是低氧血混入 arterial blood 的現象；它是理解 physiologic shunt 與 low V/Q 導致低氧的重要概念。","equation":"在 shunt equation 中，CaO2 下降相對於 CcO2 與 CvO2 的關係可用來估計 Qs/Qt。","mechanism":"當某些肺區通氣不足、塌陷或完全沒有通氣，但血流仍回到左心，就會把低氧血混入全身動脈血。","example":"肺炎區域的血液氧合不足，回流後與正常肺區血液混合，造成 systemic PaO2 下降。","model":"模型可在動脈端呈現正常氧合血與低氧血混合後的 PaO2 下降。","clinical":"venous admixture 增加通常會造成 A-a gradient 增加與 hypoxemia。","misconception":"不要把 venous admixture 誤解成 mixed venous oxygen content 本身；它指的是低氧血混入動脈端的效果。","variant":"direct","unitItemNumber":11003},{"course":"shunt","courseTitle":"課程 8：Shunt 與分流生理","courseGoal":"讓學生能分辨 true shunt、anatomic shunt、physiologic shunt、oxygen response 與 shunt equation。","concept":"right-to-left shunt","intent":"definition","aliases":["right-to-left shunt","right left shunt","右到左分流","右左分流","R to L shunt"],"questionPatterns":["是什麼","什麼意思","define","definition","what is","何謂"],"content":"Right-to-left shunt 是血液從右心或肺動脈端未經有效肺泡氧合就進入左心或動脈端。","definition":"Right-to-left shunt 的核心是未氧合或低氧血繞過有效 gas exchange，直接進入 systemic arterial circulation。","equation":"若要量化，可連到 Qs/Qt 或 oxygen content-based shunt equation。","mechanism":"因為這部分血流沒有接觸有效通氣肺泡，提高 FiO2 只能改善有通氣肺泡的血，對分流血本身幫助有限。","example":"肺內 shunt 可見於 atelectasis 或肺炎造成的無通氣但仍灌流區域；心內分流則屬另一類解剖通道。","model":"模型應顯示血流繞過有效肺泡交換，或顯示 V/Q 接近 0 的肺區。","clinical":"right-to-left shunt 會造成 refractory hypoxemia，即給氧反應相對差。","misconception":"right-to-left shunt 不是 dead space；dead space 是有氣沒血，shunt 是有血沒氣。","variant":"direct","unitItemNumber":11004},{"course":"shunt","courseTitle":"課程 8：Shunt 與分流生理","courseGoal":"讓學生能分辨 true shunt、anatomic shunt、physiologic shunt、oxygen response 與 shunt equation。","concept":"dead space vs shunt","intent":"compare","aliases":["dead space vs shunt","shunt vs dead space","dead space and shunt","死腔 分流 差別","分流 死腔 差別","有氣沒血 有血沒氣"],"questionPatterns":["差別","比較","vs","versus","difference","不同","分辨","一樣嗎"],"content":"Dead space 和 shunt 是方向相反的 V/Q 極端：dead space 是有通氣但沒有足夠灌流；shunt 是有灌流但沒有有效通氣。","definition":"比較：dead space = 有氣沒血，V/Q 趨近無限大；shunt = 有血沒氣，V/Q 趨近 0。","equation":"Dead space 常用 VD/VT 或 Bohr equation；shunt 常用 Qs/Qt = (CcO2-CaO2)/(CcO2-CvO2)。","mechanism":"dead space 浪費 ventilation，常見於 perfusion loss；shunt 浪費 perfusion，常見於 ventilation loss 或肺泡充滿液體／塌陷。","example":"pulmonary embolism 使血流下降，偏 dead-space-like/high V/Q；atelectasis 或嚴重 pneumonia 使通氣消失但血流仍在，偏 shunt。","model":"模型上 dead space 應顯示通氣存在但灌流不足；shunt 應顯示灌流存在但通氣不足或消失。","clinical":"dead space 增加會降低 ventilatory efficiency；shunt 增加常造成對給氧反應較差的低氧血症。","misconception":"不要只用 PaO2 下降來判斷；要先看主要問題是 V 少、Q 少，還是兩者比例失衡。","variant":"direct","unitItemNumber":11005},{"course":"ventilation","courseTitle":"課程 2：Ventilation 與 Alveolar Ventilation","courseGoal":"讓學生能用 VT、VD、f 與 VA 解釋 PaCO2 與肺模型變化。","concept":"anatomic dead space","intent":"definition","aliases":["anatomic dead space","anatomical dead space","解剖死腔","解剖性死腔","conducting airway dead space","conducting zone"],"questionPatterns":["是什麼","什麼意思","define","definition","what is","何謂","死腔"],"content":"Anatomic dead space 是 conducting airways 中不參與 alveolar gas exchange 的氣量，例如鼻腔、氣管、支氣管等傳導氣道。","definition":"Anatomic dead space 是吸入氣停留在傳導氣道、沒有到達可交換肺泡的部分；它是正常存在的 dead space。","equation":"Alveolar ventilation: VA = (VT - VD) × f；此處 VD 可先用 anatomic dead space 近似。","mechanism":"每一次 tidal volume 中，前段氣體用來填充傳導氣道，不能直接和肺微血管交換 O2/CO2。","example":"若 VT = 500 mL、anatomic VD 約 150 mL，則每口有效進入肺泡交換的氣量約 350 mL。","model":"模型可把 conducting airway dead space 與 alveolar compartment 分開，不要把全部 VT 都算成有效肺泡通氣。","clinical":"低 tidal volume 時，anatomic dead space 佔比變高，VA 會明顯下降並可能造成 PaCO2 上升。","misconception":"anatomic dead space 不是肺栓塞造成的 alveolar dead space；前者是正常傳導氣道，後者是肺泡有氣但灌流不足。","variant":"direct","unitItemNumber":11006},{"course":"high_vq","courseTitle":"課程 7：High V/Q、Dead Space 與 Pulmonary Embolism","courseGoal":"讓學生能分辨 high V/Q、alveolar dead space、physiologic dead space 與 PE。","concept":"alveolar dead space","intent":"definition","aliases":["alveolar dead space","肺泡死腔","alveolar VD","ventilated unperfused alveoli","有氣沒血"],"questionPatterns":["是什麼","什麼意思","define","definition","what is","何謂","死腔"],"content":"Alveolar dead space 是有通氣的肺泡缺乏足夠灌流，因此無法有效交換氣體。","definition":"Alveolar dead space = alveoli are ventilated but poorly perfused；也就是肺泡有氣，但沒有足夠血流把 O2 帶走或把 CO2 帶來。","equation":"它會使 VD/VT 上升；Bohr equation 可用 CO2 dilution 的概念估計 dead space fraction。","mechanism":"血流不足時，該肺泡的 ventilation 被浪費，局部 V/Q 很高，PACO2 低、PAO2 高，但整體交換效率下降。","example":"Pulmonary embolism 阻斷某些肺區血流，可造成 alveolar dead space。","model":"模型應顯示該區通氣仍在，但 perfusion arrow 或血流標記下降。","clinical":"alveolar dead space 增加會增加 ventilatory demand，嚴重時可造成 dyspnea、hypoxemia 或 CO2 清除效率下降。","misconception":"alveolar dead space 不是 shunt；shunt 是有血沒氣，alveolar dead space 是有氣沒血。","variant":"direct","unitItemNumber":11007},{"course":"ventilation","courseTitle":"課程 2：Ventilation 與 Alveolar Ventilation","courseGoal":"讓學生能用 VT、VD、f 與 VA 解釋 PaCO2 與肺模型變化。","concept":"physiologic dead space","intent":"definition","aliases":["physiologic dead space","physiological dead space","生理死腔","生理性死腔","total dead space","total VD"],"questionPatterns":["是什麼","什麼意思","define","definition","what is","何謂","死腔"],"content":"Physiologic dead space 是總 dead space，包含 anatomic dead space 與 alveolar dead space。","definition":"Physiologic dead space = anatomic dead space + alveolar dead space；代表每次通氣中沒有有效參與 gas exchange 的總量。","equation":"VDphys = VDanatomic + VDalveolar；VD/VT 可表示 dead space fraction。","mechanism":"正常人主要是 anatomic dead space；若 PE、肺血流不足或嚴重 V/Q mismatch，alveolar dead space 增加，physiologic dead space 也會上升。","example":"健康人 physiological dead space 接近 anatomical dead space；PE 時 alveolar dead space 增加，使 physiologic dead space 明顯升高。","model":"模型可把總 dead space 拆成 airway dead space 與 ventilated-but-underperfused alveoli。","clinical":"physiologic dead space 升高表示 ventilation efficiency 下降，病人需要更高 minute ventilation 才能維持 PaCO2。","misconception":"physiologic dead space 不是單純等於 anatomical dead space；疾病時 alveolar dead space 會使它變大。","variant":"direct","unitItemNumber":11008},{"course":"ventilation","courseTitle":"課程 2：Ventilation 與 Alveolar Ventilation","courseGoal":"讓學生能用 VT、VD、f 與 VA 解釋 PaCO2 與肺模型變化。","concept":"Bohr equation","intent":"equation","aliases":["Bohr equation","Bohr dead space equation","Bohr formula","波爾公式","波耳公式","dead space equation"],"questionPatterns":["公式","equation","formula","怎麼算","calculate","計算","方程"],"content":"Bohr equation 用 mixed expired CO2 與 alveolar CO2 的差距估計 dead space fraction。","definition":"Bohr equation 是用 CO2 稀釋概念估計 VD/VT 的 dead space 公式。","equation":"VD/VT = (PACO2 - PECO2) / PACO2。臨床常用 Enghoff modification 以 PaCO2 近似 PACO2。","mechanism":"dead space 沒有有效 CO2 交換，會稀釋 mixed expired CO2；PECO2 越低，相對 dead space fraction 越高。","example":"若 PACO2 = 40、PECO2 = 28，VD/VT = (40-28)/40 = 0.30。","model":"數值區可同時顯示 PACO2、PECO2 與 VD/VT，讓學生看到 dead space 增加如何拉低 mixed expired CO2。","clinical":"VD/VT 增加代表 ventilation 被浪費，常見於 PE、肺血管床減少或嚴重不均勻 V/Q。","misconception":"Bohr equation 不是 shunt equation；Bohr 算 dead space，Qs/Qt 算 shunt。","variant":"direct","unitItemNumber":11009},{"course":"ventilation","courseTitle":"課程 2：Ventilation 與 Alveolar Ventilation","courseGoal":"讓學生能用 VT、VD、f 與 VA 解釋 PaCO2 與肺模型變化。","concept":"VD/VT","intent":"equation","aliases":["VD/VT","VD VT","Vd/Vt","dead space fraction","dead space ratio","死腔比例","死腔分率"],"questionPatterns":["公式","equation","ratio","比例","分率","怎麼算","calculate","計算"],"content":"VD/VT 是 dead space 佔 tidal volume 的比例，用來衡量每口氣有多少沒有有效交換。","definition":"VD/VT 是 dead space fraction；數值越高，代表越多 ventilation 沒有產生有效 gas exchange。","equation":"VD/VT = VD / VT；若用 Bohr equation，VD/VT = (PACO2 - PECO2) / PACO2。","mechanism":"VD/VT 上升時，在相同 minute ventilation 下，alveolar ventilation 下降，CO2 清除效率變差。","example":"VT 500 mL、VD 150 mL 時，VD/VT = 0.30；若 VD 增加到 250 mL，VD/VT = 0.50。","model":"模型應讓 dead space ratio 上升時有效肺泡通氣區縮小或 ventilatory efficiency 下降。","clinical":"VD/VT 可用來說明 PE 或嚴重肺病造成的 wasted ventilation。","misconception":"VD/VT 不是 V/Q ratio，也不是 Qs/Qt。","variant":"direct","unitItemNumber":11010},{"course":"normal_vq","courseTitle":"課程 5：正常 V/Q 梯度與 V/Q Mismatch 基礎","courseGoal":"讓學生能用 ventilation/perfusion 比值判斷正常梯度、low V/Q、high V/Q 與 mismatch。","concept":"V/Q mismatch","intent":"definition","aliases":["V/Q mismatch","VQ mismatch","V Q mismatch","ventilation perfusion mismatch","ventilation-perfusion mismatch","通氣灌流不匹配","通氣灌流失衡","V/Q 不匹配","VQ 不匹配"],"questionPatterns":["是什麼","什麼意思","define","definition","what is","何謂","不匹配","失衡"],"content":"V/Q mismatch 是 ventilation 與 perfusion 的比例不適當，導致肺泡氣體與血液交換效率下降。","definition":"V/Q mismatch 指某些肺區 ventilation 和 perfusion 沒有配合好；可能偏 low V/Q，也可能偏 high V/Q。","equation":"V/Q = alveolar ventilation / pulmonary perfusion。low V/Q 表示 V 相對不足；high V/Q 表示 Q 相對不足。","mechanism":"若 V 太少而 Q 仍在，血液氧合不足，偏 low V/Q 或 shunt-like；若 Q 太少而 V 仍在，通氣被浪費，偏 high V/Q 或 dead-space-like。","example":"pneumonia 常造成 low V/Q；pulmonary embolism 常造成 high V/Q；正常直立肺也有 apex-to-base V/Q gradient，但不一定是疾病。","model":"模型應同時顯示 V 與 Q，而不是只顯示肺葉大小；判斷方向要看 V/Q 比值如何改變。","clinical":"V/Q mismatch 是 hypoxemia 和 A-a gradient 增加的常見原因，通常比單純 diffusion limitation 更常見。","misconception":"V/Q mismatch 不是只等於 shunt，也不是只等於 dead space；它是一個範圍，兩端才接近 shunt 或 dead space。","variant":"direct","unitItemNumber":11011},{"course":"low_vq","courseTitle":"課程 6：Low V/Q、Shunt-like 與 Pneumonia/Asthma","courseGoal":"讓學生能判斷通氣下降造成的 low V/Q、shunt-like physiology 與氧氣反應。","concept":"low V/Q vs shunt","intent":"compare","aliases":["low V/Q vs shunt","low VQ vs shunt","low V/Q and shunt","低VQ 分流 差別","low vq shunt-like","shunt-like"],"questionPatterns":["差別","比較","vs","versus","difference","不同","分辨","一樣嗎"],"content":"Low V/Q 和 shunt 位在同一條光譜上：low V/Q 是通氣不足但仍有一些通氣；true shunt 是通氣幾乎為 0 但血流仍存在。","definition":"比較：low V/Q = V 減少但未消失，V/Q 低於正常；true shunt = V 接近 0、Q 仍存在，V/Q 接近 0。","equation":"V/Q = V/Q；當 V 逐漸下降到 0，low V/Q 會逐漸接近 shunt。","mechanism":"low V/Q 的肺泡仍可因提高 FiO2 得到一些改善；true shunt 的血流沒有接觸有效通氣肺泡，所以 oxygen response 差。","example":"asthma 或 early pneumonia 可造成 low V/Q；complete atelectasis 或肺泡被大量滲出液填滿時更接近 true shunt。","model":"模型應把 low V/Q 畫成通氣箭頭變小；shunt 則畫成通氣幾乎消失但灌流仍在。","clinical":"臨床上可用給氧反應輔助判斷：low V/Q 通常會改善，true shunt 改善較有限。","misconception":"不要把所有低氧都叫 shunt；只有通氣接近 0 且仍有血流時才接近 true shunt。","variant":"direct","unitItemNumber":11012},{"course":"high_vq","courseTitle":"課程 7：High V/Q、Dead Space 與 Pulmonary Embolism","courseGoal":"讓學生能分辨 high V/Q、alveolar dead space、physiologic dead space 與 PE。","concept":"high V/Q vs dead space","intent":"compare","aliases":["high V/Q vs dead space","high VQ vs dead space","high V/Q and dead space","高VQ 死腔 差別","dead-space-like","dead space like"],"questionPatterns":["差別","比較","vs","versus","difference","不同","分辨","一樣嗎"],"content":"High V/Q 和 dead space 位在同一條光譜上：high V/Q 是灌流相對不足；dead space 是灌流接近 0 但通氣仍存在。","definition":"比較：high V/Q = V 相對 Q 過多；alveolar dead space = Q 接近 0、V 仍存在，V/Q 趨近無限大。","equation":"V/Q = V/Q；當 Q 逐漸下降到接近 0，high V/Q 會接近 dead space。","mechanism":"perfusion 下降使通氣無法有效交換 CO2/O2，造成 wasted ventilation；局部 PACO2 會偏低。","example":"pulmonary embolism 使肺區血流下降，典型呈現 high V/Q 或 dead-space-like physiology。","model":"模型應顯示 ventilation arrow 保留，但 perfusion arrow 減少或消失。","clinical":"high V/Q/dead space 會降低 ventilatory efficiency，VD/VT 常上升。","misconception":"high V/Q 不是氧合一定變好；因為那個區域血流少，對總體 oxygen transfer 的貢獻有限。","variant":"direct","unitItemNumber":11013},{"course":"normal_vq","courseTitle":"課程 5：正常 V/Q 梯度與 V/Q Mismatch 基礎","courseGoal":"讓學生能用 ventilation/perfusion 比值判斷正常梯度、low V/Q、high V/Q 與 mismatch。","concept":"V/Q spectrum","intent":"mechanism","aliases":["V/Q spectrum","VQ spectrum","V/Q continuum","VQ continuum","VQ 光譜","V/Q 光譜","VQ 連續光譜","V/Q 連續光譜"],"questionPatterns":["為什麼","mechanism","機轉","光譜","連續","spectrum","continuum"],"content":"V/Q 可以看成一條連續光譜：一端是 shunt，另一端是 dead space，中間是不同程度的 V/Q mismatch。","definition":"V/Q spectrum 是把 V/Q mismatch 視為從 V/Q = 0 到 V/Q 趨近無限大的連續變化。","equation":"V/Q = 0 近似 shunt；V/Q 正常約 0.8；V/Q 很高到無限大則近似 dead space。","mechanism":"當 ventilation 相對 perfusion 下降，會往 low V/Q 或 shunt 方向走；當 perfusion 相對 ventilation 下降，會往 high V/Q 或 dead space 方向走。","example":"pneumonia 往 low V/Q/shunt 端；PE 往 high V/Q/dead space 端。","model":"模型可用水平軸呈現：shunt ← low V/Q ← normal V/Q → high V/Q → dead space。","clinical":"這個光譜能幫助學生不要把所有 mismatch 都混成同一種病理。","misconception":"V/Q mismatch 不是單一診斷，而是不同 V 與 Q 變化方向造成的一組生理狀態。","variant":"direct","unitItemNumber":11014},{"course":"shunt","courseTitle":"課程 8：Shunt 與分流生理","courseGoal":"讓學生能分辨 true shunt、anatomic shunt、physiologic shunt、oxygen response 與 shunt equation。","concept":"Qs/Qt","intent":"equation","aliases":["Qs/Qt","QS/QT","Q s Q t","shunt fraction","shunt ratio","分流比例","分流分率"],"questionPatterns":["公式","equation","ratio","比例","分率","怎麼算","calculate","計算"],"content":"Qs/Qt 是 shunt fraction，表示心輸出量中有多少比例沒有被有效氧合就進入 arterial circulation。","definition":"Qs/Qt 是分流比例；它用 oxygen content 的差距估計未有效氧合血流占總血流的比例。","equation":"Qs/Qt = (CcO2 - CaO2) / (CcO2 - CvO2)。CcO2 是理想肺泡末端微血管氧含量，CaO2 是動脈氧含量，CvO2 是混合靜脈氧含量。","mechanism":"CaO2 越低、越接近 CvO2，代表越多血流沒有完成氧合，shunt fraction 越高。","example":"若 pneumonia 造成部分肺區無有效通氣但仍有灌流，Qs/Qt 會增加。","model":"模型可在 arterial side 顯示氧合血與低氧分流血混合後的 CaO2。","clinical":"Qs/Qt 升高可用來量化分流嚴重度，並解釋 refractory hypoxemia。","misconception":"Qs/Qt 不是 VD/VT；前者算 shunt，後者算 dead space。","variant":"direct","unitItemNumber":11015}];
  (function installMainKBItemTermsFineGrained(){
    MAIN_KB_DOMAIN_ITEMS_V113.forEach(function(item){
      if(!EMBEDDED_FULL_KB[item.course]) EMBEDDED_FULL_KB[item.course]=[];
      const key = [item.course,item.concept,item.intent].join('|').toLowerCase();
      const exists = EMBEDDED_FULL_KB[item.course].some(function(x){
        return [x.course,x.concept,x.intent].join('|').toLowerCase() === key;
      });
      if(!exists) EMBEDDED_FULL_KB[item.course].unshift(item);
    });
  })();
  const COURSE_META = COURSE_ORDER.map(k=>{
    const arr = EMBEDDED_FULL_KB[k] || [];
    const first = arr[0] || {};
    return {key:k, title:first.courseTitle || k, goal:first.courseGoal || '', count:arr.length};
  });

  let rec = null;
  let finalTranscript = '';

  function meta(key){ return COURSE_META.find(x=>x.key===key) || COURSE_META[0]; }
  function selectedCourse(){ const sel=$('lessonSelect'); return (sel && sel.value) || COURSE_ORDER[0]; }
  function selectedTitle(){ return meta(selectedCourse()).title; }

  function stripPlaceholder(t){
    return String(t||'')
      .replace(/^學生問的問題會顯示在這裡。?$/,'')
      .replace(/^學生回答會顯示在這裡。?$/,'')
      .replace(/^AI 老師回答會顯示在這裡。?$/,'')
      .replace(/^正在聆聽[\.。…]*$/,'')
      .trim();
  }
  function getText(el){ return stripPlaceholder(el ? (el.innerText || el.textContent || el.value || '') : ''); }

  function fixTranscript(s){
    let t = String(s||'');
    const reps = [
      [/\bgalaxy\s+exchange\b/ig,'gas exchange'],[/\bgases\s+exchange\b/ig,'gas exchange'],[/\bguess\s+exchange\b/ig,'gas exchange'],[/\bguys\s+exchange\b/ig,'gas exchange'],[/\bgas\s+in\s+change\b/ig,'gas exchange'],[/\bgas\s+exchange\b/ig,'gas exchange'],[/\bchange\s+change\b/ig,'gas exchange'],[/\bcan\s+exchange\b/ig,'gas exchange'],[/\bgas\s+exchang\b/ig,'gas exchange'],[/蓋斯\s*exchange/ig,'gas exchange'],[/氣體\s*exchange/ig,'gas exchange'],
      [/\balveolar\s+(?:guest|guess|gases|gas)\s+equation\b/ig,'alveolar gas equation'],[/\balveolar\s+gas\s+equation\b/ig,'alveolar gas equation'],[/\balveolar\s+equation\b/ig,'alveolar gas equation'],
      [/oxygen\s*nation/ig,'oxygenation'],[/oxygen\s*asian/ig,'oxygenation'],[/oxygenization/ig,'oxygenation'],[/oxy\s*genation/ig,'oxygenation'],[/per\s*fusion/ig,'perfusion'],[/profusion/ig,'perfusion'],[/vent\s*relation/ig,'ventilation'],[/dead\s*(?:space|spade|spec|spac)/ig,'dead space'],[/cardiac\s*output/ig,'cardiac output'],[/mixed\s*venous/ig,'mixed venous'],[/destin/ig,'dead space'],[/deston/ig,'dead space'],
      [/v\s*\/\s*q/ig,'V/Q'],[/\bv\s*q\s*ratio\b/ig,'V/Q ratio'],[/high\s*v\s*q/ig,'high V/Q'],[/low\s*v\s*q/ig,'low V/Q'],
      [/PaCO₂/g,'PaCO2'],[/PaO₂/g,'PaO2'],[/FiO₂/g,'FiO2'],[/CaO₂/g,'CaO2'],[/SvO₂/g,'SvO2'],[/SaO₂/g,'SaO2'],[/O₂/g,'O2'],[/CO₂/g,'CO2'],
      [/paco\s*2/ig,'PaCO2'],[/pao\s*2/ig,'PaO2'],[/fio\s*2/ig,'FiO2'],[/cao\s*2/ig,'CaO2'],[/svo\s*2/ig,'SvO2'],[/sao\s*2/ig,'SaO2']
    ];
    reps.forEach(([a,b])=>{t=t.replace(a,b);});
    // Do not collapse all spaces around English terms too aggressively; only normalize repeated spaces.
    return t.replace(/dead\s+spacee/ig,'dead space').replace(/\s{2,}/g,' ').trim();
  }

  function norm(s){
    return fixTranscript(String(s||''))
      .toLowerCase()
      .replace(/[，。！？、；：]/g,' ')
      .replace(/[\[\]{}<>]/g,' ')
      .replace(/\s+/g,' ')
      .trim();
  }

  const OFF_TOPIC = ['股票','台積電','銀行','資產','投資','晚餐','天氣','手機','line','html','github','檔案','下載','白屏','薪水','起薪','履歷','公文'];
  const DOMAIN_TERMS = ['gas exchange','氣體交換','abg','blood gas','血氣','alveolar gas equation','alveolar','oxygenation','ventilation','通氣','alveolar ventilation','perfusion','灌流','v/q','vq','v q','v/q ratio','low v/q','high v/q','shunt','分流','dead space','死腔','diffusion','擴散','a-a','gradient','pao2','paco2','fio2','sao2','svo2','cao2','o2','co2','hemoglobin','hb','貧血','cardiac output','mixed venous','oxygen content','oxygen delivery','pe','pulmonary embolism','肺栓塞','pneumonia','肺炎','asthma','氣喘','copd','apex','base','肺泡','肺微血管','oxygen','carbon dioxide','呼吸','肺','酸鹼'];

  const DOMAIN_TERMS_FINE_GRAINED = ['anatomic shunt','anatomical shunt','physiologic shunt','physiological shunt','venous admixture','right-to-left shunt','right left shunt','qs/qt','shunt fraction','anatomic dead space','anatomical dead space','alveolar dead space','physiologic dead space','physiological dead space','vd/vt','bohr equation','bohr dead space equation','dead space fraction','v/q mismatch','vq mismatch','ventilation perfusion mismatch','ventilation-perfusion mismatch','v/q spectrum','vq spectrum','shunt-like','dead-space-like','解剖分流','生理分流','靜脈血混合','右到左分流','解剖死腔','肺泡死腔','生理死腔','死腔比例','死腔分率','分流比例','分流分率','通氣灌流不匹配','通氣灌流失衡','有氣沒血','有血沒氣'];
  DOMAIN_TERMS_FINE_GRAINED.forEach(function(t){ if(!DOMAIN_TERMS.includes(t)) DOMAIN_TERMS.push(t); });

  function titleTokens(course){
    return norm(meta(course).title).split(' ').filter(w=>w.length>=3 && !/^課程$|^與$/.test(w));
  }
  function domainEvidenceScore(q){
    const t=norm(fixTranscript(q));
    if(!t) return 0;
    let score=0;
    const strong = ['gas exchange','alveolar gas equation','oxygenation','ventilation','alveolar ventilation','perfusion','v/q','v/q ratio','low v/q','high v/q','shunt','dead space','diffusion','a-a gradient','pao2','paco2','fio2','sao2','svo2','cao2','hemoglobin','hb','cardiac output','mixed venous','oxygen content','oxygen delivery','pulmonary embolism','pneumonia','asthma','copd','abg','blood gas'];
    const zhStrong = ['氣體交換','肺泡氣','肺泡氧','氧合','通氣','肺泡通氣','灌流','分流','死腔','擴散','血氣','血紅素','貧血','心輸出','混合靜脈','氧含量','氧氣運輸','肺栓塞','肺炎','氣喘','肺泡','肺微血管','呼吸生理'];
    strong.forEach(k=>{ if(t.includes(norm(k))) score += 6; });
    zhStrong.forEach(k=>{ if(t.includes(norm(k))) score += 6; });

    DOMAIN_TERMS_FINE_GRAINED.forEach(function(k){ if(t.includes(norm(k))) score += 2; });
    if(/q\s*s\s*\/\s*q\s*t|qs\s*\/\s*qt|v\s*d\s*\/\s*v\s*t|vd\s*\/\s*vt/i.test(q)) score += 8;
    if(/通氣灌流(不匹配|失衡)|有氣沒血|有血沒氣|解剖分流|生理分流|解剖死腔|肺泡死腔|生理死腔/.test(q)) score += 8;
    // Generic words only add weak evidence; they cannot pass the guard alone.
    ['oxygen','o2','co2','肺','呼吸','酸鹼','apex','base','gradient'].forEach(k=>{ if(t.includes(norm(k))) score += 1; });
    COURSE_ORDER.forEach(course=>{
      titleTokens(course).forEach(tok=>{ if(tok.length>=4 && t.includes(tok)) score += 4; });
    });
    return score;
  }
  function questionHasDomain(q){
    return domainEvidenceScore(q) >= 1;
  }
  function obviousOffTopic(q){
    const t=norm(q);
    // Off-topic words only reject when there is no respiratory-domain evidence.
    return OFF_TOPIC.some(k=>t.includes(norm(k))) && !questionHasDomain(q);
  }
  function mostlyNonsense(q){
    const raw=String(q||'').trim();
    const t=norm(raw);
    if(questionHasDomain(raw)) return false;
    if(!t || t.length < 3) return true;
    const digits=(raw.match(/[0-9]/g)||[]).length;
    const letters=(raw.match(/[A-Za-z]/g)||[]).length;
    const cjk=(raw.match(/[\u4e00-\u9fff]/g)||[]).length;
    const filler=(raw.match(/(就是|然後|所以|這個|那個|嗯|呃|喔|餵|好像|不知道|什麼意思|請問)/g)||[]).join('').length;
    if(digits >= 5 && domainEvidenceScore(raw) < 11) return true;
    if((letters+cjk)>0 && filler/(letters+cjk+1) > 0.45 && domainEvidenceScore(raw) < 11) return true;
    if(/(餵){2,}|(嗯){2,}|幹嘛|幹什麼|隨便|亂問|123456/.test(raw) && domainEvidenceScore(raw) < 11) return true;
    // One unknown English word plus「是什麼意思」should not be treated as physiology.
    if(/^[\u4e00-\u9fff\s，,。?？]*(?:[A-Za-z]{4,})[\u4e00-\u9fff\s，,。?？]*$/.test(raw) && domainEvidenceScore(raw) < 11) return true;
    return false;
  }
  function tooVague(q){
    const t=norm(q);
    if(questionHasDomain(q)) return false;
    if(t.length < 3) return true;
    if(/^(嗯|呃|喔|好|所以|現在|幹嘛|幹什麼|不知道)$/i.test(t)) return true;
    if(/(餵){2,}|(嗯){2,}/.test(t)) return true;
    return mostlyNonsense(q);
  }

  function detectIntent(q){
    const t=norm(q); const out=[];
    if(/什麼意思|是什麼|何謂|define|definition|what is|意思|介紹|說明/.test(t)) out.push('definition');
    if(/為什麼|why|機轉|mechanism|造成|導致|原因|怎麼會|如何造成|生理/.test(t)) out.push('mechanism');
    if(/公式|equation|formula|怎麼算|計算|calculate|方程|qs\/?qt|vd\/?vt|bohr/.test(t)) out.push('equation');
    if(/臨床|clinical|病人|疾病|pe|pulmonary embolism|pneumonia|asthma|copd|肺炎|肺栓塞|氣喘|案例/.test(t)) out.push('clinical');
    if(/差別|比較|vs|versus|difference|不同|一樣嗎|分辨|有氣沒血|有血沒氣/.test(t)) out.push('compare');
    if(/圖|模型|model|visual|apex|base|肺區|顯示|畫/.test(t)) out.push('model');
    if(/錯|誤解|misconception|不是|搞不清楚|混淆|陷阱/.test(t)) out.push('misconception');
    if(!out.length) out.push('general');
    return out;
  }

  function detectCourse(q){
    const t=norm(fixTranscript(q));
    const selected=selectedCourse();
    let best={course:selected,score:0};
    COURSE_ORDER.forEach(course=>{
      let score=0;
      const arr=EMBEDDED_FULL_KB[course]||[];
      const m=meta(course);
      // Current selected course is only a small tie-breaker, not a hard restriction.
      if(course===selected) score += 2;
      titleTokens(course).forEach(tok=>{ if(tok.length>=4 && t.includes(tok)) score += 7; });
      const seen=new Set();
      const step=Math.max(1,Math.floor(arr.length/300));
      for(let i=0;i<arr.length;i+=step){
        const it=arr[i];
        const vals=[it.concept,...(it.aliases||[])].filter(Boolean);
        for(const v of vals){
          const nv=norm(v); if(!nv || seen.has(nv)) continue; seen.add(nv);
          if(t.includes(nv)) score += nv.length>5 ? 7 : 3;
        }
      }
      if(course==='basic' && /gas exchange|氣體交換|abg|blood gas|整體|架構|overview|基本/i.test(q)) score+=25;
      if(course==='alveolar_gas' && /alveolar gas equation|oxygenation|pao2|fio2|paco2|PAO2|肺泡氣|氧合|方程/i.test(q)) score+=25;
      if(course==='ventilation' && /ventilation|alveolar ventilation|respiratory rate|tidal volume|dead space|anatomic dead space|anatomical dead space|physiologic dead space|physiological dead space|vd\/?vt|bohr|paco2|通氣|肺泡通氣|潮氣|呼吸頻率|死腔|解剖死腔|生理死腔|死腔比例|死腔分率/i.test(q)) score+=22;
      if(course==='perfusion' && /perfusion|cardiac output|mixed venous|svo2|灌流|心輸出|混合靜脈/i.test(q)) score+=22;
      if(course==='normal_vq' && /v\/?q mismatch|vq mismatch|ventilation[- ]?perfusion mismatch|v\/?q spectrum|vq spectrum|apex|base|gradient|正常.*v\/?q|肺尖|肺底|normal v|通氣灌流不匹配|通氣灌流失衡/i.test(q)) score+=22;
      if(course==='low_vq' && /low\s*v\/?q|low\s*vq|shunt-like|低.*v\/?q|pneumonia|asthma|copd|肺炎|氣喘|low.*shunt|shunt.*low/i.test(q)) score+=22;
      if(course==='high_vq' && /high\s*v\/?q|high\s*vq|dead space|alveolar dead space|dead-space-like|pulmonary embolism|肺栓塞|pe|高.*v\/?q|肺泡死腔|有氣沒血/i.test(q)) score+=22;
      if(course==='shunt' && /true shunt|anatomic shunt|anatomical shunt|physiologic shunt|physiological shunt|right[- ]?to[- ]?left shunt|venous admixture|shunt equation|qs\/?qt|分流|解剖分流|生理分流|靜脈血混合|右到左分流|shunt|有血沒氣/i.test(q)) score+=22;
      if(course==='diffusion' && /diffusion|a-a|擴散|DLO2|A-a gradient/i.test(q)) score+=22;
      if(course==='oxygen_content' && /hemoglobin|hb|cao2|oxygen content|oxygen delivery|貧血|anemia|血紅素|氧含量/i.test(q)) score+=22;
      if(course==='integrated_disease' && /pe|pneumonia|asthma|copd|肺栓塞|肺炎|氣喘|疾病|整合/i.test(q)) score+=18;
      if(score>best.score) best={course,score};
    });
    return best.course;
  }

  function fields(it){
    return [it.courseTitle,it.courseGoal,it.concept,it.intent,it.variant,it.content,it.definition,it.equation,it.mechanism,it.example,it.model,it.clinical,it.misconception,...(it.aliases||[]),...(it.questionPatterns||[])].filter(Boolean).join(' ');
  }
  function aliasesHit(q, aliases){
    const t=norm(q); let count=0;
    (aliases||[]).forEach(a=>{ const na=norm(a); if(na && (t.includes(na)||na.includes(t))) count++; });
    return count;
  }
  function scoreItem(it,q,intents,course){
    const t=norm(q); const f=norm(fields(it)); let s=0;
    if(it.course===course) s+=45;
    if(intents.includes(it.intent)) s+=8; // v136 leftmost: intent_match 24→8
    if(intents.includes('compare') && /compare|comparison|vs|difference/i.test(it.intent+' '+it.concept+' '+it.content)) s+=0; // v136 leftmost: comparison 14→0
    const ah=aliasesHit(q,it.aliases); s+=Math.min(28,ah*7);
    const ph=aliasesHit(q,it.questionPatterns); s+=Math.min(0,ph*0); // v136 leftmost: question pattern 4→0, cap 12→0
    if(it.concept && t.includes(norm(it.concept))) s+=18;
    // Separate concept-specific scoring branch removed; concept matching remains in Main Knowledge scoring via concept exact match (+18).
    DOMAIN_TERMS.forEach(term=>{ const nt=norm(term); if(nt && t.includes(nt) && f.includes(nt)) s+=2; });
    if(/course|課程|基本|架構|oxygenation|equation|gas exchange/i.test(q) && ['definition','mechanism','equation'].includes(it.intent)) s+=0; // v136 leftmost: generic course intent 6→0
    if(['direct','plain','mechanism_chain','teacher_script','student_hint'].includes(it.variant)) s+=2;
    return s;
  }
  function retrieve(q,course,intents){
    // v58: retrieve across all courses. The detected course gets a bonus, but other courses can win.
    const all=[];
    COURSE_ORDER.forEach(c=>{
      const arr=EMBEDDED_FULL_KB[c]||[];
      for(const it of arr){
        let sc=scoreItem(it,q,intents,c);
        if(c===course) sc += 12;
        all.push({it, score:sc});
      }
    });
    let scored=all.sort((a,b)=>b.score-a.score);
    const minScore = questionHasDomain(q) ? 68 : 9999; // v151 Active-7 Main KB Gate
    let filtered = scored.filter(x=>x.score>=minScore);
    const seen=new Set(); const top=[];
    for(const x of filtered){
      const k2=[x.it.course,x.it.concept,x.it.intent].join('|');
      if(seen.has(k2) && top.length>=3) continue;
      seen.add(k2);
      top.push(x.it);
      if(top.length>=6) break;
    }
    return top;
  }

  // Legacy separate MainKB domain helper removed; all records are handled inside EMBEDDED_FULL_KB retrieval.
  function dominantCourse(items, fallback){
    const counts={};
    items.forEach(it=>{ counts[it.course]=(counts[it.course]||0)+1; });
    let best=fallback, n=0;
    Object.keys(counts).forEach(k=>{ if(counts[k]>n){best=k;n=counts[k];} });
    return best;
  }

  function compact(s,max){
    const t=String(s||'').replace(/\s+/g,' ').trim();
    if(!t) return '';
    return t.length>max ? t.slice(0,max-1)+'…' : t;
  }
  function courseIntro(course){
    const m=meta(course); const arr=EMBEDDED_FULL_KB[course]||[];
    const defs=[];
    for(const it of arr){
      if(it.intent==='definition' && it.definition && !defs.includes(it.definition)) defs.push(it.definition);
      if(defs.length>=4) break;
    }
    return '這題我會依「'+m.title+'」來回答。\n\n課程目的：'+(m.goal||'建立本單元核心呼吸生理判讀架構。')+'\n\n本課核心包含：\n- '+defs.map(x=>compact(x,80)).join('\n- ');
  }
  function inferMainConcept(items){
    if(!items.length) return '';
    const c=items[0].concept||'';
    return c ? '「'+c+'」' : '';
  }
  function isCourseOverviewQuestion(q){
    const t=norm(q);
    // v67: treat natural student confusion like「我看不懂這堂課在講什麼」as a course-intro request.
    // This should be answered directly, not rejected as off-topic.
    const s=String(q||'');
    return /(這個|目前|現在|本|這門|這堂|這節|這個單元)?(課程|課|堂課|單元|章節).{0,18}(講什麼|在講什麼|說什麼|內容|介紹|概覽|重點|目的|學什麼|在學什麼|overview|intro|introduction|content)/i.test(s)
      || /(不太清楚|不清楚|不知道|不懂|看不懂|聽不懂|搞不懂).{0,18}(課程|課|堂課|單元|章節).{0,18}(講什麼|內容|意思|重點|目的|在幹嘛|在做什麼|是什麼)/i.test(s)
      || /(課程|課|堂課|單元|章節).{0,18}(不太清楚|不清楚|不知道|不懂|看不懂|聽不懂|搞不懂)/i.test(s)
      || /course.*(about|overview|intro|introduction|content)/i.test(s)
      || /我不太清楚.*(講什麼|內容|意思)/.test(s);
  }

  function composeCourseOverview(course){
    const m=meta(course || selectedCourse());
    const arr=EMBEDDED_FULL_KB[m.key]||[];
    const defs=[]; const seen=new Set();
    for(const it of arr){
      const text=(it.definition || it.mechanism || it.content || '').trim();
      const key=text.toLowerCase().replace(/\s+/g,' ');
      if(text && !seen.has(key)){
        seen.add(key); defs.push(compact(text,90));
      }
      if(defs.length>=4) break;
    }
    const title=m.title || '目前課程';
    const goal=m.goal || '建立本單元的呼吸生理核心概念。';
    const points = defs.length ? defs.map(x=>'• '+x).join('\n') : '• 先建立本單元核心名詞。\n• 再連到生理機轉與臨床判讀。';
    return '這堂課主要在講「'+title.replace(/^課程\s*\d+\s*[：:]\s*/,'')+'」。\n\n'+
      '你可以把它想成這個單元的學習地圖：先抓住核心名詞，再理解它如何影響 PaO2、PaCO2、A-a gradient、V/Q ratio 或 oxygen content。\n\n'+
      '課程重點：\n'+points+'\n\n'+
      '如果你還不確定要從哪裡問，可以直接問：「這個概念是什麼？」、「為什麼會這樣？」或「臨床上要怎麼判斷？」';
  }

  function composeAnswer(original,restored,course,intents,items){
    const finalCourse = items && items.length ? dominantCourse(items, course) : course;
    const m=meta(finalCourse);
    const lines=[];
    if(!items.length){
      return composeCourseOverview(finalCourse);
    }
    const main=items[0];
    const concept=inferMainConcept(items);

    // v61: student-facing answer should not expose internal retrieval pipeline.
    // Do not show「我怎麼判斷、最相關課程、語音修正」unless necessary.
    const askingOverview = isCourseOverviewQuestion(restored);
    if(askingOverview) return composeCourseOverview(finalCourse);

    const isDef = intents.includes('definition') || /是什麼|什麼意思|介紹|說明|define|what is/i.test(restored);
    const isCompare = intents.includes('compare');
    const isEq = intents.includes('equation') || /equation|公式|pao2|paco2|fio2|calculate|計算|alveolar gas/i.test(restored);
    const isMech = intents.includes('mechanism') || intents.includes('general') || isDef || isCompare;
    const isClinical = intents.includes('clinical') || /pe|pneumonia|asthma|copd|病人|臨床|疾病|肺栓塞|肺炎|氣喘/i.test(restored);
    const isModel = intents.includes('model');

    if(isDef){
      lines.push((main.definition || main.content || m.goal || '這是本單元的核心概念。').trim());
    } else if(concept){
      lines.push(concept+'的重點是：'+compact(main.definition || main.content || m.goal,360));
    } else {
      lines.push(compact(main.definition || main.content || m.goal,420));
    }

    if(isEq && main.equation) lines.push('\n公式／數值關係：\n'+compact(main.equation,360));
    if(isMech && main.mechanism) lines.push('\n機轉：\n'+compact(main.mechanism,460));
    if(main.example) lines.push('\n例子：\n'+compact(main.example,340));
    if(isClinical && main.clinical) lines.push('\n臨床連結：\n'+compact(main.clinical,380));
    if(isModel && main.model) lines.push('\n模型上可以這樣看：\n'+compact(main.model,360));
    if(main.misconception) lines.push('\n不要搞混：\n'+compact(main.misconception,340));

    const related=[];
    const relatedSeen=new Set();
    for(const x of items.slice(1)){
      const conceptName=String(x.concept||'').trim();
      if(conceptName && conceptName===main.concept) continue;
      let d=x.definition||x.mechanism||x.equation||x.content||'';
      const body=compact(d,150);
      if(!body) continue;
      const key=(conceptName+'|'+body).toLowerCase().replace(/\s+/g,' ');
      if(relatedSeen.has(key)) continue;
      relatedSeen.add(key);
      related.push((conceptName?conceptName+'：':'')+body);
      if(related.length>=3) break;
    }
    if(related.length){ lines.push('\n相關補充：'); related.forEach((r,i)=>lines.push((i+1)+'. '+r)); }

    const summary = '一句話總結：'+compact(main.mechanism || main.definition || main.content || m.goal,140);
    if(!lines.join('\n').includes(summary)) lines.push('\n'+summary);
    return lines.join('\n');
  }

  async function answerQuestion(raw){
    const original=String(raw||'').trim();
    if(!original) return '請先在左側 STUDENT QUESTION 完整輸入問題，再按「送出文字問題」。';
    const restored=fixTranscript(original);
    if(isCourseOverviewQuestion(restored)){
      const c=detectCourse(restored);
      return composeCourseOverview(c || selectedCourse());
    }
    const ev=domainEvidenceScore(restored);
    if(obviousOffTopic(restored) || ev < 2 || mostlyNonsense(restored)){
      return '這個問題目前超出本系統的呼吸生理／gas exchange 課程範圍，或缺少明確的課程概念，因此我不會硬套知識庫亂回答。\n\n你可以改問：gas exchange、alveolar ventilation、V/Q ratio、low V/Q、high V/Q、shunt、dead space、diffusion limitation、A-a gradient、PaO2、PaCO2、FiO2、hemoglobin、oxygen content、pulmonary embolism、pneumonia、asthma 或 COPD。';
    }
    if(tooVague(restored)){
      return '我目前無法判斷你要問的概念。請把問題寫得更明確，例如：「請問 gas exchange 是什麼意思？」、「Alveolar Gas Equation 怎麼用？」或「肺栓塞為什麼是 high V/Q？」';
    }
    const course=detectCourse(restored);
    const intents=detectIntent(restored);
    const items=retrieve(restored,course,intents);
    if(!items.length){
      return '這個問題雖然看起來可能和呼吸生理有關，但目前知識庫找不到足夠對應內容，所以我不會硬答。請補上更明確的關鍵字，例如 ventilation、perfusion、V/Q、shunt、dead space、diffusion、PaO2 或 PaCO2。';
    }
    return composeAnswer(original,restored,course,intents,items);
  }

  function setQuestionText(text){
    const q=$('studentQuestion'); if(!q) return;
    const clean = fixTranscript(text || '').trim();
    q.classList && q.classList.remove('placeholder-like','listening-mode');
    if(!clean || clean === '正在聆聽...' || clean === '正在聆聽…'){
      q.textContent = '';
      q.removeAttribute('data-live-text');
      return;
    }
    q.textContent = clean;
    q.setAttribute('data-live-text', clean);
  }
  function setAnswer(text){
    const a=$('teacherAnswer'); if(!a) return;
    a.classList && a.classList.remove('placeholder-like','typewriter-active');
    a.textContent=String(text||'');
    a.scrollTop=0;
  }
  function speak(text){
    try{
      if(window.v50Speak) return window.v50Speak(text);
      if('speechSynthesis' in window){
        speechSynthesis.cancel(); const u=new SpeechSynthesisUtterance(text); u.lang='zh-TW'; speechSynthesis.speak(u);
      }
    }catch(e){}
  }
  async function submit(){
    const q=getText($('studentQuestion'));
    setQuestionText(q);
    setAnswer('AI 老師正在依目前課程與知識庫判斷問題...');
    const ans=await answerQuestion(q);
    setAnswer(ans); // v55: no character-by-character typing; prevents English terms from being visually swallowed.
    setTimeout(()=>speak(ans),200);
  }

  function startRecognition(){
    const SR=window.SpeechRecognition || window.webkitSpeechRecognition;
    const qBox=$('studentQuestion');
    if(!SR){ setAnswer('此瀏覽器不支援 SpeechRecognition。請改用 Chrome / Edge，或直接輸入文字問題。'); return; }
    try{ if(rec) rec.stop(); }catch(e){}
    finalTranscript='';
    rec=new SR(); rec.lang='zh-TW'; rec.interimResults=true; rec.continuous=true;
    const ask=$('askBtn'), stop=$('stopAskBtn');
    if(ask) ask.disabled=true; if(stop) stop.disabled=false;
    if(qBox){
      qBox.classList.add('listening-mode');
      if(!getText(qBox)) qBox.setAttribute('data-placeholder','正在聆聽中，請開始說話…');
    }
    rec.onresult=e=>{
      let interim='';
      for(let i=e.resultIndex;i<e.results.length;i++){
        const txt=e.results[i][0].transcript;
        if(e.results[i].isFinal) finalTranscript += txt + ' '; else interim += txt;
      }
      const heard=(finalTranscript + interim).trim();
      if(heard) setQuestionText(heard);
    };
    rec.onerror=e=>{
      const err=e.error||'unknown';
      const intentional = (err === 'aborted' || err === 'no-speech');
      if(qBox){
        qBox.classList.remove('listening-mode');
        qBox.setAttribute('data-placeholder','請在這裡輸入問題，或按「學生開始提問」使用語音。');
        // 若是送出問題造成的正常停止，不要把學生已輸入/已辨識文字清掉。
        if(!intentional && !finalTranscript.trim()) qBox.textContent='';
      }
      if(ask) ask.disabled=false; if(stop) stop.disabled=true;
      // Chrome 在程式主動停止 SpeechRecognition 時常回報 aborted。這不是錯誤，不應覆蓋 AI 回答。
      if(intentional){
        setStatus('語音輸入已停止，正在處理目前問題');
        return;
      }
      setAnswer('語音辨識發生錯誤：'+err+'。可改用文字輸入。');
    };
    rec.onend=()=>{
      if(ask) ask.disabled=false; if(stop) stop.disabled=true;
      if(qBox){ qBox.classList.remove('listening-mode'); qBox.setAttribute('data-placeholder','請在這裡輸入問題，或按「學生開始提問」使用語音。'); }
      const q=getText(qBox);
      if(q && q!=='正在聆聽...' && q!=='正在聆聽…') setQuestionText(q);
      else if(qBox) qBox.textContent='';
    };
    try{ rec.start(); }
    catch(e){
      if(qBox){ qBox.classList.remove('listening-mode'); qBox.setAttribute('data-placeholder','請在這裡輸入問題，或按「學生開始提問」使用語音。'); qBox.textContent=''; }
      if(ask) ask.disabled=false; if(stop) stop.disabled=true;
      setAnswer('語音辨識啟動失敗。可改用文字輸入。');
    }
  }
  function stopRecognitionAndSubmit(){
    try{ if(rec) rec.stop(); }catch(e){}
    setTimeout(()=>{
      const q=getText($('studentQuestion'));
      if(!q || q==='正在聆聽...' || q==='正在聆聽…'){
        setQuestionText('');
        setAnswer('沒有收到語音內容。請重新按「學生開始提問」，或直接用文字輸入問題。');
        return;
      }
      submit();
    },450);
  }

  function applyStyleFix(){
    const css=`
#studentQuestion,#studentCaseAnswer,#teacherAnswer,#caseFeedback,#lessonText{
  white-space:pre-wrap !important;
  word-break:keep-all !important;
  overflow-wrap:normal !important;
  line-break:auto !important;
  text-rendering:optimizeLegibility;
}
#studentQuestion,#teacherAnswer{font-family:"Microsoft JhengHei","Noto Sans TC","Segoe UI",Arial,sans-serif !important;}
#studentQuestion{position:relative; min-height:180px;}
#studentQuestion:empty::before{content:attr(data-placeholder); color:#94a3b8; pointer-events:none;}
#studentQuestion:focus:empty::before{content:"";}
#studentQuestion.listening-mode{border-style:dashed !important; background:#eef6ff !important;}
`;
    const st=document.createElement('style'); st.textContent=css; document.head.appendChild(st);
  }
  function bind(){
    applyStyleFix();
    ['studentQuestion','studentCaseAnswer','teacherAnswer','caseFeedback'].forEach(id=>{ const el=$(id); if(el){ el.style.whiteSpace='pre-wrap'; el.style.wordBreak='normal'; el.style.overflowWrap='break-word'; }});
    const q=$('studentQuestion'); if(q){
      q.setAttribute('contenteditable','true');
      q.setAttribute('data-placeholder','請在這裡輸入問題，或按「學生開始提問」使用語音。');
      if(stripPlaceholder(q.textContent).trim()==='學生問的問題會顯示在這裡。') q.textContent='';
      q.addEventListener('focus',()=>{
        if(stripPlaceholder(q.textContent).trim()==='學生問的問題會顯示在這裡。' || stripPlaceholder(q.textContent).trim()==='正在聆聽...') q.textContent='';
      });
      q.addEventListener('input',()=>{ q.classList&&q.classList.remove('placeholder-like','listening-mode'); q.setAttribute('data-placeholder','請在這裡輸入問題，或按「學生開始提問」使用語音。'); });
      q.addEventListener('blur',()=>{ if(!getText(q)) q.textContent=''; });
    }
    const send=$('submitTypedQuestionBtn'); if(send) send.onclick=e=>{e.preventDefault(); submit();};
    const ask=$('askBtn'); if(ask) ask.onclick=e=>{e.preventDefault(); startRecognition();};
    const stop=$('stopAskBtn'); if(stop) stop.onclick=e=>{e.preventDefault(); stopRecognitionAndSubmit();};
    const clear=$('clearBtn'); if(clear) clear.onclick=e=>{e.preventDefault(); try{ if('speechSynthesis' in window) speechSynthesis.cancel(); if(rec) rec.stop(); }catch(_){ } setQuestionText(''); setAnswer('AI 老師回答會顯示在這裡。');};
    const st=$('status'); if(st) st.textContent='狀態：Shunt/Dead Space/VQ mismatch 細分 KB 補強版已載入';
    window.VQ_V55_answerQuestion=answerQuestion; window.VQ_V55_submit=submit;
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',()=>setTimeout(bind,100)); else setTimeout(bind,100);
})();
