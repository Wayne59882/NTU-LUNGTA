# Formal Main KB weight selection

This section contains the formal weight-selection analysis.

## Calibration

The ten candidate scoring factors were calibrated once on the original
50-question set using the historical fixed-Top-1 OFAT protocol with Gate 97.

For each factor, the selected formal weight is the left edge of the
highest-F1 plateau:

45, 8, 0, 7, 0, 18, 2, 0, 2, 12.

The three zero-weight factors were excluded from the final Active-7 model.

## Validation

The weights are locked after calibration. Adding 150 validation questions
does not trigger a new weight-selection OFAT. The same formal weights are
applied to Original 50Q, Added 150Q and Total 200Q.

After the weights were fixed, the complete model was rerun and the final
Top-1 score threshold was swept separately. This produced Main KB Gate 68.

Do not add OFAT plateau values across factors, and do not interpret
post-hoc robustness ranges as replacement weights.
