const fs = require('fs');
const path = require('path');

const root = '/mnt/data/01_VQ_TA_v153_GITHUB_READY';
const outDir = '/mnt/data/_v168_basic_eval';
fs.rmSync(outDir, {recursive:true, force:true});
fs.mkdirSync(outDir, {recursive:true});

const questions = JSON.parse(fs.readFileSync('/mnt/data/_v167_questions.json','utf8'));
const engine = fs.readFileSync(path.join(root,'js/03_qa_engine.js'),'utf8');
const KB = JSON.parse(fs.readFileSync(path.join(root,'data/full_kb.json'),'utf8'));
const COURSE_ORDER = ['basic','ventilation','alveolar_gas','perfusion','normal_vq','low_vq','high_vq','shunt','diffusion','oxygen_content','integrated_disease'];
const suppMatch = engine.match(/const MAIN_KB_DOMAIN_ITEMS_V113 = (\[.*?\]);\n  \(function install/s);
if(!suppMatch) throw new Error('Supplemental KB items not found');
const SUPP = JSON.parse(suppMatch[1]);
SUPP.forEach(item=>{
  if(!KB[item.course]) KB[item.course]=[];
  const key=[item.course,item.concept,item.intent].join('|').toLowerCase();
  const exists=KB[item.course].some(x=>[x.course,x.concept,x.intent].join('|').toLowerCase()===key);
  if(!exists) KB[item.course].unshift({...item, __source:'runtime_supplement_v113'});
});
Object.values(KB).forEach(arr=>arr.forEach(x=>{if(!x.__source)x.__source='base_kb';}));

const DOMAIN_TERMS = ['gas exchange','氣體交換','abg','blood gas','血氣','alveolar gas equation','alveolar','oxygenation','ventilation','通氣','alveolar ventilation','perfusion','灌流','v/q','vq','v q','v/q ratio','low v/q','high v/q','shunt','分流','dead space','死腔','diffusion','擴散','a-a','gradient','pao2','paco2','fio2','sao2','svo2','cao2','o2','co2','hemoglobin','hb','貧血','cardiac output','mixed venous','oxygen content','oxygen delivery','pe','pulmonary embolism','肺栓塞','pneumonia','肺炎','asthma','氣喘','copd','apex','base','肺泡','肺微血管','oxygen','carbon dioxide','呼吸','肺','酸鹼'];
const FINE = ['anatomic shunt','anatomical shunt','physiologic shunt','physiological shunt','venous admixture','right-to-left shunt','right left shunt','qs/qt','shunt fraction','anatomic dead space','anatomical dead space','alveolar dead space','physiologic dead space','physiological dead space','vd/vt','bohr equation','bohr dead space equation','dead space fraction','v/q mismatch','vq mismatch','ventilation perfusion mismatch','ventilation-perfusion mismatch','v/q spectrum','vq spectrum','shunt-like','dead-space-like','解剖分流','生理分流','靜脈血混合','右到左分流','解剖死腔','肺泡死腔','生理死腔','死腔比例','死腔分率','分流比例','分流分率','通氣灌流不匹配','通氣灌流失衡','有氣沒血','有血沒氣'];
FINE.forEach(t=>{if(!DOMAIN_TERMS.includes(t))DOMAIN_TERMS.push(t);});
const STRONG = ['gas exchange','alveolar gas equation','oxygenation','ventilation','alveolar ventilation','perfusion','v/q','v/q ratio','low v/q','high v/q','shunt','dead space','diffusion','a-a gradient','pao2','paco2','fio2','sao2','svo2','cao2','hemoglobin','hb','cardiac output','mixed venous','oxygen content','oxygen delivery','pulmonary embolism','pneumonia','asthma','copd','abg','blood gas'];
const ZHSTRONG = ['氣體交換','肺泡氣','肺泡氧','氧合','通氣','肺泡通氣','灌流','分流','死腔','擴散','血氣','血紅素','貧血','心輸出','混合靜脈','氧含量','氧氣運輸','肺栓塞','肺炎','氣喘','肺泡','肺微血管','呼吸生理'];
const WEAK = ['oxygen','o2','co2','肺','呼吸','酸鹼','apex','base','gradient'];

function fixTranscript(s){
  let t=String(s||'');
  const reps=[
    [/\bgalaxy\s+exchange\b/ig,'gas exchange'],[/\bgases\s+exchange\b/ig,'gas exchange'],[/\bguess\s+exchange\b/ig,'gas exchange'],[/\bguys\s+exchange\b/ig,'gas exchange'],[/\bgas\s+in\s+change\b/ig,'gas exchange'],[/\bgas\s+exchange\b/ig,'gas exchange'],[/\bchange\s+change\b/ig,'gas exchange'],[/\bcan\s+exchange\b/ig,'gas exchange'],[/\bgas\s+exchang\b/ig,'gas exchange'],[/蓋斯\s*exchange/ig,'gas exchange'],[/氣體\s*exchange/ig,'gas exchange'],
    [/\balveolar\s+(?:guest|guess|gases|gas)\s+equation\b/ig,'alveolar gas equation'],[/\balveolar\s+gas\s+equation\b/ig,'alveolar gas equation'],[/\balveolar\s+equation\b/ig,'alveolar gas equation'],
    [/oxygen\s*nation/ig,'oxygenation'],[/oxygen\s*asian/ig,'oxygenation'],[/oxygenization/ig,'oxygenation'],[/oxy\s*genation/ig,'oxygenation'],[/per\s*fusion/ig,'perfusion'],[/profusion/ig,'perfusion'],[/vent\s*relation/ig,'ventilation'],[/dead\s*(?:space|spade|spec|spac)/ig,'dead space'],[/cardiac\s*output/ig,'cardiac output'],[/mixed\s*venous/ig,'mixed venous'],
    [/v\s*\/\s*q/ig,'V/Q'],[/\bv\s*q\s*ratio\b/ig,'V/Q ratio'],[/high\s*v\s*q/ig,'high V/Q'],[/low\s*v\s*q/ig,'low V/Q'],
    [/PaCO₂/g,'PaCO2'],[/PaO₂/g,'PaO2'],[/FiO₂/g,'FiO2'],[/CaO₂/g,'CaO2'],[/SvO₂/g,'SvO2'],[/SaO₂/g,'SaO2'],[/O₂/g,'O2'],[/CO₂/g,'CO2'],
    [/paco\s*2/ig,'PaCO2'],[/pao\s*2/ig,'PaO2'],[/fio\s*2/ig,'FiO2'],[/cao\s*2/ig,'CaO2'],[/svo\s*2/ig,'SvO2'],[/sao\s*2/ig,'SaO2']
  ];
  reps.forEach(([a,b])=>{t=t.replace(a,b);});
  return t.replace(/dead\s+spacee/ig,'dead space').replace(/\s{2,}/g,' ').trim();
}
function norm(s){return fixTranscript(String(s||'')).toLowerCase().replace(/[，。！？、；：]/g,' ').replace(/[\[\]{}<>]/g,' ').replace(/\s+/g,' ').trim();}

const COURSE_META=COURSE_ORDER.map(k=>{const arr=KB[k]||[];const first=arr[0]||{};return {key:k,title:first.courseTitle||k,goal:first.courseGoal||'',count:arr.length};});
function meta(key){return COURSE_META.find(x=>x.key===key)||COURSE_META[0];}
function titleTokens(course){return norm(meta(course).title).split(' ').filter(w=>w.length>=3&&!/^課程$|^與$/.test(w));}

function domainAudit(q){
  const t=norm(fixTranscript(q));
  const groups=[]; let score=0;
  const add=(category,term,points,source)=>{groups.push({category,term,points,source});score+=points;};
  STRONG.forEach(k=>{if(t.includes(norm(k)))add('strong_en',k,6,'strong[]');});
  ZHSTRONG.forEach(k=>{if(t.includes(norm(k)))add('strong_zh',k,6,'zhStrong[]');});
  FINE.forEach(k=>{if(t.includes(norm(k)))add('domain_term',k,2,'DOMAIN_TERMS_FINE_GRAINED');});
  if(/q\s*s\s*\/\s*q\s*t|qs\s*\/\s*qt|v\s*d\s*\/\s*v\s*t|vd\s*\/\s*vt/i.test(q))add('ratio_regex','Qs/Qt or VD/VT regex',8,'ratio regex');
  if(/通氣灌流(不匹配|失衡)|有氣沒血|有血沒氣|解剖分流|生理分流|解剖死腔|肺泡死腔|生理死腔/.test(q))add('zh_special_regex','Chinese special physiology regex',8,'zh special regex');
  WEAK.forEach(k=>{if(t.includes(norm(k)))add('weak_generic',k,1,'weak generic[]');});
  COURSE_ORDER.forEach(course=>titleTokens(course).forEach(tok=>{if(tok.length>=4&&t.includes(tok))add('course_title_token',tok,4,`titleTokens(${course})`);}));
  return {score,pass:score>=1,hits:groups,hitCount:groups.length,groupCount:new Set(groups.map(x=>x.category)).size};
}

function detectIntent(q){const t=norm(q);const out=[];if(/什麼意思|是什麼|何謂|define|definition|what is|意思|介紹|說明/.test(t))out.push('definition');if(/為什麼|why|機轉|mechanism|造成|導致|原因|怎麼會|如何造成|生理/.test(t))out.push('mechanism');if(/公式|equation|formula|怎麼算|計算|calculate|方程|qs\/?qt|vd\/?vt|bohr/.test(t))out.push('equation');if(/臨床|clinical|病人|疾病|pe|pulmonary embolism|pneumonia|asthma|copd|肺炎|肺栓塞|氣喘|案例/.test(t))out.push('clinical');if(/差別|比較|vs|versus|difference|不同|一樣嗎|分辨|有氣沒血|有血沒氣/.test(t))out.push('compare');if(/圖|模型|model|visual|apex|base|肺區|顯示|畫/.test(t))out.push('model');if(/錯|誤解|misconception|不是|搞不清楚|混淆|陷阱/.test(t))out.push('misconception');if(!out.length)out.push('general');return out;}

// Precompute detection samples and scoring fields.
const detectionSamples={};
const candidateRecords=[];
let globalId=0;
COURSE_ORDER.forEach(course=>{
  const arr=KB[course]||[];
  const seen=new Set(); const sample=[];
  const step=Math.max(1,Math.floor(arr.length/300));
  for(let i=0;i<arr.length;i+=step){
    const it=arr[i];
    const vals=[it.concept,...(it.aliases||[])].filter(Boolean);
    for(const v of vals){const nv=norm(v);if(!nv||seen.has(nv))continue;seen.add(nv);sample.push(nv);}
  }
  detectionSamples[course]=sample;
  arr.forEach((it,index)=>{
    globalId++;
    const aliases=(it.aliases||[]).map(a=>({raw:a,norm:norm(a)}));
    const patterns=(it.questionPatterns||[]).map(a=>({raw:a,norm:norm(a)}));
    const fieldText=[it.courseTitle,it.courseGoal,it.concept,it.intent,it.variant,it.content,it.definition,it.equation,it.mechanism,it.example,it.model,it.clinical,it.misconception,...(it.aliases||[]),...(it.questionPatterns||[])].filter(Boolean).join(' ');
    candidateRecords.push({globalId,course,index,it,aliases,patterns,conceptNorm:norm(it.concept||''),fieldNorm:norm(fieldText)});
  });
});
const domainTermNorms=DOMAIN_TERMS.map(raw=>({raw,norm:norm(raw)}));

function detectCourse(q,selected='basic'){
  const t=norm(fixTranscript(q)); let best={course:selected,score:0}; const all={};
  COURSE_ORDER.forEach(course=>{
    let score=0;
    if(course===selected)score+=2;
    titleTokens(course).forEach(tok=>{if(tok.length>=4&&t.includes(tok))score+=7;});
    detectionSamples[course].forEach(nv=>{if(t.includes(nv))score+=nv.length>5?7:3;});
    if(course==='basic'&&/gas exchange|氣體交換|abg|blood gas|整體|架構|overview|基本/i.test(q))score+=25;
    if(course==='alveolar_gas'&&/alveolar gas equation|oxygenation|pao2|fio2|paco2|PAO2|肺泡氣|氧合|方程/i.test(q))score+=25;
    if(course==='ventilation'&&/ventilation|alveolar ventilation|respiratory rate|tidal volume|dead space|anatomic dead space|anatomical dead space|physiologic dead space|physiological dead space|vd\/?vt|bohr|paco2|通氣|肺泡通氣|潮氣|呼吸頻率|死腔|解剖死腔|生理死腔|死腔比例|死腔分率/i.test(q))score+=22;
    if(course==='perfusion'&&/perfusion|cardiac output|mixed venous|svo2|灌流|心輸出|混合靜脈/i.test(q))score+=22;
    if(course==='normal_vq'&&/v\/?q mismatch|vq mismatch|ventilation[- ]?perfusion mismatch|v\/?q spectrum|vq spectrum|apex|base|gradient|正常.*v\/?q|肺尖|肺底|normal v|通氣灌流不匹配|通氣灌流失衡/i.test(q))score+=22;
    if(course==='low_vq'&&/low\s*v\/?q|low\s*vq|shunt-like|低.*v\/?q|pneumonia|asthma|copd|肺炎|氣喘|low.*shunt|shunt.*low/i.test(q))score+=22;
    if(course==='high_vq'&&/high\s*v\/?q|high\s*vq|dead space|alveolar dead space|dead-space-like|pulmonary embolism|肺栓塞|pe|高.*v\/?q|肺泡死腔|有氣沒血/i.test(q))score+=22;
    if(course==='shunt'&&/true shunt|anatomic shunt|anatomical shunt|physiologic shunt|physiological shunt|right[- ]?to[- ]?left shunt|venous admixture|shunt equation|qs\/?qt|分流|解剖分流|生理分流|靜脈血混合|右到左分流|shunt|有血沒氣/i.test(q))score+=22;
    if(course==='diffusion'&&/diffusion|a-a|擴散|DLO2|A-a gradient/i.test(q))score+=22;
    if(course==='oxygen_content'&&/hemoglobin|hb|cao2|oxygen content|oxygen delivery|貧血|anemia|血紅素|氧含量/i.test(q))score+=22;
    if(course==='integrated_disease'&&/pe|pneumonia|asthma|copd|肺栓塞|肺炎|氣喘|疾病|整合/i.test(q))score+=18;
    all[course]=score;
    if(score>best.score)best={course,score};
  });
  return {best,all};
}

function scoreQuestion(q){
  const qn=norm(q); const intents=detectIntent(q); const detection=detectCourse(q,'basic'); const detected=detection.best.course;
  const qDomainTerms=domainTermNorms.filter(x=>x.norm&&qn.includes(x.norm));
  const candidates=[];
  candidateRecords.forEach(rec=>{
    const aliasHits=rec.aliases.filter(x=>x.norm&&(qn.includes(x.norm)||x.norm.includes(qn))).map(x=>x.raw);
    const patternHits=rec.patterns.filter(x=>x.norm&&(qn.includes(x.norm)||x.norm.includes(qn))).map(x=>x.raw);
    const overlapHits=qDomainTerms.filter(x=>rec.fieldNorm.includes(x.norm)).map(x=>x.raw);
    const components={
      course_base:45,
      intent_match:intents.includes(rec.it.intent)?8:0,
      comparison_text_match:0,
      alias_hit:Math.min(28,aliasHits.length*7),
      question_pattern_hit:0,
      concept_exact:(rec.conceptNorm&&qn.includes(rec.conceptNorm))?18:0,
      domain_terms_overlap:overlapHits.length*2,
      generic_course_intent:0,
      response_variant:['direct','plain','mechanism_chain','teacher_script','student_hint'].includes(rec.it.variant)?2:0,
      detected_course_bonus:rec.course===detected?12:0
    };
    const score=Object.values(components).reduce((a,b)=>a+b,0);
    candidates.push({score,rec,components,aliasHits,patternHits,overlapHits});
  });
  candidates.sort((a,b)=>b.score-a.score);
  const passing=candidates.filter(x=>x.score>=68);
  const seen=new Set(); const returned=[];
  for(const x of passing){
    const key=[x.rec.it.course,x.rec.it.concept,x.rec.it.intent].join('|');
    if(seen.has(key)&&returned.length>=3)continue;
    seen.add(key); returned.push(x);
    if(returned.length>=6)break;
  }
  return {intents,detection,top1:candidates[0],passing,returned};
}

function resultLabel(truth,pred){return truth?(pred?'TP':'FN'):(pred?'FP':'TN');}
function csvEscape(value){if(value===null||value===undefined)return '';let s=String(value);if(/[",\n\r]/.test(s))s='"'+s.replace(/"/g,'""')+'"';return s;}
const passStream=fs.createWriteStream(path.join(outDir,'all_passing_candidates.csv'));
const passHeaders=['dataset','qid','label','rank','global_id','source','course','unit_item_number','concept','intent','variant','score','course_base','intent_match','comparison_text_match','alias_hit','question_pattern_hit','concept_exact','domain_terms_overlap','generic_course_intent','response_variant','detected_course_bonus','alias_hits','domain_overlap_hits'];
passStream.write(passHeaders.join(',')+'\n');
const evaluations=[];
let totalPassing=0;
for(const qrow of questions){
  const domain=domainAudit(qrow.question);
  const kbEval=scoreQuestion(qrow.question);
  const top=kbEval.top1;
  const predKB=domain.pass&&top.score>=68;
  const topSummary={
    global_id:top.rec.globalId,source:top.rec.it.__source,course:top.rec.it.course,courseTitle:top.rec.it.courseTitle,courseGoal:top.rec.it.courseGoal,unitItemNumber:top.rec.it.unitItemNumber,concept:top.rec.it.concept,intent:top.rec.it.intent,variant:top.rec.it.variant,score:top.score,components:top.components,aliasHits:top.aliasHits,questionPatternHits:top.patternHits,conceptExact:top.components.concept_exact>0,domainOverlapHits:top.overlapHits
  };
  const returned=kbEval.returned.map((x,index)=>({rank:index+1,global_id:x.rec.globalId,source:x.rec.it.__source,course:x.rec.it.course,unitItemNumber:x.rec.it.unitItemNumber,concept:x.rec.it.concept,intent:x.rec.it.intent,variant:x.rec.it.variant,score:x.score,components:x.components,aliasHits:x.aliasHits,domainOverlapHits:x.overlapHits}));
  evaluations.push({...qrow,selected_course_context:'basic',domain:{...domain,result:resultLabel(!!qrow.expected_domain,domain.pass)},detected_intents:kbEval.intents,detected_course:kbEval.detection.best.course,detected_course_score:kbEval.detection.best.score,detected_course_scores:kbEval.detection.all,top1:topSummary,passing_candidate_count:kbEval.passing.length,returned_top6:returned,kb_prediction:predKB,kb_result:resultLabel(!!qrow.expected_kb,predKB)});
  totalPassing+=kbEval.passing.length;
  kbEval.passing.forEach((x,index)=>{
    const row=[qrow.dataset,qrow.qid,qrow.label,index+1,x.rec.globalId,x.rec.it.__source,x.rec.it.course,x.rec.it.unitItemNumber,x.rec.it.concept,x.rec.it.intent,x.rec.it.variant,x.score,x.components.course_base,x.components.intent_match,x.components.comparison_text_match,x.components.alias_hit,x.components.question_pattern_hit,x.components.concept_exact,x.components.domain_terms_overlap,x.components.generic_course_intent,x.components.response_variant,x.components.detected_course_bonus,x.aliasHits.join('; '),x.overlapHits.join('; ')];
    passStream.write(row.map(csvEscape).join(',')+'\n');
  });
}
passStream.end();
fs.writeFileSync(path.join(outDir,'evaluations.json'),JSON.stringify(evaluations,null,2));
fs.writeFileSync(path.join(outDir,'metadata.json'),JSON.stringify({question_count:questions.length,kb_items:candidateRecords.length,total_passing_candidates:totalPassing,selected_course_context:'basic',source:'v153 js/03_qa_engine.js'},null,2));
console.log(JSON.stringify({questions:questions.length,kb_items:candidateRecords.length,totalPassing},null,2));
