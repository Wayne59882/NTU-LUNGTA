# Final method verification — v170

- PASS: Formal selected weights — expected [45, 8, 0, 7, 0, 18, 2, 0, 2, 12]; actual [45, 8, 0, 7, 0, 18, 2, 0, 2, 12].
- PASS: Selected weights equal OFAT plateau left edges — expected [45, 8, 0, 7, 0, 18, 2, 0, 2, 12]; actual [45, 8, 0, 7, 0, 18, 2, 0, 2, 12].
- PASS: Weights locked across Original50/Added150/Total200 — expected All identical; actual True.
- PASS: Formal Original50 Main KB plateau — expected 68-93; actual 68-93.
- PASS: Formal Added150 Main KB plateau — expected 68-71; actual 68-71.
- PASS: Formal Total200 Main KB plateau — expected 68-71; actual 68-71.
- PASS: Old post-hoc OFAT folder removed from Original50 — expected Absent; actual False.
- PASS: Old post-hoc OFAT folder removed from Added150/Total200 — expected Absent; actual False.
- PASS: Original50 Word-ready DOCX — expected Present; actual True.
- PASS: Added150/Total200 Word-ready DOCX — expected Present; actual True.