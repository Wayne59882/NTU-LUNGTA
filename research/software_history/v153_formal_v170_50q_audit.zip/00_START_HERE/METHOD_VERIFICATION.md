# Formal v153 validation method (v168)

1. Load 11,000 base KB records.
2. Insert 13 non-duplicate runtime supplemental records: 11,013 runtime records total.
3. Map the UI default context `core` to Main KB course `basic`.
4. Apply the v153 intent detector and course detector.
5. Score and re-rank all 11,013 candidate records with the v153 Active-7 weights.
6. Select Top-1 and sweep the final Top-1 score threshold.
7. Evaluate Domain and Main KB independently.

This produces the formal plateaus 68-93 (Original50) and 68-71 (Added150/Total200).
