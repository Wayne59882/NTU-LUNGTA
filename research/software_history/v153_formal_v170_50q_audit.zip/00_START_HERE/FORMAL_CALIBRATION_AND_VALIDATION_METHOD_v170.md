# Formal calibration and validation method — v170

## 1. Domain gate

The formal Domain gate is binary any-hit:

- 0 valid Domain item hits: Fail
- at least 1 valid Domain item hit: Pass

Domain item-count and evidence-group-count curves are sensitivity checks.
The selected Domain threshold remains 1.

## 2. Main KB factor-weight calibration

The ten candidate Main KB scoring factors were calibrated once using the
original 50-question set.

Protocol:

- historical fixed-Top-1 OFAT;
- calibration Gate 97;
- vary one factor weight from 0 to 100;
- keep all other factors fixed;
- select the left edge of the highest-F1 plateau.

Formal weights:

- Course base: 45
- Intent match: 8
- Comparison text match: 0
- Alias hit: 7
- Question-pattern hit: 0
- Concept exact match: 18
- Domain-term overlap: 2
- Generic course intent: 0
- Response variant: 2
- Detected-course bonus: 12

This produces the Active-7 model:

45, 8, 7, 18, 2, 2, 12.

## 3. Whole-model Main KB Gate selection

After fixing the scoring weights, the complete Main KB model is rerun and
the final Top-1 score threshold is swept separately.

- Original 50Q highest-F1 plateau: 68–93
- Added 150Q highest-F1 plateau: 68–71
- Total 200Q highest-F1 plateau: 68–71
- Formal Main KB Gate retained: 68

## 4. External validation rule

The Added150 and Total200 sets validate the locked model. They do not
reselect the individual scoring-factor weights.

Therefore:

- detailed factor weights do not change when the sample size increases;
- Gate 68 does not change;
- the observed highest-F1 plateau may become narrower;
- post-hoc robustness ranges are not formal replacement weights.
