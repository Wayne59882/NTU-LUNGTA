# Original 50Q formal v153 audit v170

## Fixed model configuration

- Domain scoring entries: 151
- Runtime Main KB records: 11,013
- Formal Domain threshold: 1 valid item hit
- Formal Main KB factor weights:
  **45, 8, 0, 7, 0, 18, 2, 0, 2, 12**
- Final Active-7 weights:
  **45, 8, 7, 18, 2, 2, 12**
- Formal Main KB Gate: **68**

## Original50 results

- Domain: TP 25, FP 1, TN 24, FN 0, F1 98.04%
- Main KB at Gate 68: TP 25, FP 1, TN 24, FN 0, F1 98.04%
- Highest-F1 Main KB plateau: **68–93**

## Correct method

The individual Main KB factor weights were selected once from the Original50
formal OFAT highest-F1 plateau left edges. Added validation questions do not
reselect those weights.

After fixing the weights, the complete model was rerun and the Final Top-1
score threshold was swept separately to select Gate 68.

The previous post-hoc robustness OFAT has been removed from the formal report.

## Figure standard

- Metric Y-axis: **Score percentage (%)**
- Confusion matrices: blue monochrome with direct TN/FP/FN/TP labels
- Count and raw-score charts retain their actual units
- Word-ready editable tables and PNG/SVG figures are in `08_WORD_READY`
