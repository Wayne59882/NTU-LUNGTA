# Word-ready v170

The DOCX contains editable Word tables and embedded 300-dpi figures.
PNG and SVG copies are provided separately.

Formal factor weights are fixed at:
45, 8, 0, 7, 0, 18, 2, 0, 2, 12.

Metric Y-axis: Score percentage (%).
Confusion matrices use a readable blue monochrome scale.
