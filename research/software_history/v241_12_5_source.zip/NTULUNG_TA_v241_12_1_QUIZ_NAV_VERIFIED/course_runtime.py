#!/usr/bin/env python3
from __future__ import print_function
import hashlib, json, math, os, random, re, shutil, sqlite3, struct, threading, time, unicodedata, urllib.error, urllib.request, uuid
from array import array
from collections import Counter
from contextlib import closing
from pathlib import Path
from exam_questions import build as build_exam_questions

try:
    import fitz
    # PyMuPDF API compatibility: the production server currently uses Python 3.6,
    # whose available binary wheel is PyMuPDF 1.16.x (legacy camelCase API).
    # Normalize the few APIs used by v241 so the same code also works with newer
    # PyMuPDF releases.
    if hasattr(fitz, 'Document'):
        if not hasattr(fitz.Document, 'get_toc') and hasattr(fitz.Document, 'getToC'):
            fitz.Document.get_toc = fitz.Document.getToC
        if not hasattr(fitz.Document, 'page_count') and hasattr(fitz.Document, 'pageCount'):
            fitz.Document.page_count = property(lambda self: self.pageCount)
    if hasattr(fitz, 'Page'):
        if not hasattr(fitz.Page, 'get_text') and hasattr(fitz.Page, 'getText'):
            fitz.Page.get_text = fitz.Page.getText
except Exception as e:
    fitz=None
    PDF_IMPORT_ERROR=str(e)
try:
    import numpy as np
except Exception:
    np=None

ROOT=Path(__file__).resolve().parent
COURSE_ROOT=ROOT/'course_workspaces'
STAGING_ROOT=COURSE_ROOT/'_staging'
COURSE_ROOT.mkdir(exist_ok=True)
STAGING_ROOT.mkdir(exist_ok=True)

EMBED_HOST=os.environ.get('VQ_REFERENCE_EMBED_HOST','127.0.0.1:11438').strip()
EMBED_BASE=EMBED_HOST.rstrip('/') if EMBED_HOST.startswith(('http://','https://')) else ('http://'+EMBED_HOST).rstrip('/')
EMBED_MODEL=os.environ.get('VQ_REFERENCE_EMBED_MODEL','bge-m3:latest').strip()
TOP_CANDIDATES=max(8,int(os.environ.get('VQ_COURSE_TOP_CANDIDATES','16')))
FINAL_TOP_K=max(4,int(os.environ.get('VQ_COURSE_FINAL_TOP_K','6')))
SOURCE_CANDIDATES=max(2,min(8,int(os.environ.get('VQ_COURSE_SOURCE_CANDIDATES','5'))))
SOURCE_MAX_FINAL=max(2,min(5,int(os.environ.get('VQ_COURSE_SOURCE_MAX_FINAL','3'))))
CONTEXT_BUDGET=max(4500,int(os.environ.get('VQ_COURSE_CONTEXT_CHARS','8500')))
QUESTION_TARGET=100
QUESTION_GENERATION='exam-mcq-v5'
RERANK_BLEND=float(os.environ.get('VQ_COURSE_RERANK_BLEND','0.92'))
MIN_SCOPE_SCORE=float(os.environ.get('VQ_COURSE_MIN_SCOPE_SCORE','0.26'))
MAX_EMBED_CHARS=2400

# A visual lung simulator is appropriate only when the uploaded material
# actually teaches respiratory mechanics, gas exchange or V/Q physiology.
RESPIRATORY_TOPICS=(
    r'\bv\s*[/\\]\s*q\b', r'ventilation.perfusion', r'pulmonary physiology',
    r'respiratory physiology', r'respiratory mechanics', r'pulmonary ventilation',
    r'alveolar ventilation', r'alveolar gas',
    r'gas exchange', r'dead space', r'lung compliance', r'pulmonary shunt',
    r'pulmonary perfusion', r'pulmonary gas', r'肺泡通氣', r'通氣.灌流',
    r'呼吸生理', r'呼吸力學', r'肺通氣', r'氣體交換', r'肺順應性', r'肺泡氣體', r'肺血流', r'死腔', r'肺內分流'
)
RESPIRATORY_CONTEXT=(r'\balveol',r'\bpaco2\b',r'\bpao2\b',r'\bfio2\b',
                     r'\btidal volume\b',r'\brespiratory rate\b',r'肺泡',r'通氣量',r'氧分壓')

def _is_respiratory_physiology(text):
    sample=str(text or '').lower()
    hits=sum(bool(re.search(pattern,sample,re.I)) for pattern in RESPIRATORY_TOPICS)
    return hits>=2 or (hits>=1 and sum(bool(re.search(p,sample,re.I)) for p in RESPIRATORY_CONTEXT)>=2)


def _json_dump(path,obj):
    path=Path(path); path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix(path.suffix+'.tmp')
    tmp.write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')
    os.replace(str(tmp),str(path))

def _safe_id(s):
    s=re.sub(r'[^A-Za-z0-9._-]+','-',str(s or '').strip()).strip('-_.').lower()
    return s[:72] or 'course'

_PDF_GLYPHS={
    '\ue00b':'fl','\ue00c':'ff','\ue00d':'fi','\ue00e':'Th',
    '\ue010':'a','\ue011':'b','\ue012':'c','\ue013':'d','\ue014':'l',
    '\ue015':'m','\ue016':'o','\ue017':'p','\ue018':'t',
    '\ue01d':'fl','\ue01e':'fi'
}
_PDF_PRIVATE=re.compile(r'[\ue000-\uf8ff\ufffd]')

def _clean_text(t):
    t=str(t or '').replace('\u200b','').replace('\xad','').replace('\x08','').replace('\ufeff','')
    if _PDF_PRIVATE.search(t):
        # Verified against the subset font used in Respiratory Care Pharmacology.
        # Other unknown glyphs stay visible to the quality gate and cannot enter
        # a student answer, lecture or generated question unnoticed.
        t=re.sub(r'(?<=\d)\ue018(?=(?:mg|mcg|g|mL|ml|L)\b)',' ',t)
        for glyph,value in _PDF_GLYPHS.items():t=t.replace(glyph,value)
    t=re.sub(r'-\n(?=[a-z])','',t)
    t=re.sub(r'[ \t]+',' ',t)
    t=re.sub(r'\n{3,}','\n\n',t)
    return t.strip()

def _safe_source_text(t):
    """Omit sentences with font glyphs whose meaning we cannot verify."""
    clean=_clean_text(t)
    if not _PDF_PRIVATE.search(clean):return clean
    parts=re.split(r'(?<=[.!?。！？])\s+',clean.replace('\n',' '))
    return '\n'.join(part.strip() for part in parts if part.strip() and not _PDF_PRIVATE.search(part))

def _readable_source(text):
    text=str(text or '')
    glyphs=len(_PDF_PRIVATE.findall(text))
    letters=len(re.findall(r'[A-Za-z\u3400-\u9fff]',text))
    return letters>=90 and glyphs<=max(2,int(letters*.005))

# A PDF outline is a navigation aid, not a course syllabus. Publishers often
# put Cover, IFC and legal pages at the same outline level as real chapters.
FRONT_MATTER=re.compile(r'^(?:cover|ifc|inside\s+(?:front|back)\s+cover|title(?:\s+page)?|half\s+title|copyright|dedication|contributors?|preface|foreword|acknowledg(?:e)?ments?|contents|table\s+of\s+contents|toc|about\s+(?:the\s+)?authors?|index|glossary|bibliography|references|abbreviations|list\s+of\s+(?:figures|tables)|封面|書名頁|版權頁|目錄|前言|序言|致謝|索引|參考文獻)(?:\s*[:.\-–].*)?$',re.I)
CHAPTER_HEADING=re.compile(r'^(?:chapter|chap\.?|ch\.?|unit|module)\s*\d+[a-z]?\b|^第\s*[一二三四五六七八九十百0-9]+\s*(?:章|單元)|^\d{1,3}\s*[.、:：\-]\s*\S',re.I)
PART_HEADING=re.compile(r'^(?:(?:part|section|volume)\s+(?:[ivxlcdm]+|\d+)|(?:第\s*[一二三四五六七八九十百0-9]+\s*篇))(?:\s*[:.\-–].*)?$',re.I)

def _course_title(metadata_title,filename):
    title=_clean_text(metadata_title or '')
    if not title or len(title)>110 or re.search(r'[{}]|libgen|doi:|https?://|[/\\]',title,re.I):
        title=Path(filename).stem.split('{',1)[0].replace('_',' ')
        title=re.sub(r'\s*(?:libgen(?:\.li)?|\([^)]*\d{4}[^)]*\))\s*$','',title,flags=re.I)
    return title[:110].strip() or 'Uploaded Course'

def _course_chapters(doc):
    rows=[]
    for row in doc.get_toc(simple=True) or []:
        try:level,title,page=int(row[0]),_clean_text(row[1]),int(row[2])
        except (TypeError,ValueError,IndexError):continue
        if title and 1<=page<=doc.page_count and not FRONT_MATTER.match(title) and not PART_HEADING.match(title):
            rows.append((level,title,page))
    explicit=[r for r in rows if CHAPTER_HEADING.match(r[1])]
    if explicit:
        level=min(r[0] for r in explicit)
        chosen=[r for r in explicit if r[0]==level]
    else:
        # Keep the broadest usable outline level; a lone book-level bookmark
        # above several real sections should not swallow the entire textbook.
        levels=sorted(set(r[0] for r in rows))
        level=next((l for l in levels if len([r for r in rows if r[0]==l])>=2),levels[0] if levels else None)
        chosen=[r for r in rows if r[0]==level]
    unique=[];seen=set()
    for _,title,page in chosen:
        if page in seen:continue
        seen.add(page);unique.append((title,page))
    return unique or [('Entire PDF — review or upload separate chapter PDFs',1)]

def _word_chunks(text,max_words=420,overlap=70):
    words=_clean_text(text).split()
    if not words:return []
    out=[];step=max(1,max_words-overlap)
    for i in range(0,len(words),step):
        part=words[i:i+max_words]
        if len(part)>=45:out.append(' '.join(part))
        elif not out and part:out.append(' '.join(part))
        if i+max_words>=len(words):break
    return out

def _sentence_windows(text,target_chars=900,max_chars=1350):
    raw=' '.join(str(text or '').split())
    if not raw:return []
    parts=[x.strip() for x in re.split(r'(?<=[.!?。！？])\s+(?=[A-Z0-9\u3400-\u9fff(])',raw) if x.strip()]
    if len(parts)<=2:return [raw[:max_chars]]
    windows=[];cur=[];n=0
    for sent in parts:
        if cur and n+len(sent)+1>target_chars:
            w=' '.join(cur).strip()
            if w:windows.append(w[:max_chars])
            cur=cur[-1:];n=sum(len(x)+1 for x in cur)
        cur.append(sent);n+=len(sent)+1
    if cur:
        w=' '.join(cur).strip()
        if w:windows.append(w[:max_chars])
    seen=set();out=[]
    for w in windows:
        k=' '.join(w.lower().split())
        if k not in seen:seen.add(k);out.append(w)
    return out

class EmbeddingHTTPError(RuntimeError):
    def __init__(self,status,detail):
        self.status=status
        self.detail=detail
        super(EmbeddingHTTPError,self).__init__('BGE-M3 embedding HTTP %s: %s'%(status,detail))


def _url_json(url,payload=None,timeout=240):
    data=None;headers={}
    if payload is not None:
        data=json.dumps(payload,ensure_ascii=False).encode('utf-8');headers['Content-Type']='application/json'
    req=urllib.request.Request(url,data=data,headers=headers,method='POST' if data is not None else 'GET')
    try:
        with urllib.request.urlopen(req,timeout=float(timeout)) as r:
            return json.loads(r.read().decode('utf-8'))
    except urllib.error.HTTPError as e:
        raw=e.read(2048).decode('utf-8',errors='replace')
        try:detail=str(json.loads(raw).get('error') or raw)
        except (ValueError,AttributeError):detail=raw
        raise EmbeddingHTTPError(e.code,detail[:350] or 'No error detail returned by Ollama')

def _normalize(v):
    vals=[float(x) for x in v]
    n=math.sqrt(sum(x*x for x in vals)) or 1.0
    return [x/n for x in vals]

def _embed_input(value,max_chars=MAX_EMBED_CHARS):
    s=unicodedata.normalize('NFKC',str(value or ''))
    s=re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f\ud800-\udfff\ufffd]',' ',s)
    return ' '.join(s.split())[:max_chars].strip()


def _embed(texts,timeout=240,minimal=False):
    single=isinstance(texts,str);items=[texts] if single else list(texts)
    if not items:return []
    items=[_embed_input(x) for x in items]
    if any(not x for x in items):raise ValueError('A selected chapter contains no embeddable text.')
    payload={'model':EMBED_MODEL,'input':items[0] if single else items}
    if not minimal:payload.update({'truncate':True,'keep_alive':'12h'})
    d=_url_json(EMBED_BASE+'/api/embed',payload,timeout=timeout)
    emb=d.get('embeddings') or []
    if single and emb and isinstance(emb[0],(int,float)):emb=[emb]
    if len(emb)!=len(items):raise RuntimeError('Embedding backend returned %s vectors for %s inputs'%(len(emb),len(items)))
    return [_normalize(v) for v in emb]

def _embed_resilient(items,timeout=300):
    items=list(items)
    if not items:return []
    try:return _embed(items,timeout=timeout)
    except EmbeddingHTTPError as e:
        if e.status not in (400,413):raise
        if len(items)==1:
            last=e
            for limit in (1200,512,160):
                try:return _embed([_embed_input(items[0],limit)],timeout=timeout,minimal=True)
                except EmbeddingHTTPError as retry:
                    if retry.status not in (400,413):raise
                    last=retry
            raise RuntimeError('Embedding service rejected one cleaned PDF passage (model %s, host %s): %s'%(EMBED_MODEL,EMBED_BASE,last.detail))
        m=len(items)//2
        return _embed_resilient(items[:m],timeout)+_embed_resilient(items[m:],timeout)

def _pack(v):return struct.pack('<%df'%len(v),*v)
def _unpack(blob):
    a=array('f');a.frombytes(blob)
    if os.sys.byteorder!='little':a.byteswap()
    return a

def _dot(a,b):
    if np is not None:
        return float(np.dot(np.asarray(a,dtype=np.float32),np.asarray(b,dtype=np.float32)))
    return float(sum(x*y for x,y in zip(a,b)))

def _same_language_hint(text):
    s=str(text or '')
    zh=len(re.findall(r'[\u3400-\u9fff]',s)); en=len(re.findall(r'[A-Za-z]',s))
    return 'Traditional Chinese' if zh>max(50,en//3) else 'English'

# Source-backed choices are assembled from distinct statements in the selected unit.
# The bank is complete before a quiz starts, so no answer model can stall a draw.
_QUESTION_STOP=set(('a an and are as at be been being because but by can could did do does doing done for from had has have having he her hers him his how i if in into is it its may might more most must no nor not of on one or our ours she should so than that the their theirs them then there these they this those through to too under up very was we were what when where which while who why will with would you your yours according also between both during each either every first following further however including itself many other same several some such these those using use used'.split()))
_QUESTION_STOP.update(('chapter figure table copyright edition elsevier respiratory course material unit principles introduction summary review learning objectives key points conversely therefore moreover nevertheless otherwise traditionally generally usually commonly respectively approximately'.split()))
_QUESTION_BAD_END=set(('call calls called calling mean means meant meaning change changes changed changing cause causes caused causing explain explains explained explaining preserve preserves preserved preserving regulate regulates regulated regulating increase increases increased increasing decrease decreases decreased decreasing reduce reduces reduced reducing move moves moved moving make makes made making perform performs performed performing result results resulted resulting lead leads led leading use uses used using include includes included including provide provides provided providing require requires required requiring become becomes became becoming remain remains remained remaining'.split()))

def _stable_number(value):
    return int(hashlib.sha1(str(value).encode('utf-8')).hexdigest()[:12],16)

def _question_sentences(chunks):
    rows=[];seen=set()
    for chunk in chunks:
        raw=_clean_text(chunk.get('text') or '').replace('\r','\n')
        parts=re.split(r'(?<=[.!?。！？])\s+|\n+',raw)
        for part in parts:
            sent=' '.join(_clean_text(part).split()).strip(' \t-–—•')
            latin=len(re.findall(r'[A-Za-z]',sent));han=len(re.findall(r'[\u3400-\u9fff]',sent))
            if len(sent)<32 or len(sent)>360 or latin+han<22:continue
            if _PDF_PRIVATE.search(sent):continue
            # The PDF text layer can glue review keys, printer marks and page
            # furniture to a valid sentence. None belongs in a student quiz.
            if re.search(r'appendix\s+[a-z]|study\s+and\s+review|\.indd\b|\b(?:isbn|copyright|all rights reserved|answer found in)\b|\b\w{3,}\d{3,}_ch\d+|\bchapter\s+\d+\b',sent,re.I):continue
            if re.match(r'^\s*(?:\([a-d]\)|[a-d][.)]|\d{1,3}[.)])\s',sent,re.I):continue
            if latin>20 and len(re.findall(r'[A-Z]',sent))/float(latin)>.65:continue
            if not re.search(r'[.!?。！？][\]”"\']?$',sent):continue
            if re.search(r'\b(?:figure|fig\.?|table|illustration|key\s*point|references)\s*\d',sent,re.I):continue
            if re.match(r'^\d{1,3}\.\d{1,3}\s',sent):continue
            if re.search(r'\b(?:KEY\s*POINT|DOUGLAS\s+S\.|ISBN|Copyright)\b',sent,re.I):continue
            if latin and len(re.findall(r"[A-Za-z][A-Za-z0-9'’/-]*",sent))<6:continue
            key=re.sub(r'\W+','',sent.lower())[:260]
            if not key or key in seen:continue
            seen.add(key);rows.append({'text':sent,'evidence_chunk_id':chunk['id']})
    return rows

def _candidate_terms(sentence,frequencies,max_terms=5,prefer_phrases=False):
    found=[];occupied=set()
    def add(start,end,text,kind,bonus=0):
        value=' '.join(str(text).split()).strip(' ,.;:()[]{}')
        low=value.lower()
        if len(value)<2 or len(value)>64 or low in _QUESTION_STOP:return
        marker=(start,end,low)
        if marker in occupied:return
        occupied.add(marker)
        rarity=10.0/max(1,frequencies.get(low,1))
        found.append({'start':start,'end':end,'value':value,'kind':kind,'score':bonus+min(18,len(value))+rarity})
    for m in re.finditer(r'(?<![A-Za-z0-9])\d+(?:\.\d+)?\s*(?:%|mg|mcg|µg|g|kg|mL|ml|L|mmHg|cmH2O|s|sec(?:onds?)?|min(?:utes?)?|hours?)?',sentence,re.I):
        add(m.start(),m.end(),m.group(0),'number',18)
    words=list(re.finditer(r"\b[A-Za-z][A-Za-z0-9α-ωΑ-Ω'’/-]{1,}\b",sentence))
    content=[]
    for m in words:
        value=m.group(0);low=value.lower()
        if low in _QUESTION_STOP or (len(value)<4 and not value.isupper()):continue
        if low in _QUESTION_BAD_END or low.endswith('ly'):continue
        if value.isupper() and 2<=len(value)<=10:kind='acronym'
        elif low.endswith(('ing','ed')):kind='verb'
        elif low.endswith(('tion','sion','ment','ness','ity','ance','ence','ism','osis','emia','ase','ide','ium','ology','ship','age','ure')):kind='noun'
        elif low.endswith(('al','ic','ive','ous','able','ible','ary','ory','ant','ent','less','ful')):kind='adjective'
        else:kind='term'
        add(m.start(),m.end(),value,kind,10 if kind=='acronym' else 0);content.append(m)
    # Keep at most one conservative multiword expression per sentence.  The
    # source span must be plain adjacent words (no skipped punctuation), and a
    # verb-like ending is rejected.  This avoids awkward blanks such as
    # "vessels and reduced" while retaining terms such as "alveolar pressure".
    for size in (3,2):
        for i in range(0,max(0,len(words)-size+1)):
            group=words[i:i+size];tokens=[x.group(0).lower() for x in group]
            if tokens[0] in _QUESTION_STOP or tokens[-1] in _QUESTION_STOP or any(x in _QUESTION_BAD_END for x in tokens):continue
            if any(x in _QUESTION_STOP and x not in ('of','and','to') for x in tokens[1:-1]):continue
            if tokens[-1] in _QUESTION_BAD_END or tokens[-1].endswith(('ing','ed','ly')):continue
            if group[-1].end()-group[0].start()>58:continue
            phrase=sentence[group[0].start():group[-1].end()]
            if not re.fullmatch(r"[A-Za-z0-9α-ωΑ-Ω'’/-]+(?:\s+[A-Za-z0-9α-ωΑ-Ω'’/-]+){%d}"%(size-1),phrase):continue
            add(group[0].start(),group[-1].end(),phrase,'phrase',13+size)
    # Chinese PDFs do not expose word boundaries. Short source substrings still
    # make exact, auditable cloze answers.
    for run in re.finditer(r'[\u3400-\u9fff]{4,}',sentence):
        text=run.group(0)
        for size in (4,3,2):
            for pos in range(0,max(0,len(text)-size+1),size):
                add(run.start()+pos,run.start()+pos+size,text[pos:pos+size],'han',8+size)
    found.sort(key=lambda x:(-x['score'],x['start'],x['value'].lower()))
    selected=[]
    # Single terms and measurements make the most readable deterministic
    # cloze items.  Reserve one slot for a carefully filtered compound term.
    ordered=([x for x in found if x['kind']=='phrase']+[x for x in found if x['kind']!='phrase']) if prefer_phrases else [x for x in found if x['kind']!='phrase']+[x for x in found if x['kind']=='phrase']
    phrase_count=0
    for item in ordered:
        if item['kind']=='phrase' and phrase_count>=(2 if prefer_phrases else 1):continue
        if any(not (item['end']<=x['start'] or item['start']>=x['end']) for x in selected):continue
        selected.append(item)
        if item['kind']=='phrase':phrase_count+=1
        if len(selected)>=max_terms:break
    return selected

def _fast_question_bank(unit,chunks,target=QUESTION_TARGET,max_terms=5):
    sentences=_question_sentences(chunks)
    if not sentences:return []
    tokens=[]
    for row in sentences:
        tokens.extend(x.lower() for x in re.findall(r"\b[A-Za-z][A-Za-z0-9α-ωΑ-Ω'’/-]{2,}\b",row['text']))
    frequencies=Counter(tokens)
    rounds={}
    for si,row in enumerate(sentences):
        terms=_candidate_terms(row['text'],frequencies,max_terms=max_terms)
        for rank,term in enumerate(terms):
            rounds.setdefault(rank,[]).append({'source_concept':term['value'],'source_statement':row['text'],'evidence_chunk_id':row['evidence_chunk_id']})
    # One concept from each source sentence before returning to the same
    # sentence. This is linear in the extracted text and never duplicates a
    # fact merely to inflate the advertised count.
    generated=[];seen=set()
    for rank in sorted(rounds):
        pool=rounds[rank]
        pool.sort(key=lambda x:_stable_number(unit['id']+'|'+x['source_statement']+'|'+x['source_concept']))
        for item in pool:
            key=(item['source_statement'].casefold(),item['source_concept'].casefold())
            if key in seen:continue
            seen.add(key);item['id']='%s_q%03d'%(unit['id'],len(generated)+1)
            item['generation_method']='scenario-seed-v1'
            generated.append(item)
            if len(generated)>=target:return generated
    return generated

def _ready_question_bank(unit,chunks,target=QUESTION_TARGET):
    """Use an intact textbook sentence, never a guessed subject/object relation.

    Choices are exact, bounded terms from the same unit and grammatical class.
    The task asks for the source wording: another term may be true elsewhere,
    but only one completes this specific, quoted sentence.
    """
    rows=[];frequencies=Counter()
    for row in _question_sentences(chunks):
        fact=row['text']
        # An isolated clause after a page break or a context-only transition
        # cannot be made into a stand-alone question by adding a generic stem.
        if re.match(r'^(?:there\b|as a result\b|however\b|therefore\b|which\b|this\b|these\b|those\b)',fact,re.I):continue
        if len(re.findall(r'[A-Za-z]',fact))<35 or re.search(r'[\u3400-\u9fff]',fact):continue
        if not re.match(r'^[A-Za-z]',fact):continue
        rows.append(row)
        frequencies.update(x.lower() for x in re.findall(r"\b[A-Za-z][A-Za-z0-9α-ωΑ-Ω'’/-]{2,}\b",fact))
    candidates=[];pool={}
    for row in rows:
        fact=row['text']
        for term in _candidate_terms(fact,frequencies,max_terms=12,prefer_phrases=True):
            kind=term['kind'];answer=term['value']
            if kind in ('verb','adjective','han') or re.search(r'[\u3400-\u9fff]',answer):continue
            if kind=='number' and len(re.findall(r'\d+(?:\.\d+)?',fact))>1:continue
            if answer.casefold() in ('the','there','which','that','this','little','information','evidence','because'):continue
            if re.search(r'\b(?:and|or|the|a|an|of|to|for)\b',answer,re.I) and kind!='phrase':continue
            before=fact[:term['start']];after=fact[term['end']:]
            if len(after.strip())<8:continue
            if (before and not before[-1].isspace()) or (after[0] not in ' .,;:!?)]' and not after[0].isspace()):continue
            if len(answer)>48 or not re.search(r'[A-Za-z]',answer):continue
            stem='Complete this statement from the course material:\n'+before+'____'+after
            # The source wording must contain exactly one target span.
            if fact.casefold().count(answer.casefold())!=1:continue
            candidate={'kind':kind,'answer':answer,'stem':stem,'fact':fact,'chunk':row['evidence_chunk_id']}
            candidates.append(candidate);pool.setdefault(kind,set()).add(answer)
    result=[];seen=set()
    candidates.sort(key=lambda c:(_stable_number(unit['id']+'|'+c['fact']),_stable_number(c['answer'])))
    for card in candidates:
        fact=card['fact'];answer=card['answer'];kind=card['kind']
        key=(fact.casefold(),answer.casefold())
        if key in seen:continue
        seen.add(key)
        options=[s for s in pool[kind] if s.casefold()!=answer.casefold() and s.casefold() not in fact.casefold() and answer.casefold() not in s.casefold() and s.casefold() not in answer.casefold()]
        options.sort(key=lambda s:(abs(len(s)-len(answer)),_stable_number(card['stem']+'|'+s)))
        if len(options)<3:continue
        slot=_stable_number('answer|'+card['stem'])%4
        choices=options[:3];choices.insert(slot,answer)
        if len(set(s.casefold() for s in choices))!=4:continue
        qid='%s_cloze%03d'%(unit['id'],len(result)+1);seed_id=qid+'_seed'
        explanation='The course material states: '+fact
        question={'id':qid,'source_seed_id':seed_id,'stem':card['stem'],'choices':choices,'answer':slot,'explanation':explanation,'evidence_statement':fact,'evidence_chunk_id':card['chunk'],'generation_method':QUESTION_GENERATION}
        if _PDF_PRIVATE.search(' '.join([question['stem'],explanation]+choices)):continue
        result.append({'id':seed_id,'source_concept':answer,'source_statement':fact,'evidence_chunk_id':card['chunk'],'generation_method':QUESTION_GENERATION,'question':question})
        if len(result)>=target:break
    if len(result)<target:
        raise RuntimeError('Unit "%s" has only %s/%s complete English source questions. Upload a longer OCR-readable English chapter; incomplete sentences and unrelated choice fragments are excluded.'%(unit['title'],len(result),target))
    return result

_RELATION=re.compile(r'^(?P<subject>[A-Za-z\u3400-\u9fff][^.!?。！？]{3,100}?)\s+(?:(?:can|may|will)\s+)?(?P<verb>is\s+(?:partially\s+)?determined\s+by|are\s+(?:partially\s+)?determined\s+by|consists\s+of|results\s+in|leads\s+to|depends\s+on|is\s+associated\s+with|contains?|includes?|has|have|increases?|decreases?|reduces?|inhibits?|stimulates?|regulates?|changes?|causes?|affects?|produces?|describes?|determines?|allows?|involves?|requires?|contributes?|delivers?|binds?|blocks?|prevents?|maintains?|is|are)\s+(?P<object>[^.!?。！？]{4,230})[.!?。！？]$',re.I)
_RELATION_ZH=re.compile(r'^(?P<subject>[\u3400-\u9fff]{2,35}?)(?P<verb>包含|含有|增加|降低|減少|抑制|促進|調節|影響|導致|需要|位於|是)(?P<object>[^。！？]{4,85})[。！？]$')
_QUESTION_FURNITURE=re.compile(r'\b(?:appendix|figure|table|chapter|study and review|answer found in|copyright|isbn)\b|\.indd\b|\b\w{3,}\d{3,}_ch\d+',re.I)

def _case_phrase(value):
    value=' '.join(_clean_text(value).split()).strip(' ,.;:()[]{}-–—')
    value=re.sub(r'^(?:for example|for instance|in contrast|however|therefore|the|a|an|many different|various)\s+','',value,flags=re.I)
    return value.strip(' ,.;:()[]{}-–—')

def _case_part(value,limit=95):
    value=_case_phrase(value)
    if not value or len(value)>limit or _QUESTION_FURNITURE.search(value) or _PDF_PRIVATE.search(value):return ''
    if re.search(r'\b(?:and|or|of|to|by|the|a|an|which|that|because)\s*$',value,re.I):return ''
    return value

def _relationship_cards(statement,unit_title):
    """Turn an explicit textbook relation into a short case and short answers."""
    if _QUESTION_FURNITURE.search(statement):return []
    clean=re.sub(r'^(?:for example|for instance|in contrast|however|therefore),?\s+','',statement.strip(),flags=re.I)
    m=_RELATION.match(clean) or _RELATION_ZH.match(clean)
    if not m:return []
    subject=_case_part(m.group('subject'),70)
    obj=m.group('object');cause=''
    if re.search(r'\b(?:does not|do not|cannot|is not|are not)\s*$',subject,re.I) or subject.endswith(('不','未')):return []
    for link in (' because ',' by ',' that ',' which ','因為','透過','藉由'):
        pos=obj.lower().find(link)
        if pos>=0:
            cause=_case_part(obj[pos+len(link):],90);obj=obj[:pos]
            break
    outcome=_case_part(obj,85)
    if not subject or not outcome or subject.casefold()==outcome.casefold():return []
    if len(subject.split())>12 or len(outcome.split())>14:return []
    verb=m.group('verb').lower()
    clinical=bool(re.search(r'patient|drug|lung|pulmonary|respirat|blood|disease|pharmac|medic|alveol|病人|藥物|肺|血液',statement+' '+unit_title,re.I))
    setting='臨床實習生在照護討論中' if clinical else '學生在實驗與實務案例討論中'
    cards=[]
    if verb in ('is','are','是','describes','describe'):
        cards.append(('outcome','%s需要向同學解釋 %s。依本單元教材，哪一項描述最恰當？'%(setting,subject),outcome))
        cards.append(('subject','%s讀到 %s 的描述。這個描述對應教材中的哪一項？'%(setting,outcome),subject))
    elif verb.startswith(('contain','include')) or verb in ('has','have','consists of','包含','含有'):
        cards.append(('outcome','%s分析 %s 的組成，準備解釋觀察結果。依教材，應找到哪一項成分？'%(setting,subject),outcome))
        if cause:
            focus=_case_part(cause.rsplit('such as',1)[-1],50) if 'such as' in cause.lower() else ''
            if focus:
                cards.append(('outcome','%s觀察 %s 的變化，想找出 %s 中參與調控的成分。根據教材，應選哪一項？'%(setting,focus,subject),outcome))
    else:
        direction='受抑制' if verb.startswith(('inhib','block','prevent')) or verb in ('抑制',) else '降低' if verb.startswith(('decrease','reduc')) or verb in ('降低','減少') else '增加' if verb.startswith(('increase','stimulat')) or verb in ('增加','促進') else '受到影響'
        cards.append(('outcome','%s評估 %s 的作用。依教材，哪一項會%s？'%(setting,subject,direction),outcome))
        cards.append(('subject','%s發現 %s %s。教材提到哪個因素可能直接造成這個變化？'%(setting,outcome,direction),subject))
        if cause:
            cards.append(('mechanism','%s要解釋 %s 對 %s 的作用。教材指出的機轉是哪一項？'%(setting,subject,outcome),cause))
            cards.append(('outcome','%s研究 %s 透過 %s 發揮作用。預期哪一項會%s？'%(setting,subject,cause,direction),outcome))
    return [(kind,stem,answer) for kind,stem,answer in cards if len(stem)<=210 and answer.casefold() not in stem.casefold() and not _PDF_PRIVATE.search(stem)]

def _lecture_evidence(unit,chunks,max_chars=6200):
    rows=_question_sentences(chunks)
    if not rows:return ''
    limit=min(18,len(rows));indexes=[]
    if limit==1:indexes=[0]
    else:
        indexes=[int(round(i*(len(rows)-1)/float(limit-1))) for i in range(limit)]
    body=[];used=0
    for i in indexes:
        sent=rows[i]['text']
        if used+len(sent)+2>max_chars:break
        body.append(sent);used+=len(sent)+2
    return '\n'.join(body).strip()

def _chinese_lecture(unit,chunks,model_key,model_call):
    evidence=_lecture_evidence(unit,chunks)
    if len(evidence)<180:raise RuntimeError('This chapter has too little readable text to make a Chinese lecture. Run OCR or choose a complete chapter.')
    system=('你是生理學與藥理學課程的教學助理。以繁體中文撰寫可直接朗讀的課堂講稿。'
            '所有事實只能來自提供的教材，保留藥名、數值、公式與重要英文專有名詞。'
            '不要引用圖號、頁碼、書名、章節號或作者；不要寫題目；不要輸出英文段落或來源標記。'
            '若教材沒有支持某一因果關係，就不要自行補充。')
    user=('單元：'+str(unit['title'])+'\n請寫 5 至 7 段繁體中文講稿，先定義核心概念，再用教材中的例子解釋機轉，最後歸納。'
          '僅使用下面的乾淨教材摘錄；其餘頁面仍由學生問答檢索。\n\n'+evidence)
    script=_clean_text(model_call(model_key,system,user,1250))
    han=len(re.findall(r'[\u3400-\u9fff]',script));latin=len(re.findall(r'[A-Za-z]',script))
    if _PDF_PRIVATE.search(script) or han<150 or han<latin//2:
        raise RuntimeError('The local model did not produce a readable Traditional Chinese lecture. Retry with another available model.')
    return '單元：%s。\n\n%s'%(unit['title'],script)

_SEARCH_STOP={'the','and','what','how','does','is','are','of','in','to','for','a','an','on','with','why','can','from','this','that','about','which','when','where','explain','describe','影響','什麼','如何','請問','課程'}
def _search_terms(value):
    raw=unicodedata.normalize('NFKC',str(value or '')).lower().replace('v/q','vq')
    words=[x for x in re.findall(r'[a-z0-9]{2,}',raw) if x not in _SEARCH_STOP]
    han=re.findall(r'[\u3400-\u9fff]+',raw)
    return set(words+[s[i:i+2] for s in han for i in range(max(0,len(s)-1))])

def _lex_score(terms,value):
    if not terms:return 0.0
    found=terms & _search_terms(value)
    return float(len(found))/float(len(terms))

class CourseManager(object):
    def __init__(self):
        self.jobs={};self.jobs_lock=threading.RLock();self.cache={};self.cache_lock=threading.Lock()
        self.upload_lock=threading.RLock();self.manifest_lock=threading.RLock();self.scenario_lock=threading.RLock();self.quiz_result_lock=threading.RLock();self.running=set();self.deleted=set();self.running_lock=threading.Lock()

    def _stage_dir(self,stage_id):return STAGING_ROOT/_safe_id(stage_id)
    def _course_dir(self,course_id):return COURSE_ROOT/_safe_id(course_id)
    def _manifest_path(self,course_id):return self._course_dir(course_id)/'course_manifest.json'

    def upload_status(self,stage_id,upload_id):
        sd=self._stage_dir(stage_id);uid=_safe_id(upload_id)
        meta=sd/'_uploads'/(uid+'.json')
        if not meta.exists():return {'offset':0,'complete':False,'stage_id':_safe_id(stage_id)}
        with self.upload_lock:
            state=json.loads(meta.read_text(encoding='utf-8'))
            part=sd/'_uploads'/(uid+'.part')
            if not state.get('complete') and state['offset']==state['size'] and part.exists():
                stage_path=sd/'stage.json'
                count=len(json.loads(stage_path.read_text(encoding='utf-8')).get('sources',[])) if stage_path.exists() else 0
                if count<=state.get('source_count',0):
                    self.inspect([(state['name'],part.read_bytes())],course_name=state.get('course_name',''),stage_id=stage_id)
                state['complete']=True;_json_dump(meta,state);part.unlink()
        result={'offset':state['offset'],'complete':bool(state.get('complete')),'stage_id':_safe_id(stage_id)}
        if result['complete'] and (sd/'stage.json').exists():
            result['inspection']=json.loads((sd/'stage.json').read_text(encoding='utf-8'))
        return result

    def upload_chunk(self,stage_id,upload_id,name,total_size,offset,data,course_name=''):
        if not stage_id or not upload_id or not str(name).lower().endswith('.pdf'):
            raise ValueError('A valid stage, upload ID and PDF filename are required.')
        if len(data)<1 or len(data)>2*1024*1024:raise ValueError('Upload chunks must be 2 MB or smaller.')
        total_size=int(total_size);offset=int(offset)
        if total_size<=0 or total_size>320*1024*1024 or offset<0:raise ValueError('Invalid PDF size or upload offset.')
        sd=self._stage_dir(stage_id);ud=sd/'_uploads';ud.mkdir(parents=True,exist_ok=True)
        uid=_safe_id(upload_id);mp=ud/(uid+'.json');part=ud/(uid+'.part')
        with self.upload_lock:
            state=json.loads(mp.read_text(encoding='utf-8')) if mp.exists() else {'name':str(name),'size':total_size,'offset':0,'complete':False,'course_name':course_name}
            if state['name']!=name or state['size']!=total_size:raise ValueError('The resumed PDF does not match the original file.')
            if state.get('complete'):return self.upload_status(stage_id,upload_id)
            if offset!=state['offset']:
                raise ValueError('Upload offset mismatch; check upload status and resume at the server offset.')
            if offset+len(data)>total_size:raise ValueError('Chunk exceeds declared PDF size.')
            with part.open('r+b' if part.exists() else 'wb') as f:
                f.seek(offset);f.write(data);f.flush();os.fsync(f.fileno())
            state['offset']=offset+len(data)
            if state['offset']==total_size:
                stage_path=sd/'stage.json'
                state['source_count']=len(json.loads(stage_path.read_text(encoding='utf-8')).get('sources',[])) if stage_path.exists() else 0
            _json_dump(mp,state)
            if state['offset']==total_size:
                # The completed file is durably staged before inspection; a lost
                # response can be recovered through upload_status on refresh.
                inspection=self.inspect([(name,part.read_bytes())],course_name=course_name,stage_id=stage_id)
                state['complete']=True;_json_dump(mp,state);part.unlink()
                return {'offset':total_size,'complete':True,'stage_id':_safe_id(stage_id),'inspection':inspection}
            return {'offset':state['offset'],'complete':False,'stage_id':_safe_id(stage_id)}

    def inspect(self,files,course_name='',visual_model='none',stage_id=''):
        if fitz is None:raise RuntimeError('PDF parser unavailable in the serving Python. Re-run INSTALL_FINAL.sh; import error: '+PDF_IMPORT_ERROR)
        if not files:raise ValueError('At least one PDF is required.')
        stage_id=_safe_id(stage_id) if stage_id else ('stage-'+uuid.uuid4().hex[:12])
        sd=self._stage_dir(stage_id);(sd/'source').mkdir(parents=True,exist_ok=True)
        stage_path=sd/'stage.json'
        if stage_path.exists():
            try:meta=json.loads(stage_path.read_text(encoding='utf-8'))
            except Exception:raise ValueError('Upload staging data is invalid.')
            sources=list(meta.get('sources') or []);units=list(meta.get('units') or []);auto_name=_clean_text(meta.get('course_name') or '')
        else:
            sources=[];units=[];auto_name=''
        source_index=len(sources)
        for offset,(name,data) in enumerate(files,1):
            if not str(name).lower().endswith('.pdf'):continue
            fi=source_index+offset
            safe='%02d_%s'%(fi,re.sub(r'[^A-Za-z0-9._-]+','_',Path(name).name))
            p=sd/'source'/safe;p.write_bytes(data)
            try:
                with closing(fitz.open(str(p))) as doc:
                    if doc.page_count<1:raise ValueError('Not a readable PDF: '+str(name))
                    pdfmeta=doc.metadata or {}
                    title=_course_title(pdfmeta.get('title'),name)
                    chapter_rows=_course_chapters(doc)
                    samples=[]; readable=0
                    # Sample throughout the book; a cover alone cannot enable the simulator.
                    stride=max(1,doc.page_count//16)
                    for pi in range(0,doc.page_count,stride):
                        s=_clean_text(doc[pi].get_text('text') or '')
                        if s:readable+=len(s);samples.append(s[:3500])
                    if readable<40:raise ValueError('No searchable text found in '+str(name)+'. Run OCR on this scanned PDF, then upload it again.')
                    if not auto_name:auto_name=title
                    for ci,(ctitle,start) in enumerate(chapter_rows,1):
                        end=(chapter_rows[ci][1]-1) if ci<len(chapter_rows) else doc.page_count
                        if end<start:end=start
                        units.append({'id':'u%03d'%len(units),'title':title if ctitle.startswith('Entire PDF —') else ctitle,'source_file':safe,'source_title':title,'start_page':start,'end_page':end,'enabled':True,'needs_review':ctitle.startswith('Entire PDF —')})
                    respiratory=_is_respiratory_physiology(' '.join([x[0] for x in chapter_rows]+samples))
                    sources.append({'file_name':safe,'display_name':Path(name).name,'title':title,'pages':doc.page_count,'chapter_count':len(chapter_rows),'respiratory_physiology':respiratory})
            except Exception:
                if p.exists():p.unlink()
                raise
        if not sources:raise ValueError('No valid PDF was uploaded.')
        meta={'stage_id':stage_id,'course_name':_clean_text(course_name) or auto_name or 'Uploaded Course','visual_model':'vq' if any(s.get('respiratory_physiology') for s in sources) else 'none','sources':sources,'units':units,'created_at':meta.get('created_at',time.time()) if stage_path.exists() else time.time(),'updated_at':time.time()}
        _json_dump(sd/'stage.json',meta)
        return meta

    def start_build(self,stage_id,course_name,visual_model,units,model_key,model_call):
        sd=self._stage_dir(stage_id);stage_path=sd/'stage.json'
        if not stage_path.exists():raise ValueError('Upload staging data was not found.')
        stage=json.loads(stage_path.read_text(encoding='utf-8'))
        allowed={u['id']:u for u in stage.get('units',[])};selected=[]
        for x in units or []:
            uid=str((x or {}).get('id') or '')
            if uid not in allowed:continue
            u=dict(allowed[uid]);title=_clean_text((x or {}).get('title') or u['title'])
            if title:u['title']=title
            selected.append(u)
        if not selected:raise ValueError('Select at least one chapter/unit.')
        if len({u['id'] for u in selected})!=len(selected):raise ValueError('Each chapter/unit can only be selected once.')
        # One staged upload owns one build. Retrying after a lost response or
        # refreshing the browser must attach to the existing job.
        prior=sd/'build_job.json'
        with self.jobs_lock:
            if prior.exists():
                existing=json.loads(prior.read_text(encoding='utf-8'))
                if existing.get('selected')!=selected:raise ValueError('This upload is already building. Continue the existing job or start a new upload for different units.')
                current=self.job_status(existing['id'])
                if current.get('status')=='error':
                    self._set_job(existing['id'],status='queued',progress=0,message='Retrying course activation',error='')
                    threading.Thread(target=self._build,args=(existing['id'],stage,selected,existing['course_id'],course_name,stage.get('visual_model','none'),model_key,model_call),daemon=True).start()
                return self.job_status(existing['id'])
        base=_safe_id(course_name or stage.get('course_name') or 'uploaded-course');course_id=base+'-'+uuid.uuid4().hex[:8]
        job_id='course-'+uuid.uuid4().hex[:12]
        job={'id':job_id,'status':'queued','progress':0,'message':'Queued','course_id':course_id,'stage_id':stage_id,'selected':selected,'course_name':course_name,'model_key':model_key,'created_at':time.time(),'updated_at':time.time()}
        with self.jobs_lock:
            self.jobs[job_id]=job;_json_dump(sd/'build_job.json',job);_json_dump(self._job_path(job_id),job)
        th=threading.Thread(target=self._build,args=(job_id,stage,selected,course_id,course_name,stage.get('visual_model','none'),model_key,model_call),daemon=True);th.start()
        return dict(job)

    def _job_path(self,jid):return COURSE_ROOT/'_jobs'/(_safe_id(jid)+'.json')

    def _set_job(self,jid,**kw):
        with self.jobs_lock:
            if jid not in self.jobs:
                jp=self._job_path(jid)
                if not jp.exists():return
                self.jobs[jid]=json.loads(jp.read_text(encoding='utf-8'))
            self.jobs[jid].update(kw);self.jobs[jid]['updated_at']=time.time()
            _json_dump(self._job_path(jid),self.jobs[jid])

    def job_status(self,jid):
        with self.jobs_lock:
            if jid in self.jobs:return dict(self.jobs[jid])
            p=self._job_path(jid)
            return json.loads(p.read_text(encoding='utf-8')) if p.exists() else {}

    def resume_pending(self,model_call):
        """Reconnect jobs and background work after a service restart."""
        jobs_dir=COURSE_ROOT/'_jobs'
        if jobs_dir.exists():
            for p in jobs_dir.glob('*.json'):
                try:
                    job=json.loads(p.read_text(encoding='utf-8'))
                    if job.get('status') not in ('queued','running'):continue
                    stage=json.loads((self._stage_dir(job['stage_id'])/'stage.json').read_text(encoding='utf-8'))
                    cid=job['course_id'];jid=job['id']
                    if self.manifest(cid):
                        self._set_job(jid,status='done',progress=100,message='Course active; background preparation continues',result={'course_id':cid})
                    else:
                        threading.Thread(target=self._build,args=(jid,stage,job['selected'],cid,job['course_name'],stage.get('visual_model','none'),job['model_key'],model_call),daemon=True).start()
                except Exception as e:self._set_job(job.get('id',''),status='error',error='Could not resume build: '+str(e))
        for man in self.list_courses():
            if man.get('content_version')!='v241.9':
                try:man=self._upgrade_course_text(man)
                except Exception as e:
                    self._update_manifest(man['course_id'],lambda current:current.update({'status':'error','migration_error':str(e)}))
                    continue
            if man.get('question_generation')!=QUESTION_GENERATION:
                def prepare_bank(current):
                    current['status']='preparing'
                    current.setdefault('preparation',{})['questions']={'status':'preparing','completed_units':0,'total_units':len(current.get('units') or []),'message':'Preparing reviewed exam-style questions from available evidence'}
                    for u in current.get('units') or []:u['question_count']=0
                man=self._update_manifest(man['course_id'],prepare_bank) or man
            prep=man.get('preparation') or {}
            if man.get('status') in ('preparing','error') or any((prep.get(k) or {}).get('status') in ('preparing','error') for k in ('questions','index','lectures')):
                self._start_preparation(man['course_id'],man.get('model_key') or 'gemma',model_call)

    def _upgrade_course_text(self,man):
        """Replace v241.8 glyph-contaminated scripts, questions and indexes."""
        cid=man['course_id'];cd=self._course_dir(cid);old=[]
        cp=cd/'chunks.jsonl'
        if cp.exists():old=[json.loads(x) for x in cp.read_text(encoding='utf-8').splitlines() if x]
        first={}
        for chunk in old:first.setdefault(chunk.get('unit_id'),chunk)
        chunks=[]
        for unit in man.get('units',[]):
            uid=unit['id'];path=cd/'units'/(uid+'.txt')
            if not path.exists():raise RuntimeError('Saved chapter text is missing for '+str(unit.get('title') or uid))
            content=_safe_source_text(path.read_text(encoding='utf-8'))
            if not _readable_source(content):raise RuntimeError('Chapter '+str(unit.get('title') or uid)+' contains unreadable PDF glyphs; upload an OCR-readable PDF.')
            path.write_text(content,encoding='utf-8')
            previous=first.get(uid) or {}
            for n,value in enumerate(_word_chunks(content),1):
                chunks.append({'id':'%s_c%03d'%(uid,n),'unit_id':uid,'unit_title':unit['title'],'source':unit.get('source_title') or previous.get('source') or 'Uploaded PDF','source_file':previous.get('source_file') or '', 'pdf_page':unit.get('start_page') or previous.get('pdf_page') or 1,'text':value})
            unit['script']='';unit['script_status']='preparing';unit['question_count']=0
        if not chunks:raise RuntimeError('No readable teaching passages remain after PDF text repair.')
        with cp.open('w',encoding='utf-8') as f:
            for chunk in chunks:f.write(json.dumps(chunk,ensure_ascii=False)+'\n')
        _json_dump(cd/'question_banks.json',{});_json_dump(cd/'scenario_cache.json',{})
        for filename in ('vector_index.sqlite3','vector_index.building.sqlite3','window_index.sqlite3'):
            p=cd/filename
            if p.exists():p.unlink()
        prep=man.setdefault('preparation',{})
        prep['lectures']={'status':'preparing','completed_units':0,'total_units':len(man['units']),'message':'Preparing readable Chinese teacher scripts'}
        prep['questions']={'status':'preparing','completed_units':0,'total_units':len(man['units']),'message':'Preparing reviewed exam-style questions from available evidence'}
        prep['index']={'status':'preparing','message':'Rebuilding search from corrected PDF text'}
        man.update({'content_version':'v241.9','question_generation':'scenario-seed-v1','status':'preparing'})
        _json_dump(cd/'course_manifest.json',man)
        with self.cache_lock:self.cache.pop(cid,None)
        return man

    def _unit_text(self,source_path,start_page,end_page,doc=None):
        owned=doc is None
        if owned:doc=fitz.open(str(source_path))
        try:
            parts=[]
            for p in range(max(1,int(start_page)),min(doc.page_count,int(end_page))+1):
                parts.append(_clean_text(doc[p-1].get_text('text') or ''))
            return '\n\n'.join(x for x in parts if x)
        finally:
            if owned:doc.close()

    def _build(self,jid,stage,units,course_id,course_name,visual_model,model_key,model_call):
        phase='initializing the course workspace'
        try:
            if self.manifest(course_id):
                self._set_job(jid,status='done',progress=100,message='Course active; background preparation continues',result={'course_id':course_id})
                self._start_preparation(course_id,model_key,model_call);return
            cd=self._course_dir(course_id);(cd/'source').mkdir(parents=True,exist_ok=True);(cd/'units').mkdir(exist_ok=True)
            sd=self._stage_dir(stage['stage_id'])
            for s in stage.get('sources',[]):
                src=sd/'source'/s['file_name'];dst=cd/'source'/s['file_name']
                if src.exists() and not dst.exists():
                    try:os.link(str(src),str(dst))
                    except OSError:shutil.copyfile(str(src),str(dst))
            phase='extracting chapter text'
            self._set_job(jid,status='running',progress=4,message='Extracting chapter text')
            chunks=[];unit_texts={};doc=None;last_file=None
            try:
                for ui,u in enumerate(units,1):
                    if u['source_file']!=last_file:
                        if doc:doc.close()
                        doc=fitz.open(str(cd/'source'/u['source_file']));last_file=u['source_file']
                    txt=_safe_source_text(self._unit_text(None,u['start_page'],u['end_page'],doc=doc))
                    if not _readable_source(txt):raise RuntimeError('Chapter "%s" has unreadable PDF glyphs. Please upload an OCR-readable PDF instead.'%u['title'])
                    unit_texts[u['id']]=txt
                    (cd/'units'/(u['id']+'.txt')).write_text(txt,encoding='utf-8')
                    for ci,c in enumerate(_word_chunks(txt),1):
                        chunks.append({'id':'%s_c%03d'%(u['id'],ci),'unit_id':u['id'],'unit_title':u['title'],'source':u['source_title'],'source_file':u['source_file'],'pdf_page':u['start_page'],'text':c})
                    self._set_job(jid,progress=4+int(10*ui/max(1,len(units))),message='Extracted %s / %s chapters'%(ui,len(units)))
            finally:
                if doc:doc.close()
            if not chunks:raise RuntimeError('No readable text was extracted from the selected chapters.')
            with (cd/'chunks.jsonl').open('w',encoding='utf-8') as f:
                for c in chunks:f.write(json.dumps(c,ensure_ascii=False)+'\n')
            phase='activating lecture and course Q&A'
            lecture_units=[];by_unit={u['id']:[] for u in units}
            for c in chunks:by_unit[c['unit_id']].append(c)
            for u in units:
                txt=unit_texts.get(u['id'],'')
                lecture_units.append({'id':u['id'],'title':u['title'],'script':'','script_status':'preparing','source_title':u['source_title'],'start_page':u['start_page'],'end_page':u['end_page'],'question_count':0,'question_source_count':0,'question_processed_count':0})
            manifest={'course_id':course_id,'course_name':_clean_text(course_name) or stage.get('course_name') or 'Uploaded Course','visual_model':'vq' if visual_model=='vq' else 'none','visual_model_label':'V/Q Visual Model' if visual_model=='vq' else 'No Specialized Visual Model','sources':stage.get('sources',[]),'units':lecture_units,'content_version':'v241.9','question_target_per_unit':QUESTION_TARGET,'quiz_questions_per_unit':2,'question_generation':QUESTION_GENERATION,'rag':{'embedding_model':EMBED_MODEL,'dimension':1024,'top_candidates':TOP_CANDIDATES,'final_top_k':FINAL_TOP_K,'search_method':'course text ready immediately; semantic passage index follows'},'model_key':model_key,'created_at':time.time(),'status':'preparing','preparation':{'lectures':{'status':'preparing','completed_units':0,'total_units':len(units),'message':'Preparing Traditional Chinese teacher scripts'},'questions':{'status':'preparing','completed_units':0,'total_units':len(units),'message':'Preparing reviewed exam-style questions from available evidence'},'index':{'status':'preparing','message':'Course text Q&A ready; enhancing semantic search'}}}
            _json_dump(cd/'question_banks.json',{});_json_dump(cd/'scenario_cache.json',{})
            _json_dump(cd/'course_manifest.json',manifest)
            self._set_job(jid,status='done',progress=100,message='Course Q&A active; Chinese lectures and scenario concepts are being prepared',result={'course_id':course_id})
            with self.cache_lock:self.cache.pop(course_id,None)
            self._start_preparation(course_id,model_key,model_call)
        except Exception as e:
            self._set_job(jid,status='error',message='Course build failed during '+phase,error=str(e),phase=phase)

    def _build_vectors(self,cd,chunks,jid):
        vp=cd/'vector_index.sqlite3';tmp=cd/'vector_index.building.sqlite3'
        if tmp.exists():tmp.unlink()
        conn=sqlite3.connect(str(tmp))
        try:
            conn.execute('CREATE TABLE vectors (idx INTEGER PRIMARY KEY, chunk_id TEXT, unit_id TEXT, source TEXT, page INTEGER, text TEXT, dim INTEGER, vec BLOB)')
            batch=8;dim=0
            for i in range(0,len(chunks),batch):
                rows=chunks[i:i+batch]
                try:emb=_embed_resilient([r['text'] for r in rows])
                except Exception as e:raise RuntimeError('Passage embedding %s–%s of %s failed: %s'%(i+1,i+len(rows),len(chunks),e))
                if emb:dim=len(emb[0])
                conn.executemany('INSERT INTO vectors VALUES (?,?,?,?,?,?,?,?)',[(i+j+1,r['id'],r['unit_id'],r['source'],int(r.get('pdf_page') or 0),r['text'],len(v),_pack(v)) for j,(r,v) in enumerate(zip(rows,emb))]);conn.commit()
                self._update_manifest(cd.name,lambda m:m['preparation']['index'].update({'status':'preparing','completed':i+len(rows),'total':len(chunks),'message':'Indexed %s / %s passages'%(i+len(rows),len(chunks))}))
            conn.execute('CREATE TABLE meta (key TEXT PRIMARY KEY,value TEXT)');conn.executemany('INSERT INTO meta VALUES (?,?)',[('model',EMBED_MODEL),('count',str(len(chunks))),('dimension',str(dim))]);conn.commit()
        finally:conn.close()
        os.replace(str(tmp),str(vp))
        with self.cache_lock:self.cache.pop(cd.name,None)

    def _update_manifest(self,cid,change):
        with self.manifest_lock:
            m=self.manifest(cid)
            if not m:return None
            change(m);m['updated_at']=time.time();_json_dump(self._manifest_path(cid),m)
            return m

    def _start_preparation(self,cid,model_key,model_call,force=False,only=None):
        m=self.manifest(cid)
        if not m:return
        prep=m.get('preparation') or {}
        for kind,fn in (('questions',self._prepare_questions),('lectures',self._prepare_lectures),('index',self._prepare_index)):
            if only is not None and kind not in only:continue
            if not force and (prep.get(kind) or {}).get('status')=='ready':continue
            key=(cid,kind)
            with self.running_lock:
                if cid in self.deleted:continue
                if key in self.running:continue
                self.running.add(key)
            def work(task=key,task_fn=fn):
                try:task_fn(cid,model_key,model_call)
                finally:
                    with self.running_lock:self.running.discard(task)
                    if task[1]=='questions':
                        latest=self.manifest(cid) or {}
                        questions=(latest.get('preparation') or {}).get('questions') or {}
                        if questions.get('expansion_requests') and questions.get('status')!='error':
                            self._start_preparation(cid,model_key,model_call,force=True,only=('questions',))
            threading.Thread(target=work,daemon=True).start()

    def retry_preparation(self,cid,model_key,model_call):
        if not self.manifest(cid):raise ValueError('course not found')
        self._start_preparation(cid,model_key,model_call,force=True)
        return self.manifest(cid)

    def prioritize_unit(self,cid,unit_id,kind,model_key,model_call):
        man=self.manifest(cid)
        if not man:raise ValueError('course not found')
        if kind not in ('questions','lectures'):raise ValueError('Invalid preparation type.')
        if unit_id not in {u['id'] for u in man.get('units',[])}:raise ValueError('Selected unit not found.')
        self._update_manifest(cid,lambda current:current['preparation'][kind].update({'priority_unit_id':unit_id}))
        self._start_preparation(cid,model_key,model_call)
        return self.manifest(cid)

    def expand_questions(self,cid,unit_ids,model_key,model_call):
        man=self.manifest(cid)
        if not man:raise ValueError('course not found')
        valid={u['id'] for u in man.get('units',[])}
        if not isinstance(unit_ids,list) or not unit_ids or len(unit_ids)>len(valid):
            raise ValueError('Select at least one unit to expand.')
        requested=[str(uid) for uid in unit_ids]
        if len(set(requested))!=len(requested) or any(uid not in valid for uid in requested):
            raise ValueError('The selected unit is invalid.')
        def queue(current):
            q=current['preparation']['questions']
            waiting=list(q.get('expansion_requests') or [])
            q['expansion_requests']=waiting+[uid for uid in requested if uid not in waiting]
            q.update({'status':'preparing','message':'Expanding the selected unit question bank'})
        self._update_manifest(cid,queue)
        self._start_preparation(cid,model_key,model_call,force=True,only=('questions',))
        return self.manifest(cid)

    def _prepare_index(self,cid,model_key,model_call):
        cd=self._course_dir(cid)
        try:
            self._update_manifest(cid,lambda m:m['preparation']['index'].update({'status':'preparing','message':'Preparing semantic passage index','error':''}))
            chunks=[json.loads(line) for line in (cd/'chunks.jsonl').read_text(encoding='utf-8').splitlines() if line]
            self._build_vectors(cd,chunks,None)
            self._update_manifest(cid,lambda m:m['preparation']['index'].update({'status':'ready','message':'Semantic search ready'}))
        except Exception as e:self._update_manifest(cid,lambda m:m['preparation']['index'].update({'status':'error','error':str(e),'message':'Semantic search unavailable; course text search remains active'}))

    def _prepare_lectures(self,cid,model_key,model_call):
        cd=self._course_dir(cid)
        try:
            rows=[json.loads(x) for x in (cd/'chunks.jsonl').read_text(encoding='utf-8').splitlines() if x]
            grouped={}
            for row in rows:grouped.setdefault(row['unit_id'],[]).append(row)
            units=self.manifest(cid)['units'];completed=0;errors=[]
            pending=list(range(len(units)))
            while pending:
                current=self.manifest(cid) or {}
                priority=(current.get('preparation',{}).get('lectures') or {}).get('priority_unit_id')
                i=next((index for index in pending if units[index]['id']==priority),pending[0])
                pending.remove(i);unit=units[i]
                if unit.get('script_status')=='ready' and unit.get('script'):
                    completed+=1;continue
                self._update_manifest(cid,lambda m,n=i:m['preparation']['lectures'].update({'status':'preparing','message':'Writing Chinese lecture %s / %s'%(n+1,len(units)),'error':''}))
                try:script=_chinese_lecture(unit,grouped.get(unit['id'],[]),model_key,model_call)
                except Exception as e:
                    errors.append('%s: %s'%(unit['title'],e))
                    self._update_manifest(cid,lambda m,n=i,err=str(e):m['units'][n].update({'script':'','script_status':'error','script_error':err}))
                else:
                    completed+=1
                    self._update_manifest(cid,lambda m,n=i,value=script:m['units'][n].update({'script':value,'script_status':'ready','script_error':''}))
                self._update_manifest(cid,lambda m:m['preparation']['lectures'].update({'completed_units':completed,'total_units':len(units),'message':'Chinese lectures ready: %s / %s'%(completed,len(units))}))
            state='error' if errors else 'ready'
            self._update_manifest(cid,lambda m:m['preparation']['lectures'].update({'status':state,'error':'; '.join(errors)[:1000]}))
        except Exception as e:
            self._update_manifest(cid,lambda m:m['preparation']['lectures'].update({'status':'error','error':str(e),'message':'Chinese lecture preparation stopped'}))

    def _prepare_questions(self,cid,model_key,model_call):
        """Build reviewed questions in the background; persist each batch for resume."""
        cd=self._course_dir(cid)
        try:
            self._update_manifest(cid,lambda m:m['preparation']['questions'].update({'status':'preparing','message':'Drafting and reviewing exam-style questions','error':''}))
            m=self.manifest(cid);banks=json.loads((cd/'question_banks.json').read_text(encoding='utf-8'))
            chunks=[json.loads(line) for line in (cd/'chunks.jsonl').read_text(encoding='utf-8').splitlines() if line]
            by_unit={u['id']:[] for u in m['units']}
            for c in chunks:
                if c['unit_id'] in by_unit:by_unit[c['unit_id']].append(c)
            banks={uid:[row for row in banks.get(uid,[]) if isinstance(row,dict) and
                (row.get('question') or {}).get('generation_method')==QUESTION_GENERATION]
                for uid in by_unit}
            timing={'calls':0,'seconds':0.0}
            def timed_model_call(*args):
                start=time.monotonic()
                try:return model_call(*args)
                finally:
                    timing['calls']+=1
                    timing['seconds']+=time.monotonic()-start
            # First make each unit playable, then give each a useful small
            # bank. Longer builds run only when a unit is explicitly selected.
            for phase,target in (('first questions',2),('small banks',10)):
                pending=list(enumerate(m['units']))
                while pending:
                    priority=((self.manifest(cid) or {}).get('preparation',{}).get('questions') or {}).get('priority_unit_id')
                    position=next((n for n,(_,unit) in enumerate(pending) if unit['id']==priority),0)
                    idx,u=pending.pop(position)
                    unit_id=u['id']
                    if len(banks.get(unit_id) or [])>=target:continue
                    def save_progress(cards,available,processed,unit_index=idx,unit_id=unit_id,unit_title=u['title'],phase=phase):
                        banks[unit_id]=cards;_json_dump(cd/'question_banks.json',banks)
                        def update(current):
                            current['units'][unit_index].update({'question_count':len(cards),'question_source_count':available,
                                'question_processed_count':processed})
                            ready=sum(x.get('question_count',0)>=2 for x in current['units'])
                            finished=sum(bool(x.get('question_source_count')) and
                                x.get('question_processed_count',0)>=min(QUESTION_TARGET,x['question_source_count'])
                                for x in current['units'])
                            if any(x.get('question_count',0)>0 for x in current['units']):current['question_generation']=QUESTION_GENERATION
                            current['preparation']['questions'].update({'completed_units':finished,'total_units':len(current['units']),
                                'ready_units':ready,'model_calls':timing['calls'],
                                'model_elapsed_seconds':round(timing['seconds'],1),
                                'message':'%s / %s units playable; %s: %s reviewed questions, %s / %s source facts evaluated (%s)'%(
                                    ready,len(current['units']),unit_title,len(cards),processed,available,phase)})
                        self._update_manifest(cid,update)
                    questions=build_exam_questions(u,by_unit[unit_id],_question_sentences,banks.get(unit_id) or [],
                        model_key,timed_model_call,save_progress,target,max_new_facts=12 if target==2 else None)
                    banks[unit_id]=questions
            while True:
                latest=self.manifest(cid) or {}
                requests=((latest.get('preparation') or {}).get('questions') or {}).get('expansion_requests') or []
                if not requests:break
                unit_id=requests[0];index=next((i for i,u in enumerate(m['units']) if u['id']==unit_id),None)
                if index is not None and len(banks.get(unit_id) or [])<QUESTION_TARGET:
                    unit=m['units'][index]
                    def save_expansion(cards,available,processed,unit_index=index,unit_id=unit_id,unit_title=unit['title']):
                        banks[unit_id]=cards;_json_dump(cd/'question_banks.json',banks)
                        def update(current):
                            current['units'][unit_index].update({'question_count':len(cards),'question_source_count':available,
                                'question_processed_count':processed})
                            current['preparation']['questions'].update({'status':'preparing','model_calls':timing['calls'],
                                'model_elapsed_seconds':round(timing['seconds'],1),
                                'message':'Expanding %s: %s approved questions; %s / %s source facts evaluated'%(
                                    unit_title,len(cards),processed,available)})
                        self._update_manifest(cid,update)
                    banks[unit_id]=build_exam_questions(unit,by_unit[unit_id],_question_sentences,banks.get(unit_id) or [],
                        model_key,timed_model_call,save_expansion,QUESTION_TARGET)
                self._update_manifest(cid,lambda current,uid=unit_id:current['preparation']['questions'].update({
                    'expansion_requests':[x for x in current['preparation']['questions'].get('expansion_requests',[]) if x!=uid]}))
            missing=[u['title'] for u in m['units'] if len(banks.get(u['id']) or [])<2]
            if missing:
                raise RuntimeError('Fewer than two reviewed questions in: '+', '.join(missing[:4])+'. Ready units can still be practised; review the PDF text or retry with another model.')
            self._update_manifest(cid,lambda current:(current.update({'status':'ready','question_generation':QUESTION_GENERATION}),
                current['preparation']['questions'].update({'status':'ready','completed_units':len(m['units']),
                    'ready_units':len(m['units']),'message':'Quick question banks ready; choose a unit to expand toward 100 if needed'})))
        except Exception as e:self._update_manifest(cid,lambda m:(m.update({'status':'error'}),m['preparation']['questions'].update({'status':'error','error':str(e),'message':'Question review stopped; saved approved questions remain available'})))

    def list_courses(self):
        out=[]
        for p in sorted(COURSE_ROOT.iterdir()):
            if not p.is_dir() or p.name.startswith('_'):continue
            mp=p/'course_manifest.json'
            if mp.exists():
                try:out.append(json.loads(mp.read_text(encoding='utf-8')))
                except Exception:pass
        return out

    def course_summaries(self):
        return [{'course_id':m['course_id'],'course_name':m.get('course_name') or 'Uploaded Course','unit_count':len(m.get('units') or []),'created_at':m.get('created_at',0)} for m in self.list_courses()]

    def manifest(self,course_id):
        p=self._manifest_path(course_id)
        if not p.exists():return None
        return json.loads(p.read_text(encoding='utf-8'))

    def delete_course(self,course_id):
        cid=str(course_id or '').strip()
        if not cid or cid!=_safe_id(cid) or cid.startswith('_'):
            raise ValueError('Select a valid uploaded course')
        with self.running_lock:
            if any(item[0]==cid for item in self.running):
                raise RuntimeError('This course is still preparing. Wait for preparation to finish before deleting it.')
            self.deleted.add(cid)
        try:
            with self.manifest_lock:
                cd=self._course_dir(cid)
                if cd.is_symlink() or not cd.is_dir() or not self.manifest(cid):raise ValueError('Uploaded course not found')
                shutil.rmtree(str(cd))
                deleted_path=COURSE_ROOT/'_deleted_courses.json'
                previously=json.loads(deleted_path.read_text(encoding='utf-8')) if deleted_path.exists() else []
                _json_dump(deleted_path,sorted(set(previously+[cid])))
            with self.cache_lock:self.cache.pop(cid,None)
        except Exception:
            with self.running_lock:self.deleted.discard(cid)
            raise
        return {'ok':True,'course_id':cid,'deleted':True}

    def _load_index(self,course_id):
        cd=self._course_dir(course_id);vp=cd/'vector_index.sqlite3';wp=cd/'window_index.sqlite3'
        cp=cd/'chunks.jsonl';stamp=(vp.stat().st_mtime_ns if vp.exists() else 0,wp.stat().st_mtime_ns if wp.exists() else 0,cp.stat().st_mtime_ns if cp.exists() else 0)
        with self.cache_lock:
            cached=self.cache.get(course_id)
            if cached and cached.get('stamp')==stamp:return cached
        if not cp.exists() and not vp.exists():raise RuntimeError('Course text is not ready.')
        if vp.exists():
            conn=sqlite3.connect(str(vp));rows=conn.execute('SELECT chunk_id,unit_id,source,page,text,vec FROM vectors ORDER BY idx').fetchall();conn.close()
            passages=[{'chunk_id':r[0],'unit_id':r[1],'source':r[2],'page':r[3],'text':r[4],'vec':_unpack(r[5])} for r in rows]
        else:
            passages=[{'chunk_id':r['id'],'unit_id':r['unit_id'],'source':r['source'],'page':r.get('pdf_page'),'text':r['text']} for r in (json.loads(line) for line in cp.read_text(encoding='utf-8').splitlines() if line)]
        wins=[]
        if wp.exists():
            conn=sqlite3.connect(str(wp));raw=conn.execute('SELECT chunk_id,unit_id,source,window_idx,text,vec FROM windows ORDER BY idx').fetchall();conn.close()
            wins=[{'chunk_id':r[0],'unit_id':r[1],'source':r[2],'window_idx':r[3],'text':r[4],'vec':_unpack(r[5])} for r in raw]
        data={'stamp':stamp,'rows':passages,'windows':wins,'semantic':vp.exists()}
        with self.cache_lock:self.cache[course_id]=data
        return data

    def search(self,course_id,question):
        man=self.manifest(course_id)
        if not man:return {'ok':False,'reason':'course-not-found','context':'','sources':[],'retrieval':{},'in_scope':False}
        q=str(question or '').strip()
        if not q:return {'ok':False,'reason':'empty-question','context':'','sources':[],'retrieval':{},'in_scope':False,'course':man}
        data=self._load_index(course_id);terms=_search_terms(q)
        try:qv=_embed_resilient([q])[0] if data['semantic'] else None
        except Exception:qv=None
        ranked=[]
        for r in data['rows']:
            s=_dot(qv,r['vec']) if qv is not None else _lex_score(terms,r['text'])
            ranked.append((s,r))
        ranked.sort(key=lambda x:x[0],reverse=True)
        srcs={r['source'] for _,r in ranked};cands=[];counts={}
        if len(srcs)>1:
            for s,r in ranked:
                src=r['source'];n=counts.get(src,0)
                if n<SOURCE_CANDIDATES:cands.append((s,r));counts[src]=n+1
                if len(cands)>=TOP_CANDIDATES:break
            if len(cands)<TOP_CANDIDATES:
                seen={r['chunk_id'] for _,r in cands}
                for s,r in ranked:
                    if r['chunk_id'] not in seen:cands.append((s,r));seen.add(r['chunk_id'])
                    if len(cands)>=TOP_CANDIDATES:break
        else:cands=ranked[:TOP_CANDIDATES]
        cids={r['chunk_id'] for _,r in cands};bestwin={}
        if qv is not None:
            for w in data['windows']:
                if w['chunk_id'] not in cids:continue
                s=_dot(qv,w['vec'])
                if w['chunk_id'] not in bestwin or s>bestwin[w['chunk_id']][0]:bestwin[w['chunk_id']]=(s,w)
        rer=[]
        for cs,r in cands:
            if r['chunk_id'] in bestwin:
                ws,w=bestwin[r['chunk_id']];score=RERANK_BLEND*ws+(1.0-RERANK_BLEND)*cs
            else:
                windows=_sentence_windows(r['text']);best=max(windows,key=lambda t:_lex_score(terms,t)) if windows else r['text']
                ws=_lex_score(terms,best);w={'text':best};score=(cs+0.06*ws) if qv is not None else cs
            rr=dict(r);rr['score']=float(score);rr['chunk_score']=float(cs);rr['window_score']=float(ws);rr['window_text']=w.get('text') or r['text'];rer.append(rr)
        rer.sort(key=lambda r:r['score'],reverse=True)
        final=[];counts={}
        for r in rer:
            src=r['source'];cap=SOURCE_MAX_FINAL if len(srcs)>1 else FINAL_TOP_K
            if counts.get(src,0)>=cap:continue
            final.append(r);counts[src]=counts.get(src,0)+1
            if len(final)>=FINAL_TOP_K:break
        if len(final)<FINAL_TOP_K:
            seen={r['chunk_id'] for r in final}
            for r in rer:
                if r['chunk_id'] not in seen:final.append(r);seen.add(r['chunk_id'])
                if len(final)>=FINAL_TOP_K:break
        top_score=float(final[0]['score']) if final else 0.0
        in_scope=bool(final and (top_score>=MIN_SCOPE_SCORE if qv is not None else top_score>0))
        context_parts=[];used=0;sources=[]
        if in_scope:
            for i,r in enumerate(final,1):
                block='[Evidence %d | %s | %s]\n%s'%(i,r['source'],r['unit_id'],r['window_text'])
                if used+len(block)>CONTEXT_BUDGET:break
                context_parts.append(block);used+=len(block)+2
                sources.append({'chunk_id':r['chunk_id'],'source':r['source'],'unit_id':r['unit_id'],'score':round(r['score'],5)})
        retrieval={'embedding_model':EMBED_MODEL if qv is not None else None,'stage1_candidate_count':len(cands),'selected_count':len(sources),'top_matches':[{'chunk_id':r['chunk_id'],'source':r['source'],'unit_id':r['unit_id'],'score':round(r['score'],5)} for r in rer[:8]],'source_balanced':len(srcs)>1,'source_candidate_quota':SOURCE_CANDIDATES,'source_max_final':SOURCE_MAX_FINAL if len(srcs)>1 else None,'rerank_mode':'precomputed semantic windows' if qv is not None and data['windows'] else 'passage vector and lexical windows' if qv is not None else 'course text lexical fallback','final_top_k':FINAL_TOP_K}
        return {'ok':bool(context_parts),'in_scope':in_scope,'reason':'ok' if in_scope else 'outside-uploaded-course-scope','context':'\n\n'.join(context_parts),'sources':sources,'retrieval':retrieval,'course':man,'top_similarity':round(top_score,5)}

    def quiz(self,course_id,per_unit=2,model_key='gemma',model_call=None,progress=None,unit_ids=None):
        man=self.manifest(course_id)
        if not man:raise ValueError('course not found')
        if man.get('question_generation')!=QUESTION_GENERATION:raise ValueError('The exam-style question bank is being prepared. Refresh course status shortly.')
        qp=self._course_dir(course_id)/'question_banks.json'
        if not qp.exists():raise ValueError('question bank not ready')
        per=int(per_unit)
        if per<1 or per>10:raise ValueError('Select 1 to 10 questions per unit.')
        banks=json.loads(qp.read_text(encoding='utf-8'));items=[];summary=[]
        units=man.get('units',[]);started=time.monotonic()
        if unit_ids is not None:
            if not isinstance(unit_ids,list) or not unit_ids or len(unit_ids)>len(units):
                raise ValueError('Select at least one course unit to practise.')
            requested=[str(value) for value in unit_ids]
            valid={u['id'] for u in units}
            if len(set(requested))!=len(requested) or any(uid not in valid for uid in requested):
                raise ValueError('The selected course unit is invalid.')
            units=[u for u in units if u['id'] in requested]
        for index,u in enumerate(units):
            bank=list(banks.get(u['id']) or [])
            if len(bank)<per:
                raise ValueError('Unit "%s" has %s reviewed questions; select %s or fewer per unit.'%(u['title'],len(bank),len(bank)))
            if any(not isinstance(row.get('question'),dict) for row in bank):
                raise ValueError('The complete question bank is being upgraded. Refresh the course status shortly.')
            shuffled=random.sample(bank,len(bank));pick=[];used_statements=set()
            for seed in shuffled:
                statement=seed['source_statement']
                if statement in used_statements:continue
                pick.append(seed);used_statements.add(statement)
                if len(pick)==per:break
            if len(pick)<per:
                pick.extend(x for x in shuffled if x not in pick)  # Smaller chapters may reuse a source statement.
                pick=pick[:per]
            summary.append({'unit_id':u['id'],'title':u['title'],'available':len(bank),'selected':len(pick)})
            for seed in pick:
                q=seed['question']
                if q.get('generation_method')!=QUESTION_GENERATION:raise RuntimeError('A reviewed exam-style question was not available.')
                x=dict(q);x['unit_id']=u['id'];x['unit_title']=u['title'];items.append(x)
            if progress:progress(len(items),per*len(units),'Selected %s / %s ready questions'%(len(items),per*len(units)))
        quiz_id=uuid.uuid4().hex
        with self.quiz_result_lock:
            conn=self._quiz_db(course_id)
            try:
                conn.execute('INSERT INTO sessions (id,created_at,question_ids) VALUES (?,?,?)',(quiz_id,time.time(),json.dumps([x['id'] for x in items])))
                conn.commit()
            finally:conn.close()
        return {'course_id':course_id,'course_name':man.get('course_name'),'quiz_id':quiz_id,'per_unit':per,'total':len(items),'units':summary,'questions':items,'generation':{'prebuilt_questions':len(items),'cached_questions':len(items),'model_calls':0,'elapsed_ms':round((time.monotonic()-started)*1000)}}

    def _quiz_db(self,course_id):
        conn=sqlite3.connect(str(self._course_dir(course_id)/'quiz_results.sqlite3'),timeout=10)
        conn.execute('CREATE TABLE IF NOT EXISTS sessions (id TEXT PRIMARY KEY,created_at REAL NOT NULL,question_ids TEXT NOT NULL,submitted_at REAL)')
        conn.execute('CREATE TABLE IF NOT EXISTS attempts (quiz_id TEXT PRIMARY KEY,submitted_at REAL NOT NULL,summary TEXT NOT NULL)')
        return conn

    def record_quiz(self,course_id,quiz_id,answers):
        if not self.manifest(course_id):raise ValueError('course not found')
        if not re.fullmatch(r'[a-f0-9]{32}',str(quiz_id or '')):raise ValueError('Invalid quiz session')
        if not isinstance(answers,list):raise ValueError('Answers must be a list')
        with self.quiz_result_lock:
            conn=self._quiz_db(course_id)
            try:
                existing=conn.execute('SELECT summary FROM attempts WHERE quiz_id=?',(quiz_id,)).fetchone()
                if existing:return json.loads(existing[0])
                row=conn.execute('SELECT question_ids FROM sessions WHERE id=?',(quiz_id,)).fetchone()
                if not row:raise ValueError('Quiz session not found; start a new quiz')
                ids=json.loads(row[0])
                if len(answers)!=len(ids) or [x.get('id') for x in answers if isinstance(x,dict)]!=ids:
                    raise ValueError('The submitted questions differ from this quiz session')
                banks=json.loads((self._course_dir(course_id)/'question_banks.json').read_text(encoding='utf-8'))
                legacy_cache_path=self._course_dir(course_id)/'scenario_cache.json'
                legacy_cache=json.loads(legacy_cache_path.read_text(encoding='utf-8')) if legacy_cache_path.exists() else {}
                unit_by_id={key:(uid,seed['source_statement'],seed.get('question') if key!=seed['id'] else legacy_cache.get(seed['id'])) for uid,bank in banks.items() for seed in bank for key in (seed['id'],(seed.get('question') or {}).get('id')) if key}
                rows=[];correct=0;answered=0;per_unit={}
                for item,answer_id in zip(answers,ids):
                    source=unit_by_id.get(answer_id)
                    if not source and answer_id in legacy_cache:
                        prior=legacy_cache[answer_id]
                        source=(str(prior.get('unit_id') or answer_id.split('_q')[0]),str(prior.get('evidence_statement') or ''),prior)
                    if not source:raise ValueError('Quiz question is unavailable')
                    q=source[2]
                    if not q:raise ValueError('Quiz question is unavailable')
                    choice=item.get('choice')
                    if choice is not None and (isinstance(choice,bool) or not isinstance(choice,int) or choice not in range(4)):
                        raise ValueError('Answer choice must be A–D or unanswered')
                    is_correct=choice is not None and choice==q['answer'];correct+=int(is_correct);answered+=int(choice is not None)
                    uid=source[0];u=per_unit.setdefault(uid,{'unit_id':uid,'total':0,'answered':0,'correct':0})
                    u['total']+=1;u['answered']+=int(choice is not None);u['correct']+=int(is_correct)
                    rows.append({'id':answer_id,'unit_id':uid,'choice':choice,'correct_choice':q['answer'],'correct':is_correct})
                result={'ok':True,'quiz_id':quiz_id,'course_id':course_id,'total':len(ids),'answered':answered,'correct':correct,'accuracy':round(100*correct/float(max(1,len(ids))),1),'units':list(per_unit.values()),'items':rows}
                conn.execute('INSERT INTO attempts (quiz_id,submitted_at,summary) VALUES (?,?,?)',(quiz_id,time.time(),json.dumps(result,ensure_ascii=False)))
                conn.execute('UPDATE sessions SET submitted_at=? WHERE id=?',(time.time(),quiz_id));conn.commit()
                return result
            finally:conn.close()

    def quiz_statistics(self,course_id):
        if not self.manifest(course_id):raise ValueError('course not found')
        with self.quiz_result_lock:
            conn=self._quiz_db(course_id)
            try:rows=[json.loads(x[0]) for x in conn.execute('SELECT summary FROM attempts')]
            finally:conn.close()
        units={}
        for attempt in rows:
            for row in attempt['units']:
                u=units.setdefault(row['unit_id'],{'unit_id':row['unit_id'],'total':0,'answered':0,'correct':0})
                for field in ('total','answered','correct'):u[field]+=row[field]
        questions=sum(x['total'] for x in rows);correct=sum(x['correct'] for x in rows)
        return {'ok':True,'course_id':course_id,'attempts':len(rows),'questions':questions,'correct':correct,'accuracy':round(100*correct/float(max(1,questions)),1),'units':list(units.values())}

COURSES=CourseManager()
