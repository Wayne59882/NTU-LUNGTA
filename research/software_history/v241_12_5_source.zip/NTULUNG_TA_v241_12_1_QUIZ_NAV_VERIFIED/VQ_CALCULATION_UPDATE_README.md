# v241.12.5 V/Q 計算修正版（2026-10-09）

此完整包以原始 v241.12.5 為基礎。更新範圍是 V/Q 計算、相關情境、快取版本與驗證入口；其餘課程、講稿、RAG、問答、題庫與模型設定維持原程式。公開網站須部署後才會套用新公式；附圖是在本機載入實際應用程式取得。

## 原始初始值

以下 11 項與原始 v241.12.5 的 HTML、Normal/Reset 設定逐項相同：VT=500 mL、VD=150 mL、f=15/min、FiO2=0.21、Altitude=0 m、VO2=300 mL/min、R=0.8、Hb=15 g/dL、QT=5.5 L/min、Shunt=0、DLO2=32 mL/min/mmHg。修正推導公式後，輸出值會改變。舊 PPT 的 f=12 截圖不是本版本的初始狀態，已替換成實際 f=15 的畫面。

所有原有情境的輸入值也保持不變，包括 **Diffusion Limitation 的 DLO2=16**。新公式不會強制產生指定的氧氣落差。報告另提供手動將 DLO2 設為 8 或 5 的比較結果，說明擴散程度對結果的影響；這些比較不會覆蓋原有情境。

## 計算方法

原碼只有一個均勻肺單元；High V/Q 的整肺通氣上升會直接令 PaCO2 降低。原碼另有四組顯示數字的多項式校正，分別改寫 PO2、飽和度、含量與 pH，使顯示值不一定彼此一致。新版移除獨立數字校正，改由以下约束求穩態解：

1. VE = VT × f / 1000；VA = (VT − VD) × f / 1000。
2. PIO2 = FiO2 × (PB − 47)，海平面 PB=760 mmHg。
3. 每個肺單元 PACO2 = 0.863 × VCO2_exchange / VA。代謝氣體為 STPD mL/min，肺泡通氣為 BTPS L/min。
4. 完整氧氣平衡：PAO2 = PIO2 − 0.863 × [FiO2 × VCO2_exchange + (1−FiO2) × VO2_exchange] / VA。
5. 血氧含量 = 1.34 × Hb × saturation + 0.0031 × PO2。使用 Hill 曲線、Bohr 修正、固定 base excess=0 的酸鹼約束及包含 Haldane effect 的 Douglas 型 CO2 含量近似。
6. 有限氧氣擴散：∫[dC/dP ÷ (PAO2−P)] dP = DLO2/(10 × Q)。CO2 假設快速平衡。
7. 分流與各肺單元按 **氣體含量及血流量** 混合，再反解血氣壓力，不平均 PO2/PCO2。
8. 全身 Fick 約束：10QT(CaO2−CvO2)=VO2；10QT(CvCO2−CaCO2)=VCO2。無可行穩態時顯示錯誤，不用截斷數字偽裝正常結果。

General 的肺泡壓力為通氣加權；End Capillary 為灌流加權的血液含量所對應血氣；Arterial 再加入真正分流。異質肺部時三者可能不同。畫面的 A-a 差使用理想肺泡氣體方程：PIO2 − PaCO2 × [FiO2 + (1−FiO2)/R] − PaO2。解釋區另列此理想肺泡估計值；異質肺部時，它可能與 General 顯示的實際通氣加權 PAO2 不同。

## 區域 V/Q 假設

整肺 VA、QT 無法唯一決定區域 V/Q 分布。VD 在此視為導氣道死腔；區域浪費通氣另由肺單元分配表示。若輸入的 VD 已包含肺泡死腔，兩者不能重複計入。新版情境採用兩單元的 **教學示意分配**，並在介面解釋區列明：

| 情境 | 受影響單元占總 VA | 占有通氣肺的灌流 |
|---|---:|---:|
| Low V/Q | 20% | 50% |
| High V/Q | 70% | 10% |
| Pulmonary embolism | 50% | 10% |
| Pneumonia | 30% | 50% |

另一單元接受剩餘通氣及灌流，DLO2 按灌流分配。正常、真正分流、單純擴散受限使用一個通氣單元。這些比例不是實測值；數值取決於分配假設。模型固定37°C、base excess=0，且沒有自動呼吸代償，尚未經病人資料或老師的獨立標準模型驗證。

## 老師註記的核對

- **Low V/Q 的 PcCO2 約46：** 原始 VT350、VD180、f14，使 VA只有2.38 L/min。VO2=300、R=0.8 時，均勻肺泡模型的 CO2 已約87.03 mmHg，不能保留這些條件又直接指定46。區域模型的 PaCO2 約95.54；詳細 end-capillary 值見報告。若要約46，需要不同通氣／代謝條件或代償假設。
- **High V/Q：** 區域浪費通氣已納入；固定通氣且不自動代償時，此情境 PaCO2 約56.31 mmHg。不能推廣成所有 high V/Q 一定造成整體 PaCO2 上升。
- **Diffusion：** DLO2=16 在此穩態條件下接近完全平衡，氧氣落差很小不一定是錯誤。示範 DLO2=8 時，PAO2約99.11、PaO2約92.82，差約6.30 mmHg；DLO2=5 時落差更大。
- **True shunt 補氧：** 反應較差，不代表 PaO2 必須完全不變。固定30%分流例，FiO2從0.21到0.40，PaO2約56.38→70.13；無分流時上升幅度大得多。混合按含量計算，不把 PaO2 鎖死。

完整輸入、結果、平衡殘差及實際畫面在 `VQ_CALCULATION_REPORT/`。這些是模型驗證結果，不是臨床或學生學習效果驗證。

## 在 server 套用

將完整 ZIP 上傳並解壓到 server 的新資料夾，進入內層 `NTULUNG_TA_v241_12_1_QUIZ_NAV_VERIFIED` 後執行：

```bash
node VERIFY_VQ_CONSERVATION.cjs
bash APPLY_VQ_CALCULATION_UPDATE.sh /你的目前運行中的程式資料夾
```

路徑須為實際含 `web/reference`、`web/kb`、`wrangler.jsonc` 的現有程式資料夾。更新脚本只覆蓋6個相關網頁檔與驗證入口，先備份、沿用現有 API origin 和 Worker 權限；不啟動新 LLM 或替換 API key。若現有資料夾沒有 `logs/cloudflare_origin_url.txt`，先將 `VQ_ORIGIN_URL` 設為目前使用的 HTTPS origin；找不到 origin 時會在寫入前停止。

只更新本機、不部署公開網站：

```bash
VQ_DEPLOY_STATIC=0 bash APPLY_VQ_CALCULATION_UPDATE.sh /你的目前運行中的程式資料夾
```

更新後重新整理頁面即可，29及35兩支 JS 已更改快取版本。执行 `node VERIFY_VQ_CONSERVATION.cjs --write-report` 可重新取得計算報告。

## 方法來源

- https://pmc.ncbi.nlm.nih.gov/articles/PMC8315793/ ：氣體平衡、血液含量與分流混合原理。
- https://pubmed.ncbi.nlm.nih.gov/25063240/ ：區域 V/Q 與分流原理。
- https://journals.physiology.org/doi/full/10.1152/advan.00064.2019 ：肺泡通氣方程與單位換算。

文獻支持計算原理，並不驗證此程式的區域分配比例或每個情境數值。
