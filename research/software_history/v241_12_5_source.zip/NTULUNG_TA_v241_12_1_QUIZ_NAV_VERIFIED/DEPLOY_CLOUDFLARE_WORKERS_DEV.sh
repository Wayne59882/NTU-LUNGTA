#!/usr/bin/env bash
set -euo pipefail
BASE="$(cd "$(dirname "$0")" && pwd)"
for d in /work103/wayne6/node-v22/bin "$HOME/node-v22/bin"; do [[ -x "$d/node" ]] && export PATH="$d:$PATH" && break; done
URLFILE="$BASE/logs/cloudflare_origin_url.txt"; ORIGIN="${VQ_ORIGIN_URL:-}"
if [[ -z "$ORIGIN" ]]; then [[ -f "$URLFILE" ]] || "$BASE/START_CLOUDFLARE_TUNNEL.sh"; ORIGIN="$(cat "$URLFILE")"; fi
ORIGIN="${ORIGIN%/}"; [[ "$ORIGIN" == https://* ]] || { echo "[ERROR] HTTPS origin required: $ORIGIN"; exit 1; }
command -v node >/dev/null 2>&1 || { echo '[ERROR] Node.js not found.'; exit 1; }
command -v npx >/dev/null 2>&1 || { echo '[ERROR] npx not found.'; exit 1; }
cd "$BASE"
echo '[INFO] Verifying pinned 3D Avatar runtime + Yating/Zhiwei model URLs...'
"$BASE/ENSURE_3D_RUNTIME.sh"
echo '[INFO] Static assets + Worker are being deployed to the existing lungta workers.dev site.'
echo '[INFO] Query Knowledge Base remains Local-only.'
echo '[INFO] Reference Textbook and uploaded-course modes use semantic Vector RAG. Local answer first; optional BYOK GPT-5.6 Luna fallback uses the same retrieved evidence. No system-owned cloud API key is configured.'
echo "[INFO] API origin: $ORIGIN"
npx --yes wrangler@4.127.0 deploy --config "$BASE/wrangler.jsonc" --var "ORIGIN_URL:$ORIGIN"
