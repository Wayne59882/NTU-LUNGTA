'use strict';
// Independent constraints, analytic limits, and original-input regression.
const fs=require('fs'),path=require('path'),assert=require('assert'),vm=require('vm');
const base=__dirname;
const context={module:{exports:{}}};
vm.runInNewContext(fs.readFileSync(path.join(base,'web/reference/js/35_hopkins_reference_lung_physiology.js'),'utf8'),context);
const E=context.module.exports;
const defaults={VT:500,VD:150,f:15,FIO2:.21,Altitude:0,VO2:300,R:.8,Hb:15,QT:5.5,Shunt:0,DLO2:32};
const presets={normal:{},lowvq:{VT:350,VD:180,f:14,Shunt:.08},highvq:{VT:650,VD:280,f:18,QT:3.4,Shunt:.02},pe:{VT:650,VD:300,f:20,QT:3.2,Shunt:.02},pneumonia:{VT:320,VD:150,f:18,Shunt:.18},shunt:{Shunt:.30,VT:400,f:16},diffusion:{DLO2:16,VT:500,f:14},anemia:{Hb:8},altitude:{Altitude:3000,FIO2:.21,f:18}};
const checks=[];function test(name,fn){fn();checks.push(name);console.log('PASS '+name);}
function near(x,y,t=1e-3){assert(Number.isFinite(x)&&Number.isFinite(y));assert(Math.abs(x-y)<t,`${x} differs from ${y} (tolerance ${t})`);}
function calc(x){const d=E.calculateFromInputs({...defaults,...x});assert(d.ok,JSON.stringify(d.errors));return d;}
test('all eleven initial engine defaults are unchanged',()=>assert.deepStrictEqual(JSON.parse(JSON.stringify(E.DEFAULTS)),defaults));
test('both pages retain every original initial HTML input',()=>{
 for(const mode of ['kb','reference']){
 const html=fs.readFileSync(path.join(base,'web',mode,'index.html'),'utf8');
 for(const [key,value] of Object.entries(defaults)){
 const input=html.match(new RegExp('<input[^>]*id="v149_'+key+'"[^>]*>'));assert(input,'Missing '+key);
 near(Number(input[0].match(/value="([^"]+)"/)[1]),value,1e-12);
 }
 for(const name of ['29_v153_course_aligned_student_results','35_hopkins_reference_lung_physiology'])assert(html.includes(name+'.js?v=241125vqconservation20261009'));
 }
});
test('KB and Reference use identical authoritative calculation code',()=>assert(fs.readFileSync(path.join(base,'web/kb/js/35_hopkins_reference_lung_physiology.js')).equals(fs.readFileSync(path.join(base,'web/reference/js/35_hopkins_reference_lung_physiology.js')))));
const results={};
for(const [preset,patch] of Object.entries(presets))test(preset+': oxygen/CO2 conservation and content mixing',()=>{
 const d=calc({...patch,preset});results[preset]=d;
 near(10*d.s.QT*(d.arterialO2Content-d.mixedVenousO2Content),d.s.VO2,.001);
 near(10*d.s.QT*(d.mixedVenousCO2Content-d.arterialCO2Content),d.VCO2,.001);
 near(d.arterialO2Content,d.s.Shunt*d.mixedVenousO2Content+d.units.reduce((a,u)=>a+u.q/d.s.QT*u.o2,0),1e-10);
 near(d.arterialCO2Content,d.s.Shunt*d.mixedVenousCO2Content+d.units.reduce((a,u)=>a+u.q/d.s.QT*u.co2,0),1e-10);
 near(E.o2ContentMlDl(d.artPO2,d.s.Hb,d.artPCO2),d.arterialO2Content,1e-7);
 near(E.co2ContentMlDl(d.artPCO2,d.s.Hb,d.artSat),d.arterialCO2Content,1e-7);
 near(d.aaGradient,d.PIO2-d.artPCO2*(d.s.FIO2+(1-d.s.FIO2)/d.s.R)-d.artPO2,1e-9);
 for(const u of d.units){near(u.pc,.863*u.co2Flux/u.va,1e-4);near(u.pa,d.PIO2-.863*(d.s.FIO2*u.co2Flux+(1-d.s.FIO2)*u.o2Flux)/u.va,1e-4);}
});
test('homogeneous ventilation matches the independent alveolar equations',()=>{
 const d=results.normal,va=(500-150)*15/1000;
 near(d.VA,va,1e-12);near(d.VE,500*15/1000,1e-12);
 near(d.artPCO2,.863*300*.8/va,.001);
 near(d.PAO2,.21*(760-47)-.863*(.21*240+.79*300)/va,.001);
 near(calc({f:30}).artPCO2,d.artPCO2/2,.001);
});
test('regional wasted ventilation changes arterial, not whole-lung input values',()=>{
 const a=calc({preset:'normal'}),b=calc({preset:'highvq'});
 assert(b.artPCO2>a.artPCO2);near(a.VA,b.VA,1e-12);near(a.VE,b.VE,1e-12);
});
test('lower diffusing capacity widens A-a oxygen difference',()=>{
 const a=calc({f:14,DLO2:32}),b=calc({f:14,DLO2:8}),c=calc({f:14,DLO2:5});
 assert(a.aaGradient<b.aaGradient&&b.aaGradient<c.aaGradient);assert(b.aaGradient>5);
});
test('true shunt has a reduced oxygen response, without a false flat PaO2',()=>{
 const a=calc({...presets.shunt,FIO2:.21}),b=calc({...presets.shunt,FIO2:.4});
 const n=calc({VT:400,f:16,FIO2:.21}),m=calc({VT:400,f:16,FIO2:.4});
 assert(b.artPO2>a.artPO2);assert(b.artPO2-a.artPO2<m.artPO2-n.artPO2);
});
test('diffusion solver agrees with the exact dissolved-only exponential limit',()=>{
 const pv=40,pa=100,q=5,dl=.05,beta=.0031;
 near(E.endCapillaryO2FromDiffusion(pv,pa,q,dl,0,40).po2,pa-(pa-pv)*Math.exp(-dl/(10*q*beta)),1e-5);
});
test('invalid/infeasible settings return errors, without plausible fabricated outputs',()=>{
 for(const x of [{VT:150,VD:150},{QT:0},{Hb:-1},{FIO2:1.1},{Shunt:1},{VO2:0},{VT:NaN},{DLO2:0}])assert(!E.calculateFromInputs({...defaults,...x}).ok,JSON.stringify(x));
});
test('reset defaults and all original preset inputs remain unchanged',()=>{
 for(const mode of ['kb','reference']){
 const s=fs.readFileSync(path.join(base,'web',mode,'js/29_v153_course_aligned_student_results.js'),'utf8');
 const t=s.match(/const DEFAULTS=(\{[^;]+\});/)[1];assert.deepStrictEqual(Function('return ('+t+')')(),defaults);
 const p=s.match(/const PRESETS=(\{[^;]+\});/)[1];assert.deepStrictEqual(Function('return ('+p+')')(),presets);
 }
});
if(process.argv.includes('--write-report')){
 fs.mkdirSync(path.join(base,'VQ_CALCULATION_REPORT'),{recursive:true});
 const rows=Object.entries(results).map(([preset,d])=>({preset,inputs:d.s,VE:d.VE,VA:d.VA,alveolarPCO2:d.PACO2,alveolarPO2:d.PAO2,endCapillaryPCO2:d.endPCO2,endCapillaryPO2:d.endPO2,arterialPCO2:d.artPCO2,arterialPO2:d.artPO2,AaDifference:d.aaGradient,oxygenBalanceResidual:d.oxygenBalanceResidual,co2BalanceResidual:d.co2BalanceResidual,units:d.units,assumptions:d.warnings}));
 fs.writeFileSync(path.join(base,'VQ_CALCULATION_REPORT/verified_cases.json'),JSON.stringify({revision:'v241.12.5-VQ-conservation-20261009',checks,rows},null,2)+'\n');
 const cols=['preset','VE','VA','alveolarPCO2','alveolarPO2','endCapillaryPCO2','endCapillaryPO2','arterialPCO2','arterialPO2','AaDifference','oxygenBalanceResidual','co2BalanceResidual'];
 fs.writeFileSync(path.join(base,'VQ_CALCULATION_REPORT/verified_cases.csv'),cols.join(',')+'\n'+rows.map(x=>cols.map(k=>x[k]).join(',')).join('\n')+'\n');
}
console.log(checks.length+' checks passed. Initial defaults preserved.');
