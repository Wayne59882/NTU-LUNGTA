#!/usr/bin/env python3
from __future__ import print_function
import argparse, json, os, urllib.request, urllib.error
from http.server import SimpleHTTPRequestHandler
try:
    from http.server import ThreadingHTTPServer
except ImportError:
    from http.server import HTTPServer
    from socketserver import ThreadingMixIn
    class ThreadingHTTPServer(ThreadingMixIn,HTTPServer): daemon_threads=True
from pathlib import Path
ROOT=Path(__file__).resolve().parent; WEB=ROOT/'web'
KB='http://127.0.0.1:'+os.environ.get('VQ_KB_INTERNAL_PORT','8181')
REF='http://127.0.0.1:'+os.environ.get('VQ_REFERENCE_INTERNAL_PORT','8182')
class H(SimpleHTTPRequestHandler):
    def end_headers(self): self.send_header('Cache-Control','no-store'); super().end_headers()
    def _target(self):
        p=self.path
        if p.startswith('/api/kb/'): return KB+'/api/'+p[len('/api/kb/'):]
        if p=='/api/reference/tts': return KB+'/api/tts'
        if p.startswith('/api/reference/'): return REF+p
        return None
    def _proxy(self):
        target=self._target()
        if not target:return False
        n=int(self.headers.get('Content-Length','0') or 0); body=self.rfile.read(n) if n else None
        headers={k:v for k,v in self.headers.items() if k.lower() not in ('host','content-length','connection')}
        try:
            req=urllib.request.Request(target,data=body,headers=headers,method=self.command)
            with urllib.request.urlopen(req,timeout=300) as r:
                data=r.read();self.send_response(getattr(r,'status',200));self.send_header('Content-Type',r.headers.get('Content-Type','application/octet-stream'));self.send_header('Content-Length',str(len(data)));self.end_headers();
                try:self.wfile.write(data)
                except (BrokenPipeError,ConnectionResetError):pass
        except urllib.error.HTTPError as e:
            data=e.read();self.send_response(e.code);self.send_header('Content-Type',e.headers.get('Content-Type','application/json'));self.send_header('Content-Length',str(len(data)));self.end_headers();
            try:self.wfile.write(data)
            except (BrokenPipeError,ConnectionResetError):pass
        except Exception as e:
            data=json.dumps({'error':'Backend unavailable','detail':str(e)}).encode();self.send_response(502);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(data)));self.end_headers();
            try:self.wfile.write(data)
            except (BrokenPipeError,ConnectionResetError):pass
        return True
    def do_GET(self):
        if self._proxy():return
        if self.path=='/api/health':
            b=json.dumps({'ok':True,'build':'v241.12.5-full-answer-voice','serving_profile':'v241.12.5-full-answer-voice','modes':['query-knowledge-base','reference-textbook']}).encode();self.send_response(200);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(b)));self.end_headers();self.wfile.write(b);return
        if self.path=='/':self.path='/reference/'
        return super().do_GET()
    def do_POST(self):
        if self._proxy():return
        self.send_error(404)
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--host',default='0.0.0.0');ap.add_argument('--port',type=int,default=int(os.environ.get('VQ_PORT','8179')));args=ap.parse_args();os.chdir(str(WEB));s=ThreadingHTTPServer((args.host,args.port),H);print('[OK] v206.7 gateway http://%s:%s'%(args.host,args.port));s.serve_forever()
if __name__=='__main__':main()
