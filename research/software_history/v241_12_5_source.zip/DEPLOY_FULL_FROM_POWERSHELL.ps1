& {
    $ErrorActionPreference = 'Stop'
    $zip = Get-ChildItem -LiteralPath (Join-Path $env:USERPROFILE 'Downloads') -Filter 'NTULUNG_TA_v241_12_5_VQ_CALCULATION_FIXED*.zip' -File |
        Sort-Object LastWriteTime -Descending | Select-Object -First 1
    if (!$zip) { throw 'Download the updated COMPLETE ZIP to Downloads first.' }
    $releaseId = 'lungta_full_' + (Get-Date -Format 'yyyyMMdd_HHmmss') + '_' + ([Guid]::NewGuid().ToString('N').Substring(0,6))
    scp $zip.FullName "wayne6@172.16.0.103:/work103/wayne6/$releaseId.zip"
    if ($LASTEXITCODE -ne 0) { throw 'Upload failed. Existing app was not changed.' }
    ssh -v -T -o ConnectTimeout=20 -o ServerAliveInterval=30 -o ServerAliveCountMax=6 wayne6@172.16.0.103 "printf 'SSH_OK\n' && cd /work103/wayne6 && unzip -tq $releaseId.zip && mkdir $releaseId && unzip -q $releaseId.zip -d $releaseId && bash $releaseId/DEPLOY_COMPLETE.sh"
    if ($LASTEXITCODE -ne 0) { throw 'Full deployment NOT verified. Keep the complete error output.' }
    Start-Process "https://lungta.twchu.workers.dev/reference/?vqfix=$releaseId"
}

