& {
    $ErrorActionPreference = 'Stop'
    $zip = Get-ChildItem -LiteralPath (Join-Path $env:USERPROFILE 'Downloads') -Filter 'NTULUNG_TA_v241_12_5_FULL*.zip' -File |
        Sort-Object LastWriteTime -Descending | Select-Object -First 1
    if (!$zip) { throw 'Download NTULUNG_TA_v241_12_5_FULL.zip to Downloads first.' }
    $releaseId = 'lungta_full_' + (Get-Date -Format 'yyyyMMdd_HHmmss')
    scp $zip.FullName "wayne6@172.16.0.103:/work103/wayne6/$releaseId.zip"
    if ($LASTEXITCODE -ne 0) { throw 'Upload failed. Server was not changed.' }
    ssh -t -o ServerAliveInterval=30 wayne6@172.16.0.103 "cd /work103/wayne6 && unzip -tq $releaseId.zip && unzip -oq $releaseId.zip -d $releaseId && cd $releaseId && bash APPLY_FULL_UPDATE.sh"
    if ($LASTEXITCODE -ne 0) { throw 'Deployment did not finish. Keep the error output.' }
}
