param([string]$ZipPath)
& (Join-Path $PSScriptRoot 'RUN_R12.ps1') -ZipPath $ZipPath
